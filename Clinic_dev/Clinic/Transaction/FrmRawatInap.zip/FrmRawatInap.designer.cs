﻿namespace Clinic
{
    partial class FrmRawatInap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmRawatInap));
            DevExpress.XtraCharts.XYDiagram xyDiagram1 = new DevExpress.XtraCharts.XYDiagram();
            DevExpress.XtraCharts.Series series1 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.PointSeriesLabel pointSeriesLabel1 = new DevExpress.XtraCharts.PointSeriesLabel();
            DevExpress.XtraCharts.LineSeriesView lineSeriesView1 = new DevExpress.XtraCharts.LineSeriesView();
            DevExpress.XtraCharts.Series series2 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.PointSeriesLabel pointSeriesLabel2 = new DevExpress.XtraCharts.PointSeriesLabel();
            DevExpress.XtraCharts.LineSeriesView lineSeriesView2 = new DevExpress.XtraCharts.LineSeriesView();
            DevExpress.XtraCharts.Series series3 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.PointSeriesLabel pointSeriesLabel3 = new DevExpress.XtraCharts.PointSeriesLabel();
            DevExpress.XtraCharts.LineSeriesView lineSeriesView3 = new DevExpress.XtraCharts.LineSeriesView();
            this.tab5 = new DevExpress.XtraTab.XtraTabPage();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.pnlPulang1 = new System.Windows.Forms.Panel();
            this.scrolPulang = new DevExpress.XtraEditors.XtraScrollableControl();
            this.xtraScrollableControl8 = new DevExpress.XtraEditors.XtraScrollableControl();
            this.xtraScrollableControl12 = new DevExpress.XtraEditors.XtraScrollableControl();
            this.txAltTerpsang = new DevExpress.XtraEditors.TextEdit();
            this.txKeadaanDtl = new DevExpress.XtraEditors.TextEdit();
            this.cbKeadaanPulang = new System.Windows.Forms.ComboBox();
            this.addObat = new DevExpress.XtraEditors.SimpleButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.chkDoc7 = new System.Windows.Forms.CheckBox();
            this.chkDoc8 = new System.Windows.Forms.CheckBox();
            this.chkDoc6 = new System.Windows.Forms.CheckBox();
            this.chkDoc5 = new System.Windows.Forms.CheckBox();
            this.chkDoc4 = new System.Windows.Forms.CheckBox();
            this.chkDoc3 = new System.Windows.Forms.CheckBox();
            this.chkDoc2 = new System.Windows.Forms.CheckBox();
            this.chkDoc1 = new System.Windows.Forms.CheckBox();
            this.txDoc3 = new DevExpress.XtraEditors.TextEdit();
            this.txDoc5 = new DevExpress.XtraEditors.TextEdit();
            this.txDoc6 = new DevExpress.XtraEditors.TextEdit();
            this.txDoc4 = new DevExpress.XtraEditors.TextEdit();
            this.txDoc2 = new DevExpress.XtraEditors.TextEdit();
            this.txDoc1 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl38 = new DevExpress.XtraEditors.LabelControl();
            this.lblKeadaan = new DevExpress.XtraEditors.LabelControl();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.cbAlatTerpasang = new System.Windows.Forms.ComboBox();
            this.gcObtPlng = new DevExpress.XtraGrid.GridControl();
            this.gvObtPlng = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn19 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn20 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn21 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn22 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn23 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.txObatRutin = new DevExpress.XtraEditors.TextEdit();
            this.rgRawatLanjutan = new DevExpress.XtraEditors.RadioGroup();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl47 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl48 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl49 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl50 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl52 = new DevExpress.XtraEditors.LabelControl();
            this.txWaktu = new DevExpress.XtraEditors.TextEdit();
            this.txdoRawat = new DevExpress.XtraEditors.TextEdit();
            this.txKebiasaanlain = new DevExpress.XtraEditors.TextEdit();
            this.txDokterDituju = new DevExpress.XtraEditors.TextEdit();
            this.txTindakan = new DevExpress.XtraEditors.TextEdit();
            this.txPsikologis = new DevExpress.XtraEditors.TextEdit();
            this.txProcedurePlan = new DevExpress.XtraEditors.TextEdit();
            this.txControlLanjutan = new DevExpress.XtraEditors.TextEdit();
            this.txProcRawat = new DevExpress.XtraEditors.TextEdit();
            this.txUnitKesehatan = new DevExpress.XtraEditors.TextEdit();
            this.txPolaMakan = new DevExpress.XtraEditors.TextEdit();
            this.txAktivitas = new DevExpress.XtraEditors.TextEdit();
            this.txjenisPeriksa = new DevExpress.XtraEditors.TextEdit();
            this.labelControl53 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl54 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl55 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl56 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl57 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl58 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl59 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl60 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl61 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl62 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl63 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl64 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl66 = new DevExpress.XtraEditors.LabelControl();
            this.dtkeluar = new DevExpress.XtraEditors.DateEdit();
            this.labelControl26 = new DevExpress.XtraEditors.LabelControl();
            this.panel14 = new System.Windows.Forms.Panel();
            this.xtraScrollableControl9 = new DevExpress.XtraEditors.XtraScrollableControl();
            this.xtraScrollableControl11 = new DevExpress.XtraEditors.XtraScrollableControl();
            this.labelControl25 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl21 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl24 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl23 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl22 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl94 = new DevExpress.XtraEditors.LabelControl();
            this.txAnjuran = new DevExpress.XtraEditors.MemoEdit();
            this.mmPeriksaFisik = new DevExpress.XtraEditors.MemoEdit();
            this.txAnamesa = new DevExpress.XtraEditors.MemoEdit();
            this.txTerapiLanjtan = new DevExpress.XtraEditors.TextEdit();
            this.txTindakanDo = new DevExpress.XtraEditors.TextEdit();
            this.txPengobatan = new DevExpress.XtraEditors.TextEdit();
            this.txDiagnosaAkhir = new DevExpress.XtraEditors.TextEdit();
            this.txDokterKonsultan = new DevExpress.XtraEditors.TextEdit();
            this.txDokterPengirim = new DevExpress.XtraEditors.TextEdit();
            this.dtKeluarx = new DevExpress.XtraEditors.DateEdit();
            this.labelControl93 = new DevExpress.XtraEditors.LabelControl();
            this.splitContainerControl3 = new DevExpress.XtraEditors.SplitContainerControl();
            this.tbLayJdObat = new System.Windows.Forms.TableLayoutPanel();
            this.splitContainerControl2 = new DevExpress.XtraEditors.SplitContainerControl();
            this.panel16 = new System.Windows.Forms.Panel();
            this.btnSaveCppt = new DevExpress.XtraEditors.SimpleButton();
            this.btnAddCppt = new DevExpress.XtraEditors.SimpleButton();
            this.gcCppt = new DevExpress.XtraGrid.GridControl();
            this.gvCppt = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpDatex = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.txJamx = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpKodePpa = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.gridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn18 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.panel17 = new System.Windows.Forms.Panel();
            this.splitContainerControl4 = new DevExpress.XtraEditors.SplitContainerControl();
            this.btnSimpanObat = new DevExpress.XtraEditors.SimpleButton();
            this.btnAddJadwalObat = new DevExpress.XtraEditors.SimpleButton();
            this.gcJadwalObat = new DevExpress.XtraGrid.GridControl();
            this.gvJadwalObat = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.cbJnisObaT = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpDate = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpTimetx = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.panel7 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.splitContainerControl5 = new DevExpress.XtraEditors.SplitContainerControl();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btnSaveV = new DevExpress.XtraEditors.SimpleButton();
            this.btnAddVt = new DevExpress.XtraEditors.SimpleButton();
            this.gcVt = new DevExpress.XtraGrid.GridControl();
            this.gvVt = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn24 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn25 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpDateVx = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.gridColumn26 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.rpTxShu = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.gridColumn27 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.panel9 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel12 = new System.Windows.Forms.TableLayoutPanel();
            this.chrVital = new DevExpress.XtraCharts.ChartControl();
            this.labelControl98 = new DevExpress.XtraEditors.LabelControl();
            this.pnlAsGizi = new System.Windows.Forms.Panel();
            this.xtraScrollableControl6 = new DevExpress.XtraEditors.XtraScrollableControl();
            this.panel20 = new System.Windows.Forms.Panel();
            this.labelControl75 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl79 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl77 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl73 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl70 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl51 = new DevExpress.XtraEditors.LabelControl();
            this.txMonitoring = new DevExpress.XtraEditors.TextEdit();
            this.txIntrvnsiGz = new DevExpress.XtraEditors.TextEdit();
            this.txDiagnosGz = new DevExpress.XtraEditors.TextEdit();
            this.txRiwytPerson = new DevExpress.XtraEditors.TextEdit();
            this.labelControl90 = new DevExpress.XtraEditors.LabelControl();
            this.txAsupnLbh = new DevExpress.XtraEditors.TextEdit();
            this.labelControl89 = new DevExpress.XtraEditors.LabelControl();
            this.txAsupnKurng = new DevExpress.XtraEditors.TextEdit();
            this.labelControl88 = new DevExpress.XtraEditors.LabelControl();
            this.txPolaMkn = new DevExpress.XtraEditors.TextEdit();
            this.labelControl87 = new DevExpress.XtraEditors.LabelControl();
            this.txAlergiMkn = new DevExpress.XtraEditors.TextEdit();
            this.labelControl86 = new DevExpress.XtraEditors.LabelControl();
            this.txBiokimia = new DevExpress.XtraEditors.TextEdit();
            this.labelControl44 = new DevExpress.XtraEditors.LabelControl();
            this.txKlinis = new DevExpress.XtraEditors.TextEdit();
            this.labelControl85 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl45 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl46 = new DevExpress.XtraEditors.LabelControl();
            this.txImtDw = new DevExpress.XtraEditors.TextEdit();
            this.txKbthnKarbo = new DevExpress.XtraEditors.TextEdit();
            this.txKbthnLemak = new DevExpress.XtraEditors.TextEdit();
            this.txKbthnProtein = new DevExpress.XtraEditors.TextEdit();
            this.txKbthnEnergi = new DevExpress.XtraEditors.TextEdit();
            this.txPercenKarbo = new DevExpress.XtraEditors.TextEdit();
            this.txNilaiKarbo = new DevExpress.XtraEditors.TextEdit();
            this.txPercenLemak = new DevExpress.XtraEditors.TextEdit();
            this.txNilaiLemak = new DevExpress.XtraEditors.TextEdit();
            this.txPercenProtein = new DevExpress.XtraEditors.TextEdit();
            this.txNilaiProtein = new DevExpress.XtraEditors.TextEdit();
            this.txPercenEnergi = new DevExpress.XtraEditors.TextEdit();
            this.txNlaiEnergi = new DevExpress.XtraEditors.TextEdit();
            this.txBBU = new DevExpress.XtraEditors.TextEdit();
            this.txTgLutut = new DevExpress.XtraEditors.TextEdit();
            this.txBBTB = new DevExpress.XtraEditors.TextEdit();
            this.txBbDw = new DevExpress.XtraEditors.TextEdit();
            this.txImtAnk = new DevExpress.XtraEditors.TextEdit();
            this.txTbDw = new DevExpress.XtraEditors.TextEdit();
            this.txLilaDw = new DevExpress.XtraEditors.TextEdit();
            this.labelControl78 = new DevExpress.XtraEditors.LabelControl();
            this.txStsGizi = new DevExpress.XtraEditors.TextEdit();
            this.labelControl37 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl39 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl43 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl42 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl41 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl40 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl65 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl74 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl91 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl84 = new DevExpress.XtraEditors.LabelControl();
            this.txBbi = new DevExpress.XtraEditors.TextEdit();
            this.labelControl83 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl76 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl82 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl72 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl71 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl69 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl67 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl68 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl80 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl81 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl92 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl36 = new DevExpress.XtraEditors.LabelControl();
            this.tab3 = new DevExpress.XtraTab.XtraTabPage();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.tab1 = new DevExpress.XtraTab.XtraTabPage();
            this.formLayout = new System.Windows.Forms.TableLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.frmLayout1 = new System.Windows.Forms.TableLayoutPanel();
            this.layout123 = new System.Windows.Forms.TableLayoutPanel();
            this.gbRwObat = new System.Windows.Forms.GroupBox();
            this.txRiwayatObat = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.rgRiwayatObat = new DevExpress.XtraEditors.RadioGroup();
            this.g1 = new System.Windows.Forms.GroupBox();
            this.mmKeluhan = new DevExpress.XtraEditors.MemoEdit();
            this.g2 = new System.Windows.Forms.GroupBox();
            this.xtraScrollableControl1 = new DevExpress.XtraEditors.XtraScrollableControl();
            this.gbPernahDirawat = new System.Windows.Forms.GroupBox();
            this.txRawatDi = new System.Windows.Forms.TextBox();
            this.txKapanRawat = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.rgPernahRawat = new DevExpress.XtraEditors.RadioGroup();
            this.txDiagnosa = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.gbRwkerja = new System.Windows.Forms.GroupBox();
            this.txRwytKerja = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.rgRiwayatKerja = new DevExpress.XtraEditors.RadioGroup();
            this.gbRwAlergi = new System.Windows.Forms.GroupBox();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.txAlergi = new System.Windows.Forms.TextBox();
            this.rgAlergi = new DevExpress.XtraEditors.RadioGroup();
            this.txLain2 = new System.Windows.Forms.CheckBox();
            this.checkBox22 = new System.Windows.Forms.CheckBox();
            this.gbTergantungThdp = new System.Windows.Forms.GroupBox();
            this.txketergantungan = new System.Windows.Forms.TextBox();
            this.checkBox19 = new System.Windows.Forms.CheckBox();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.rgKetergantungan = new DevExpress.XtraEditors.RadioGroup();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.gbRwSakitKlrg = new System.Windows.Forms.GroupBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.txSakitKlrga = new System.Windows.Forms.TextBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.rgRwSktKlrg = new DevExpress.XtraEditors.RadioGroup();
            this.checkBox28 = new System.Windows.Forms.CheckBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.gbPernahOperasi = new System.Windows.Forms.GroupBox();
            this.rgPrnhOperasi = new DevExpress.XtraEditors.RadioGroup();
            this.txJnsOperasi = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.gbRwPenyakitlalu = new System.Windows.Forms.GroupBox();
            this.rgSakitLalu = new DevExpress.XtraEditors.RadioGroup();
            this.txSakitLalu = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.Scroll2 = new DevExpress.XtraEditors.XtraScrollableControl();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.rgPeriksaKhusus = new DevExpress.XtraEditors.RadioGroup();
            this.txPeriksaFisik = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.ckLokasiLuka = new System.Windows.Forms.CheckedListBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.txP = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.txSuhu = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.pnlKulit = new System.Windows.Forms.Panel();
            this.txKulitDtl = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.rgKulit = new DevExpress.XtraEditors.RadioGroup();
            this.label64 = new System.Windows.Forms.Label();
            this.pnlDekubitus = new System.Windows.Forms.Panel();
            this.txSkorNorton = new System.Windows.Forms.TextBox();
            this.label63 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.rbDekubitus = new DevExpress.XtraEditors.RadioGroup();
            this.label66 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.pnlMiksi = new System.Windows.Forms.Panel();
            this.txMiksiDtl = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.rgMiksi = new DevExpress.XtraEditors.RadioGroup();
            this.label58 = new System.Windows.Forms.Label();
            this.pnlDefekasi = new System.Windows.Forms.Panel();
            this.txDefekasiDtl = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.rgDefekasi = new DevExpress.XtraEditors.RadioGroup();
            this.label60 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.pnlPenglihatan = new System.Windows.Forms.Panel();
            this.txPnglihtDtl = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.rgPenglihatan = new DevExpress.XtraEditors.RadioGroup();
            this.label56 = new System.Windows.Forms.Label();
            this.pnlPendengaran = new System.Windows.Forms.Panel();
            this.txPdngrDtl = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.rgPendengaran = new DevExpress.XtraEditors.RadioGroup();
            this.label67 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txImt = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.txGstKet = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.txTbPb = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.txBB = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.pnlBatasMakan = new System.Windows.Forms.Panel();
            this.label45 = new System.Windows.Forms.Label();
            this.txBtsMakan = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.pnlMuntah = new System.Windows.Forms.Panel();
            this.rgMuntah = new DevExpress.XtraEditors.RadioGroup();
            this.label49 = new System.Windows.Forms.Label();
            this.pnlMual = new System.Windows.Forms.Panel();
            this.rgMual = new DevExpress.XtraEditors.RadioGroup();
            this.label48 = new System.Windows.Forms.Label();
            this.pnlGigiPalsu = new System.Windows.Forms.Panel();
            this.rgGigiPalsu = new DevExpress.XtraEditors.RadioGroup();
            this.label47 = new System.Windows.Forms.Label();
            this.pnKeluhan = new System.Windows.Forms.Panel();
            this.txKeluhan = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.rgKeluhan = new DevExpress.XtraEditors.RadioGroup();
            this.label44 = new System.Windows.Forms.Label();
            this.txNadi = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.txTd = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.xtraScrollableControl3 = new DevExpress.XtraEditors.XtraScrollableControl();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.xtraScrollableControl2 = new DevExpress.XtraEditors.XtraScrollableControl();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.pnlTempatTinggal = new System.Windows.Forms.Panel();
            this.txTpTinggalDtl = new System.Windows.Forms.TextBox();
            this.rgTmpTinggal = new DevExpress.XtraEditors.RadioGroup();
            this.label73 = new System.Windows.Forms.Label();
            this.txTlpKerabat = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.txHubKerabat = new System.Windows.Forms.TextBox();
            this.label76 = new System.Windows.Forms.Label();
            this.txNmKerabat = new System.Windows.Forms.TextBox();
            this.label77 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.rgHubKluarga = new DevExpress.XtraEditors.RadioGroup();
            this.label72 = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.txStsMental3 = new System.Windows.Forms.TextBox();
            this.txStsMental2 = new System.Windows.Forms.TextBox();
            this.chkStasMental3 = new System.Windows.Forms.CheckBox();
            this.chkStsMental2 = new System.Windows.Forms.CheckBox();
            this.ckStsMental1 = new System.Windows.Forms.CheckBox();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.txkegSpirit = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.txkegAgama = new System.Windows.Forms.TextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.gbStsPsikologi = new System.Windows.Forms.GroupBox();
            this.checkBox32 = new System.Windows.Forms.CheckBox();
            this.checkBox33 = new System.Windows.Forms.CheckBox();
            this.checkBox34 = new System.Windows.Forms.CheckBox();
            this.checkBox35 = new System.Windows.Forms.CheckBox();
            this.chkEtc5 = new System.Windows.Forms.CheckBox();
            this.checkBox36 = new System.Windows.Forms.CheckBox();
            this.txStsPsikologi = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.checkBox27 = new System.Windows.Forms.CheckBox();
            this.checkBox26 = new System.Windows.Forms.CheckBox();
            this.checkBox23 = new System.Windows.Forms.CheckBox();
            this.checkBox24 = new System.Windows.Forms.CheckBox();
            this.checkBox25 = new System.Windows.Forms.CheckBox();
            this.checkBox21 = new System.Windows.Forms.CheckBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.xtraScrollableControl4 = new DevExpress.XtraEditors.XtraScrollableControl();
            this.label96 = new System.Windows.Forms.Label();
            this.rgMnrimaInfo = new DevExpress.XtraEditors.RadioGroup();
            this.pnlButuhPnrjmh = new System.Windows.Forms.Panel();
            this.txPnrjmhDtl = new System.Windows.Forms.TextBox();
            this.rgPnrjemah = new DevExpress.XtraEditors.RadioGroup();
            this.label81 = new System.Windows.Forms.Label();
            this.pnlKbthnEdukasi = new System.Windows.Forms.Panel();
            this.txKbthnEdukasi = new System.Windows.Forms.TextBox();
            this.chkEtc12 = new System.Windows.Forms.CheckBox();
            this.txHmbtan = new System.Windows.Forms.TextBox();
            this.checkBox44 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.txSedia = new System.Windows.Forms.TextBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.pnlSedia = new System.Windows.Forms.Panel();
            this.checkBox42 = new System.Windows.Forms.CheckBox();
            this.checkBox43 = new System.Windows.Forms.CheckBox();
            this.checkBox41 = new System.Windows.Forms.CheckBox();
            this.rgSedia = new DevExpress.XtraEditors.RadioGroup();
            this.label84 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.gbResikoCedera = new System.Windows.Forms.GroupBox();
            this.label83 = new System.Windows.Forms.Label();
            this.rgResikoCedera = new DevExpress.XtraEditors.RadioGroup();
            this.gbHambatanBljr = new System.Windows.Forms.GroupBox();
            this.checkBox40 = new System.Windows.Forms.CheckBox();
            this.checkBox39 = new System.Windows.Forms.CheckBox();
            this.checkBox38 = new System.Windows.Forms.CheckBox();
            this.checkBox37 = new System.Windows.Forms.CheckBox();
            this.rgHmbtanBljr = new DevExpress.XtraEditors.RadioGroup();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSimpan = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.btnInputData = new System.Windows.Forms.Button();
            this.splitContainerControl1 = new DevExpress.XtraEditors.SplitContainerControl();
            this.panTbl = new System.Windows.Forms.Panel();
            this.grdMain = new DevExpress.XtraGrid.GridControl();
            this.gvwMain = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn28 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn29 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn30 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn31 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn32 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn33 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn34 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn35 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.mainTab = new DevExpress.XtraTab.XtraTabControl();
            this.tab2 = new DevExpress.XtraTab.XtraTabPage();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel13 = new System.Windows.Forms.TableLayoutPanel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.mmPerawat = new DevExpress.XtraEditors.MemoEdit();
            this.label88 = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.mmDokter = new DevExpress.XtraEditors.MemoEdit();
            this.label13 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.mmTujuanTerukur = new DevExpress.XtraEditors.MemoEdit();
            this.label90 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.chkSusunRencana = new System.Windows.Forms.CheckBox();
            this.pnlRisikoJatuh = new System.Windows.Forms.Panel();
            this.pnlRJAnak = new System.Windows.Forms.Panel();
            this.xtraScrollableControl7 = new DevExpress.XtraEditors.XtraScrollableControl();
            this.panel22 = new System.Windows.Forms.Panel();
            this.labelControl101 = new DevExpress.XtraEditors.LabelControl();
            this.txResikoAnak = new System.Windows.Forms.Label();
            this.txScoreAnak = new System.Windows.Forms.Label();
            this.rgJenkel = new DevExpress.XtraEditors.RadioGroup();
            this.rgSedasiAnestesi = new DevExpress.XtraEditors.RadioGroup();
            this.rgGangguan = new DevExpress.XtraEditors.RadioGroup();
            this.labelControl32 = new DevExpress.XtraEditors.LabelControl();
            this.rguseObat = new DevExpress.XtraEditors.RadioGroup();
            this.labelControl30 = new DevExpress.XtraEditors.LabelControl();
            this.rgFlingkungan = new DevExpress.XtraEditors.RadioGroup();
            this.labelControl31 = new DevExpress.XtraEditors.LabelControl();
            this.rgDiagnosis = new DevExpress.XtraEditors.RadioGroup();
            this.labelControl29 = new DevExpress.XtraEditors.LabelControl();
            this.rgUsia = new DevExpress.XtraEditors.RadioGroup();
            this.labelControl28 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl27 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.pnlRJDewasa = new System.Windows.Forms.Panel();
            this.xScrolJatuhDwasa = new DevExpress.XtraEditors.XtraScrollableControl();
            this.panel21 = new System.Windows.Forms.Panel();
            this.txResikoDewasa = new DevExpress.XtraEditors.LabelControl();
            this.lblTindakan = new DevExpress.XtraEditors.LabelControl();
            this.txTotalNilai = new System.Windows.Forms.Label();
            this.labelControl97 = new DevExpress.XtraEditors.LabelControl();
            this.pnlStsmental = new System.Windows.Forms.Panel();
            this.txket6 = new System.Windows.Forms.TextBox();
            this.rgstsMental = new DevExpress.XtraEditors.RadioGroup();
            this.pnlGayaJalan = new System.Windows.Forms.Panel();
            this.txKet5 = new System.Windows.Forms.TextBox();
            this.rgGayaJalan = new DevExpress.XtraEditors.RadioGroup();
            this.pnlInfus = new System.Windows.Forms.Panel();
            this.txket4 = new System.Windows.Forms.TextBox();
            this.rgInfus = new DevExpress.XtraEditors.RadioGroup();
            this.pnlLatBantuJalan = new System.Windows.Forms.Panel();
            this.txKet3 = new System.Windows.Forms.TextBox();
            this.rgAltBantuJalan = new DevExpress.XtraEditors.RadioGroup();
            this.pnlDiagnosaSekunder = new System.Windows.Forms.Panel();
            this.txKet2 = new System.Windows.Forms.TextBox();
            this.rgDiagnosaSekunder = new DevExpress.XtraEditors.RadioGroup();
            this.pnlRiwayatJatuh = new System.Windows.Forms.Panel();
            this.txKet1 = new System.Windows.Forms.TextBox();
            this.rgRiwayatJatuh = new DevExpress.XtraEditors.RadioGroup();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.panel12 = new System.Windows.Forms.Panel();
            this.btnSaveX = new DevExpress.XtraEditors.SimpleButton();
            this.rgKatgriPasien = new DevExpress.XtraEditors.RadioGroup();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl100 = new DevExpress.XtraEditors.LabelControl();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.gbStsFungsi = new System.Windows.Forms.GroupBox();
            this.txAltBantujalan = new System.Windows.Forms.TextBox();
            this.txMobilisasiDtl = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.rgMobilisasi = new DevExpress.XtraEditors.RadioGroup();
            this.label95 = new System.Windows.Forms.Label();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.xtraScrollableControl10 = new DevExpress.XtraEditors.XtraScrollableControl();
            this.pnlSkalaNyeri = new System.Windows.Forms.Panel();
            this.labelControl99 = new DevExpress.XtraEditors.LabelControl();
            this.chkSkalaNyeri = new System.Windows.Forms.CheckedListBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txScorNyeri = new System.Windows.Forms.TextBox();
            this.label87 = new System.Windows.Forms.Label();
            this.txDurasiNyeri = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txFrekuensi = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txLokasiNyeri = new System.Windows.Forms.TextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.rgTingkatNyeri = new DevExpress.XtraEditors.RadioGroup();
            this.label12 = new System.Windows.Forms.Label();
            this.gbNyeriHilang = new System.Windows.Forms.GroupBox();
            this.txNyeriHilang = new System.Windows.Forms.TextBox();
            this.chkEtc7 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.rgNyeri = new DevExpress.XtraEditors.RadioGroup();
            this.xtraScrollableControl5 = new DevExpress.XtraEditors.XtraScrollableControl();
            this.labelControl95 = new DevExpress.XtraEditors.LabelControl();
            this.panel11 = new System.Windows.Forms.Panel();
            this.labelControl96 = new DevExpress.XtraEditors.LabelControl();
            this.pnlDiagnoseKhusus = new System.Windows.Forms.Panel();
            this.txDiagnoseDtl = new System.Windows.Forms.TextBox();
            this.checkBox53 = new System.Windows.Forms.CheckBox();
            this.checkBox52 = new System.Windows.Forms.CheckBox();
            this.checkBox51 = new System.Windows.Forms.CheckBox();
            this.checkBox50 = new System.Windows.Forms.CheckBox();
            this.checkBox48 = new System.Windows.Forms.CheckBox();
            this.checkBox47 = new System.Windows.Forms.CheckBox();
            this.checkBox46 = new System.Windows.Forms.CheckBox();
            this.label22 = new System.Windows.Forms.Label();
            this.checkBox54 = new System.Windows.Forms.CheckBox();
            this.chkEtc14 = new System.Windows.Forms.CheckBox();
            this.rgDiagnoseKh = new DevExpress.XtraEditors.RadioGroup();
            this.checkBox45 = new System.Windows.Forms.CheckBox();
            this.pnlLaporTim = new System.Windows.Forms.Panel();
            this.txLaporDtl = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.rgLapor_tr_Gizi = new DevExpress.XtraEditors.RadioGroup();
            this.pnlBeratBadan = new System.Windows.Forms.Panel();
            this.lebrtbadan = new DevExpress.XtraEditors.LookUpEdit();
            this.label20 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.rgTurunBB = new DevExpress.XtraEditors.RadioGroup();
            this.txScoreScrining = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.rgAsupanMakan = new DevExpress.XtraEditors.RadioGroup();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tab5.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.pnlPulang1.SuspendLayout();
            this.scrolPulang.SuspendLayout();
            this.xtraScrollableControl8.SuspendLayout();
            this.xtraScrollableControl12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txAltTerpsang.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txKeadaanDtl.Properties)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txDoc3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txDoc5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txDoc6.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txDoc4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txDoc2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txDoc1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcObtPlng)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvObtPlng)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txObatRutin.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgRawatLanjutan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txWaktu.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txdoRawat.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txKebiasaanlain.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txDokterDituju.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txTindakan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txPsikologis.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txProcedurePlan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txControlLanjutan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txProcRawat.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txUnitKesehatan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txPolaMakan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txAktivitas.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txjenisPeriksa.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtkeluar.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtkeluar.Properties)).BeginInit();
            this.panel14.SuspendLayout();
            this.xtraScrollableControl9.SuspendLayout();
            this.xtraScrollableControl11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txAnjuran.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mmPeriksaFisik.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txAnamesa.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txTerapiLanjtan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txTindakanDo.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txPengobatan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txDiagnosaAkhir.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txDokterKonsultan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txDokterPengirim.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtKeluarx.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtKeluarx.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl3)).BeginInit();
            this.splitContainerControl3.SuspendLayout();
            this.tbLayJdObat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl2)).BeginInit();
            this.splitContainerControl2.SuspendLayout();
            this.panel16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcCppt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvCppt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpDatex)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpDatex.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txJamx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpKodePpa)).BeginInit();
            this.panel17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl4)).BeginInit();
            this.splitContainerControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcJadwalObat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvJadwalObat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbJnisObaT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpDate.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpTimetx)).BeginInit();
            this.panel7.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl5)).BeginInit();
            this.splitContainerControl5.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcVt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvVt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpDateVx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpDateVx.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpTxShu)).BeginInit();
            this.panel9.SuspendLayout();
            this.tableLayoutPanel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chrVital)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(xyDiagram1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(pointSeriesLabel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(lineSeriesView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(pointSeriesLabel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(lineSeriesView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(pointSeriesLabel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(lineSeriesView3)).BeginInit();
            this.pnlAsGizi.SuspendLayout();
            this.xtraScrollableControl6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txMonitoring.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txIntrvnsiGz.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txDiagnosGz.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txRiwytPerson.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txAsupnLbh.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txAsupnKurng.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txPolaMkn.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txAlergiMkn.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txBiokimia.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txKlinis.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txImtDw.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txKbthnKarbo.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txKbthnLemak.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txKbthnProtein.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txKbthnEnergi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txPercenKarbo.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txNilaiKarbo.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txPercenLemak.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txNilaiLemak.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txPercenProtein.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txNilaiProtein.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txPercenEnergi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txNlaiEnergi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txBBU.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txTgLutut.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txBBTB.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txBbDw.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txImtAnk.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txTbDw.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txLilaDw.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txStsGizi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txBbi.Properties)).BeginInit();
            this.tab3.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tab1.SuspendLayout();
            this.formLayout.SuspendLayout();
            this.panel3.SuspendLayout();
            this.frmLayout1.SuspendLayout();
            this.layout123.SuspendLayout();
            this.gbRwObat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgRiwayatObat.Properties)).BeginInit();
            this.g1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mmKeluhan.Properties)).BeginInit();
            this.g2.SuspendLayout();
            this.xtraScrollableControl1.SuspendLayout();
            this.gbPernahDirawat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgPernahRawat.Properties)).BeginInit();
            this.gbRwkerja.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgRiwayatKerja.Properties)).BeginInit();
            this.gbRwAlergi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgAlergi.Properties)).BeginInit();
            this.gbTergantungThdp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgKetergantungan.Properties)).BeginInit();
            this.gbRwSakitKlrg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgRwSktKlrg.Properties)).BeginInit();
            this.gbPernahOperasi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgPrnhOperasi.Properties)).BeginInit();
            this.gbRwPenyakitlalu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgSakitLalu.Properties)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.Scroll2.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgPeriksaKhusus.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.groupBox10.SuspendLayout();
            this.pnlKulit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgKulit.Properties)).BeginInit();
            this.pnlDekubitus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rbDekubitus.Properties)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.pnlMiksi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgMiksi.Properties)).BeginInit();
            this.pnlDefekasi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgDefekasi.Properties)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.pnlPenglihatan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgPenglihatan.Properties)).BeginInit();
            this.pnlPendengaran.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgPendengaran.Properties)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.pnlBatasMakan.SuspendLayout();
            this.pnlMuntah.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgMuntah.Properties)).BeginInit();
            this.pnlMual.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgMual.Properties)).BeginInit();
            this.pnlGigiPalsu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgGigiPalsu.Properties)).BeginInit();
            this.pnKeluhan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgKeluhan.Properties)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            this.xtraScrollableControl3.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.xtraScrollableControl2.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.pnlTempatTinggal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgTmpTinggal.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgHubKluarga.Properties)).BeginInit();
            this.groupBox14.SuspendLayout();
            this.groupBox25.SuspendLayout();
            this.gbStsPsikologi.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.xtraScrollableControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgMnrimaInfo.Properties)).BeginInit();
            this.pnlButuhPnrjmh.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgPnrjemah.Properties)).BeginInit();
            this.pnlKbthnEdukasi.SuspendLayout();
            this.pnlSedia.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgSedia.Properties)).BeginInit();
            this.gbResikoCedera.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgResikoCedera.Properties)).BeginInit();
            this.gbHambatanBljr.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgHmbtanBljr.Properties)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).BeginInit();
            this.splitContainerControl1.SuspendLayout();
            this.panTbl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvwMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mainTab)).BeginInit();
            this.mainTab.SuspendLayout();
            this.tab2.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.tableLayoutPanel13.SuspendLayout();
            this.panel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mmPerawat.Properties)).BeginInit();
            this.panel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mmDokter.Properties)).BeginInit();
            this.panel19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mmTujuanTerukur.Properties)).BeginInit();
            this.panel13.SuspendLayout();
            this.pnlRisikoJatuh.SuspendLayout();
            this.pnlRJAnak.SuspendLayout();
            this.xtraScrollableControl7.SuspendLayout();
            this.panel22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgJenkel.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgSedasiAnestesi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgGangguan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rguseObat.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgFlingkungan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgDiagnosis.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgUsia.Properties)).BeginInit();
            this.pnlRJDewasa.SuspendLayout();
            this.xScrolJatuhDwasa.SuspendLayout();
            this.panel21.SuspendLayout();
            this.pnlStsmental.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgstsMental.Properties)).BeginInit();
            this.pnlGayaJalan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgGayaJalan.Properties)).BeginInit();
            this.pnlInfus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgInfus.Properties)).BeginInit();
            this.pnlLatBantuJalan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgAltBantuJalan.Properties)).BeginInit();
            this.pnlDiagnosaSekunder.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgDiagnosaSekunder.Properties)).BeginInit();
            this.pnlRiwayatJatuh.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgRiwayatJatuh.Properties)).BeginInit();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgKatgriPasien.Properties)).BeginInit();
            this.tableLayoutPanel6.SuspendLayout();
            this.gbStsFungsi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgMobilisasi.Properties)).BeginInit();
            this.groupBox16.SuspendLayout();
            this.xtraScrollableControl10.SuspendLayout();
            this.pnlSkalaNyeri.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgTingkatNyeri.Properties)).BeginInit();
            this.gbNyeriHilang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgNyeri.Properties)).BeginInit();
            this.xtraScrollableControl5.SuspendLayout();
            this.panel11.SuspendLayout();
            this.pnlDiagnoseKhusus.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgDiagnoseKh.Properties)).BeginInit();
            this.pnlLaporTim.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgLapor_tr_Gizi.Properties)).BeginInit();
            this.pnlBeratBadan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lebrtbadan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgTurunBB.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgAsupanMakan.Properties)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tab5
            // 
            this.tab5.Controls.Add(this.tableLayoutPanel8);
            this.tab5.Name = "tab5";
            this.tab5.Size = new System.Drawing.Size(1252, 485);
            this.tab5.Text = "C. Perencanaan dan Resume Pulang";
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 2;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 56.23003F));
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.76997F));
            this.tableLayoutPanel8.Controls.Add(this.pnlPulang1, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.panel14, 1, 0);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 1;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(1252, 485);
            this.tableLayoutPanel8.TabIndex = 0;
            // 
            // pnlPulang1
            // 
            this.pnlPulang1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlPulang1.Controls.Add(this.scrolPulang);
            this.pnlPulang1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPulang1.Location = new System.Drawing.Point(3, 3);
            this.pnlPulang1.Name = "pnlPulang1";
            this.pnlPulang1.Size = new System.Drawing.Size(697, 479);
            this.pnlPulang1.TabIndex = 0;
            // 
            // scrolPulang
            // 
            this.scrolPulang.Controls.Add(this.xtraScrollableControl8);
            this.scrolPulang.Controls.Add(this.labelControl26);
            this.scrolPulang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.scrolPulang.Location = new System.Drawing.Point(0, 0);
            this.scrolPulang.Name = "scrolPulang";
            this.scrolPulang.Size = new System.Drawing.Size(695, 477);
            this.scrolPulang.TabIndex = 3;
            // 
            // xtraScrollableControl8
            // 
            this.xtraScrollableControl8.Controls.Add(this.xtraScrollableControl12);
            this.xtraScrollableControl8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraScrollableControl8.Location = new System.Drawing.Point(0, 30);
            this.xtraScrollableControl8.Name = "xtraScrollableControl8";
            this.xtraScrollableControl8.Size = new System.Drawing.Size(695, 447);
            this.xtraScrollableControl8.TabIndex = 211;
            // 
            // xtraScrollableControl12
            // 
            this.xtraScrollableControl12.Controls.Add(this.txAltTerpsang);
            this.xtraScrollableControl12.Controls.Add(this.txKeadaanDtl);
            this.xtraScrollableControl12.Controls.Add(this.cbKeadaanPulang);
            this.xtraScrollableControl12.Controls.Add(this.addObat);
            this.xtraScrollableControl12.Controls.Add(this.panel5);
            this.xtraScrollableControl12.Controls.Add(this.labelControl10);
            this.xtraScrollableControl12.Controls.Add(this.labelControl38);
            this.xtraScrollableControl12.Controls.Add(this.lblKeadaan);
            this.xtraScrollableControl12.Controls.Add(this.labelControl12);
            this.xtraScrollableControl12.Controls.Add(this.cbAlatTerpasang);
            this.xtraScrollableControl12.Controls.Add(this.gcObtPlng);
            this.xtraScrollableControl12.Controls.Add(this.txObatRutin);
            this.xtraScrollableControl12.Controls.Add(this.rgRawatLanjutan);
            this.xtraScrollableControl12.Controls.Add(this.labelControl14);
            this.xtraScrollableControl12.Controls.Add(this.labelControl15);
            this.xtraScrollableControl12.Controls.Add(this.labelControl16);
            this.xtraScrollableControl12.Controls.Add(this.labelControl47);
            this.xtraScrollableControl12.Controls.Add(this.labelControl48);
            this.xtraScrollableControl12.Controls.Add(this.labelControl49);
            this.xtraScrollableControl12.Controls.Add(this.labelControl50);
            this.xtraScrollableControl12.Controls.Add(this.labelControl52);
            this.xtraScrollableControl12.Controls.Add(this.txWaktu);
            this.xtraScrollableControl12.Controls.Add(this.txdoRawat);
            this.xtraScrollableControl12.Controls.Add(this.txKebiasaanlain);
            this.xtraScrollableControl12.Controls.Add(this.txDokterDituju);
            this.xtraScrollableControl12.Controls.Add(this.txTindakan);
            this.xtraScrollableControl12.Controls.Add(this.txPsikologis);
            this.xtraScrollableControl12.Controls.Add(this.txProcedurePlan);
            this.xtraScrollableControl12.Controls.Add(this.txControlLanjutan);
            this.xtraScrollableControl12.Controls.Add(this.txProcRawat);
            this.xtraScrollableControl12.Controls.Add(this.txUnitKesehatan);
            this.xtraScrollableControl12.Controls.Add(this.txPolaMakan);
            this.xtraScrollableControl12.Controls.Add(this.txAktivitas);
            this.xtraScrollableControl12.Controls.Add(this.txjenisPeriksa);
            this.xtraScrollableControl12.Controls.Add(this.labelControl53);
            this.xtraScrollableControl12.Controls.Add(this.labelControl54);
            this.xtraScrollableControl12.Controls.Add(this.labelControl55);
            this.xtraScrollableControl12.Controls.Add(this.labelControl56);
            this.xtraScrollableControl12.Controls.Add(this.labelControl57);
            this.xtraScrollableControl12.Controls.Add(this.labelControl58);
            this.xtraScrollableControl12.Controls.Add(this.labelControl59);
            this.xtraScrollableControl12.Controls.Add(this.labelControl60);
            this.xtraScrollableControl12.Controls.Add(this.labelControl61);
            this.xtraScrollableControl12.Controls.Add(this.labelControl62);
            this.xtraScrollableControl12.Controls.Add(this.labelControl63);
            this.xtraScrollableControl12.Controls.Add(this.labelControl64);
            this.xtraScrollableControl12.Controls.Add(this.labelControl66);
            this.xtraScrollableControl12.Controls.Add(this.dtkeluar);
            this.xtraScrollableControl12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraScrollableControl12.Location = new System.Drawing.Point(0, 0);
            this.xtraScrollableControl12.Name = "xtraScrollableControl12";
            this.xtraScrollableControl12.Size = new System.Drawing.Size(695, 447);
            this.xtraScrollableControl12.TabIndex = 0;
            // 
            // txAltTerpsang
            // 
            this.txAltTerpsang.Enabled = false;
            this.txAltTerpsang.Location = new System.Drawing.Point(441, 53);
            this.txAltTerpsang.Name = "txAltTerpsang";
            this.txAltTerpsang.Properties.AutoHeight = false;
            this.txAltTerpsang.Size = new System.Drawing.Size(236, 21);
            this.txAltTerpsang.TabIndex = 5;
            // 
            // txKeadaanDtl
            // 
            this.txKeadaanDtl.Enabled = false;
            this.txKeadaanDtl.Location = new System.Drawing.Point(441, 29);
            this.txKeadaanDtl.Name = "txKeadaanDtl";
            this.txKeadaanDtl.Properties.AutoHeight = false;
            this.txKeadaanDtl.Size = new System.Drawing.Size(236, 21);
            this.txKeadaanDtl.TabIndex = 3;
            // 
            // cbKeadaanPulang
            // 
            this.cbKeadaanPulang.FormattingEnabled = true;
            this.cbKeadaanPulang.Items.AddRange(new object[] {
            "Sembuh",
            "Belum Sembuh Sempurna",
            "Rawat Jalan",
            "Rujuk/Alih Rawat",
            "Pulang Paksa",
            "Lainnya"});
            this.cbKeadaanPulang.Location = new System.Drawing.Point(199, 29);
            this.cbKeadaanPulang.Name = "cbKeadaanPulang";
            this.cbKeadaanPulang.Size = new System.Drawing.Size(183, 21);
            this.cbKeadaanPulang.TabIndex = 2;
            this.cbKeadaanPulang.SelectedValueChanged += new System.EventHandler(this.cbKeadaanPulang_SelectedValueChanged);
            // 
            // addObat
            // 
            this.addObat.Image = ((System.Drawing.Image)(resources.GetObject("addObat.Image")));
            this.addObat.Location = new System.Drawing.Point(603, 81);
            this.addObat.Name = "addObat";
            this.addObat.Size = new System.Drawing.Size(68, 20);
            this.addObat.TabIndex = 6;
            this.addObat.Text = "Tambah";
            this.addObat.Click += new System.EventHandler(this.addObat_Click);
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.chkDoc7);
            this.panel5.Controls.Add(this.chkDoc8);
            this.panel5.Controls.Add(this.chkDoc6);
            this.panel5.Controls.Add(this.chkDoc5);
            this.panel5.Controls.Add(this.chkDoc4);
            this.panel5.Controls.Add(this.chkDoc3);
            this.panel5.Controls.Add(this.chkDoc2);
            this.panel5.Controls.Add(this.chkDoc1);
            this.panel5.Controls.Add(this.txDoc3);
            this.panel5.Controls.Add(this.txDoc5);
            this.panel5.Controls.Add(this.txDoc6);
            this.panel5.Controls.Add(this.txDoc4);
            this.panel5.Controls.Add(this.txDoc2);
            this.panel5.Controls.Add(this.txDoc1);
            this.panel5.Controls.Add(this.labelControl4);
            this.panel5.Location = new System.Drawing.Point(4, 499);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(671, 106);
            this.panel5.TabIndex = 304;
            // 
            // chkDoc7
            // 
            this.chkDoc7.AutoSize = true;
            this.chkDoc7.Location = new System.Drawing.Point(588, 56);
            this.chkDoc7.Name = "chkDoc7";
            this.chkDoc7.Size = new System.Drawing.Size(69, 17);
            this.chkDoc7.TabIndex = 34;
            this.chkDoc7.Text = "Buku KIA";
            this.chkDoc7.UseVisualStyleBackColor = true;
            // 
            // chkDoc8
            // 
            this.chkDoc8.AutoSize = true;
            this.chkDoc8.Location = new System.Drawing.Point(378, 81);
            this.chkDoc8.Name = "chkDoc8";
            this.chkDoc8.Size = new System.Drawing.Size(147, 17);
            this.chkDoc8.TabIndex = 35;
            this.chkDoc8.Text = "Kartu peserta aseptor KB";
            this.chkDoc8.UseVisualStyleBackColor = true;
            // 
            // chkDoc6
            // 
            this.chkDoc6.AutoSize = true;
            this.chkDoc6.Location = new System.Drawing.Point(378, 56);
            this.chkDoc6.Name = "chkDoc6";
            this.chkDoc6.Size = new System.Drawing.Size(192, 17);
            this.chkDoc6.TabIndex = 33;
            this.chkDoc6.Text = "Surat keterangan dirawat/istirahat";
            this.chkDoc6.UseVisualStyleBackColor = true;
            // 
            // chkDoc5
            // 
            this.chkDoc5.AutoSize = true;
            this.chkDoc5.Location = new System.Drawing.Point(378, 5);
            this.chkDoc5.Name = "chkDoc5";
            this.chkDoc5.Size = new System.Drawing.Size(133, 17);
            this.chkDoc5.TabIndex = 24;
            this.chkDoc5.Text = "Surat rujukan, kepada";
            this.chkDoc5.UseVisualStyleBackColor = true;
            this.chkDoc5.CheckedChanged += new System.EventHandler(this.chkDoc5_CheckedChanged);
            // 
            // chkDoc4
            // 
            this.chkDoc4.AutoSize = true;
            this.chkDoc4.Location = new System.Drawing.Point(3, 79);
            this.chkDoc4.Name = "chkDoc4";
            this.chkDoc4.Size = new System.Drawing.Size(184, 17);
            this.chkDoc4.TabIndex = 31;
            this.chkDoc4.Text = "Hasil pemeriksaan Laboratorium :";
            this.chkDoc4.UseVisualStyleBackColor = true;
            this.chkDoc4.CheckedChanged += new System.EventHandler(this.chkDoc4_CheckedChanged);
            // 
            // chkDoc3
            // 
            this.chkDoc3.AutoSize = true;
            this.chkDoc3.Location = new System.Drawing.Point(3, 54);
            this.chkDoc3.Name = "chkDoc3";
            this.chkDoc3.Size = new System.Drawing.Size(161, 17);
            this.chkDoc3.TabIndex = 29;
            this.chkDoc3.Text = "Hasil pemeriksaan radiologi :";
            this.chkDoc3.UseVisualStyleBackColor = true;
            this.chkDoc3.CheckedChanged += new System.EventHandler(this.chkDoc3_CheckedChanged);
            // 
            // chkDoc2
            // 
            this.chkDoc2.AutoSize = true;
            this.chkDoc2.Location = new System.Drawing.Point(3, 32);
            this.chkDoc2.Name = "chkDoc2";
            this.chkDoc2.Size = new System.Drawing.Size(168, 17);
            this.chkDoc2.TabIndex = 26;
            this.chkDoc2.Text = "Surat pengantar Pemeriksaan";
            this.chkDoc2.UseVisualStyleBackColor = true;
            this.chkDoc2.CheckedChanged += new System.EventHandler(this.chkDoc2_CheckedChanged);
            // 
            // chkDoc1
            // 
            this.chkDoc1.AutoSize = true;
            this.chkDoc1.Location = new System.Drawing.Point(3, 7);
            this.chkDoc1.Name = "chkDoc1";
            this.chkDoc1.Size = new System.Drawing.Size(209, 17);
            this.chkDoc1.TabIndex = 22;
            this.chkDoc1.Text = "Surat keterangan Rawat Jalan, ke poli";
            this.chkDoc1.UseVisualStyleBackColor = true;
            this.chkDoc1.CheckedChanged += new System.EventHandler(this.chkDoc1_CheckedChanged);
            // 
            // txDoc3
            // 
            this.txDoc3.Enabled = false;
            this.txDoc3.Location = new System.Drawing.Point(426, 28);
            this.txDoc3.Name = "txDoc3";
            this.txDoc3.Size = new System.Drawing.Size(240, 20);
            this.txDoc3.TabIndex = 28;
            // 
            // txDoc5
            // 
            this.txDoc5.Enabled = false;
            this.txDoc5.Location = new System.Drawing.Point(194, 78);
            this.txDoc5.Name = "txDoc5";
            this.txDoc5.Size = new System.Drawing.Size(177, 20);
            this.txDoc5.TabIndex = 32;
            // 
            // txDoc6
            // 
            this.txDoc6.Enabled = false;
            this.txDoc6.Location = new System.Drawing.Point(517, 4);
            this.txDoc6.Name = "txDoc6";
            this.txDoc6.Size = new System.Drawing.Size(149, 20);
            this.txDoc6.TabIndex = 25;
            // 
            // txDoc4
            // 
            this.txDoc4.Enabled = false;
            this.txDoc4.Location = new System.Drawing.Point(177, 52);
            this.txDoc4.Name = "txDoc4";
            this.txDoc4.Size = new System.Drawing.Size(194, 20);
            this.txDoc4.TabIndex = 30;
            // 
            // txDoc2
            // 
            this.txDoc2.Enabled = false;
            this.txDoc2.Location = new System.Drawing.Point(177, 29);
            this.txDoc2.Name = "txDoc2";
            this.txDoc2.Size = new System.Drawing.Size(194, 20);
            this.txDoc2.TabIndex = 27;
            // 
            // txDoc1
            // 
            this.txDoc1.Enabled = false;
            this.txDoc1.Location = new System.Drawing.Point(217, 3);
            this.txDoc1.Name = "txDoc1";
            this.txDoc1.Size = new System.Drawing.Size(154, 20);
            this.txDoc1.TabIndex = 23;
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(377, 31);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(43, 13);
            this.labelControl4.TabIndex = 2;
            this.labelControl4.Text = "Kepada :";
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl10.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl10.Location = new System.Drawing.Point(382, 53);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl10.Size = new System.Drawing.Size(59, 21);
            this.labelControl10.TabIndex = 283;
            this.labelControl10.Text = "Lainnya";
            // 
            // labelControl38
            // 
            this.labelControl38.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl38.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl38.Location = new System.Drawing.Point(6, 6);
            this.labelControl38.Name = "labelControl38";
            this.labelControl38.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl38.Size = new System.Drawing.Size(97, 20);
            this.labelControl38.TabIndex = 281;
            this.labelControl38.Text = "Tanggal Keluar";
            // 
            // lblKeadaan
            // 
            this.lblKeadaan.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblKeadaan.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.lblKeadaan.Location = new System.Drawing.Point(382, 29);
            this.lblKeadaan.Name = "lblKeadaan";
            this.lblKeadaan.Padding = new System.Windows.Forms.Padding(3);
            this.lblKeadaan.Size = new System.Drawing.Size(59, 21);
            this.lblKeadaan.TabIndex = 282;
            this.lblKeadaan.Text = "Lainnya";
            // 
            // labelControl12
            // 
            this.labelControl12.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl12.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl12.Location = new System.Drawing.Point(6, 29);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(201, 21);
            this.labelControl12.TabIndex = 280;
            this.labelControl12.Text = "  Pulang dari klinik dengan keadaan :";
            // 
            // cbAlatTerpasang
            // 
            this.cbAlatTerpasang.FormattingEnabled = true;
            this.cbAlatTerpasang.Items.AddRange(new object[] {
            "Tidak Ada",
            "NGT",
            "DC",
            "IV Line",
            "Oksigen",
            "Lainnya"});
            this.cbAlatTerpasang.Location = new System.Drawing.Point(199, 53);
            this.cbAlatTerpasang.Name = "cbAlatTerpasang";
            this.cbAlatTerpasang.Size = new System.Drawing.Size(183, 21);
            this.cbAlatTerpasang.TabIndex = 4;
            this.cbAlatTerpasang.SelectedValueChanged += new System.EventHandler(this.cbAlatTerpasang_SelectedValueChanged);
            // 
            // gcObtPlng
            // 
            this.gcObtPlng.Location = new System.Drawing.Point(5, 77);
            this.gcObtPlng.MainView = this.gvObtPlng;
            this.gcObtPlng.Name = "gcObtPlng";
            this.gcObtPlng.Size = new System.Drawing.Size(672, 132);
            this.gcObtPlng.TabIndex = 301;
            this.gcObtPlng.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvObtPlng});
            this.gcObtPlng.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gcObtPlng_KeyDown);
            // 
            // gvObtPlng
            // 
            this.gvObtPlng.Appearance.ViewCaption.Options.UseTextOptions = true;
            this.gvObtPlng.Appearance.ViewCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.gvObtPlng.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn19,
            this.gridColumn20,
            this.gridColumn21,
            this.gridColumn22,
            this.gridColumn23});
            this.gvObtPlng.GridControl = this.gcObtPlng;
            this.gvObtPlng.Name = "gvObtPlng";
            this.gvObtPlng.OptionsView.ShowGroupPanel = false;
            this.gvObtPlng.OptionsView.ShowViewCaption = true;
            this.gvObtPlng.ViewCaption = "Obat yang harus dikonsumsi setelah pulang";
            this.gvObtPlng.ViewCaptionHeight = 30;
            // 
            // gridColumn19
            // 
            this.gridColumn19.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn19.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn19.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn19.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn19.Caption = "No";
            this.gridColumn19.FieldName = "SEQ";
            this.gridColumn19.Name = "gridColumn19";
            this.gridColumn19.Visible = true;
            this.gridColumn19.VisibleIndex = 0;
            this.gridColumn19.Width = 63;
            // 
            // gridColumn20
            // 
            this.gridColumn20.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn20.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn20.Caption = "Nama Obat";
            this.gridColumn20.FieldName = "NAMA_OBAT";
            this.gridColumn20.Name = "gridColumn20";
            this.gridColumn20.Visible = true;
            this.gridColumn20.VisibleIndex = 1;
            this.gridColumn20.Width = 377;
            // 
            // gridColumn21
            // 
            this.gridColumn21.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn21.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn21.Caption = "DOSIS";
            this.gridColumn21.FieldName = "DOSIS";
            this.gridColumn21.Name = "gridColumn21";
            this.gridColumn21.Visible = true;
            this.gridColumn21.VisibleIndex = 2;
            this.gridColumn21.Width = 416;
            // 
            // gridColumn22
            // 
            this.gridColumn22.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn22.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn22.Caption = "Waktu Pemberian";
            this.gridColumn22.FieldName = "WAKTU_BERI";
            this.gridColumn22.Name = "gridColumn22";
            this.gridColumn22.Visible = true;
            this.gridColumn22.VisibleIndex = 3;
            this.gridColumn22.Width = 325;
            // 
            // gridColumn23
            // 
            this.gridColumn23.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn23.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn23.Caption = "Cara Pemeberian";
            this.gridColumn23.FieldName = "CARA";
            this.gridColumn23.Name = "gridColumn23";
            this.gridColumn23.Visible = true;
            this.gridColumn23.VisibleIndex = 4;
            this.gridColumn23.Width = 451;
            // 
            // txObatRutin
            // 
            this.txObatRutin.Location = new System.Drawing.Point(233, 212);
            this.txObatRutin.Name = "txObatRutin";
            this.txObatRutin.Size = new System.Drawing.Size(211, 20);
            this.txObatRutin.TabIndex = 7;
            // 
            // rgRawatLanjutan
            // 
            this.rgRawatLanjutan.Location = new System.Drawing.Point(255, 340);
            this.rgRawatLanjutan.Name = "rgRawatLanjutan";
            this.rgRawatLanjutan.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgRawatLanjutan.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(null, "DC", true, 0),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(1, "NGT"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(2, "Luka")});
            this.rgRawatLanjutan.Size = new System.Drawing.Size(144, 22);
            this.rgRawatLanjutan.TabIndex = 14;
            // 
            // labelControl14
            // 
            this.labelControl14.Location = new System.Drawing.Point(6, 480);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(150, 13);
            this.labelControl14.TabIndex = 274;
            this.labelControl14.Text = "Dokumen yang dibawa pulang :";
            // 
            // labelControl15
            // 
            this.labelControl15.Location = new System.Drawing.Point(5, 435);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(86, 13);
            this.labelControl15.TabIndex = 273;
            this.labelControl15.Text = "Kontrol Lanjutan :";
            // 
            // labelControl16
            // 
            this.labelControl16.Location = new System.Drawing.Point(6, 390);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(344, 13);
            this.labelControl16.TabIndex = 272;
            this.labelControl16.Text = "Saran atau tindakan yang dilakukan jika terjadi keadaan gawat darurat:";
            // 
            // labelControl47
            // 
            this.labelControl47.Location = new System.Drawing.Point(8, 344);
            this.labelControl47.Name = "labelControl47";
            this.labelControl47.Size = new System.Drawing.Size(250, 13);
            this.labelControl47.TabIndex = 271;
            this.labelControl47.Text = "Petunjuk perawatan lanjutan yang harus dilakukan :";
            // 
            // labelControl48
            // 
            this.labelControl48.Location = new System.Drawing.Point(6, 275);
            this.labelControl48.Name = "labelControl48";
            this.labelControl48.Size = new System.Drawing.Size(222, 13);
            this.labelControl48.TabIndex = 270;
            this.labelControl48.Text = "Perubahan gaya hidup yang harus di lakukan :";
            // 
            // labelControl49
            // 
            this.labelControl49.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.labelControl49.Location = new System.Drawing.Point(7, 230);
            this.labelControl49.Name = "labelControl49";
            this.labelControl49.Size = new System.Drawing.Size(189, 13);
            this.labelControl49.TabIndex = 269;
            this.labelControl49.Text = "Pemeriksaan lanjutan yang dianjurkan :";
            // 
            // labelControl50
            // 
            this.labelControl50.Location = new System.Drawing.Point(6, 214);
            this.labelControl50.Name = "labelControl50";
            this.labelControl50.Size = new System.Drawing.Size(225, 13);
            this.labelControl50.TabIndex = 268;
            this.labelControl50.Text = "Obat rutin yang diberhentikan pemberiannya : ";
            // 
            // labelControl52
            // 
            this.labelControl52.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl52.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl52.Location = new System.Drawing.Point(6, 53);
            this.labelControl52.Name = "labelControl52";
            this.labelControl52.Size = new System.Drawing.Size(201, 21);
            this.labelControl52.TabIndex = 267;
            this.labelControl52.Text = "  Alat yang terpasang saat pulang  :";
            // 
            // txWaktu
            // 
            this.txWaktu.Location = new System.Drawing.Point(574, 364);
            this.txWaktu.Name = "txWaktu";
            this.txWaktu.Size = new System.Drawing.Size(102, 20);
            this.txWaktu.TabIndex = 17;
            // 
            // txdoRawat
            // 
            this.txdoRawat.Location = new System.Drawing.Point(336, 364);
            this.txdoRawat.Name = "txdoRawat";
            this.txdoRawat.Size = new System.Drawing.Size(154, 20);
            this.txdoRawat.TabIndex = 16;
            // 
            // txKebiasaanlain
            // 
            this.txKebiasaanlain.Location = new System.Drawing.Point(465, 317);
            this.txKebiasaanlain.Name = "txKebiasaanlain";
            this.txKebiasaanlain.Size = new System.Drawing.Size(212, 20);
            this.txKebiasaanlain.TabIndex = 13;
            // 
            // txDokterDituju
            // 
            this.txDokterDituju.Location = new System.Drawing.Point(481, 454);
            this.txDokterDituju.Name = "txDokterDituju";
            this.txDokterDituju.Size = new System.Drawing.Size(196, 20);
            this.txDokterDituju.TabIndex = 21;
            // 
            // txTindakan
            // 
            this.txTindakan.Location = new System.Drawing.Point(481, 409);
            this.txTindakan.Name = "txTindakan";
            this.txTindakan.Size = new System.Drawing.Size(195, 20);
            this.txTindakan.TabIndex = 19;
            // 
            // txPsikologis
            // 
            this.txPsikologis.Location = new System.Drawing.Point(465, 294);
            this.txPsikologis.Name = "txPsikologis";
            this.txPsikologis.Size = new System.Drawing.Size(212, 20);
            this.txPsikologis.TabIndex = 11;
            // 
            // txProcedurePlan
            // 
            this.txProcedurePlan.Location = new System.Drawing.Point(465, 249);
            this.txProcedurePlan.Name = "txProcedurePlan";
            this.txProcedurePlan.Size = new System.Drawing.Size(212, 20);
            this.txProcedurePlan.TabIndex = 9;
            // 
            // txControlLanjutan
            // 
            this.txControlLanjutan.Location = new System.Drawing.Point(135, 454);
            this.txControlLanjutan.Name = "txControlLanjutan";
            this.txControlLanjutan.Size = new System.Drawing.Size(223, 20);
            this.txControlLanjutan.TabIndex = 20;
            // 
            // txProcRawat
            // 
            this.txProcRawat.Location = new System.Drawing.Point(62, 364);
            this.txProcRawat.Name = "txProcRawat";
            this.txProcRawat.Size = new System.Drawing.Size(184, 20);
            this.txProcRawat.TabIndex = 15;
            // 
            // txUnitKesehatan
            // 
            this.txUnitKesehatan.Location = new System.Drawing.Point(135, 409);
            this.txUnitKesehatan.Name = "txUnitKesehatan";
            this.txUnitKesehatan.Size = new System.Drawing.Size(223, 20);
            this.txUnitKesehatan.TabIndex = 18;
            // 
            // txPolaMakan
            // 
            this.txPolaMakan.Location = new System.Drawing.Point(139, 317);
            this.txPolaMakan.Name = "txPolaMakan";
            this.txPolaMakan.Size = new System.Drawing.Size(223, 20);
            this.txPolaMakan.TabIndex = 12;
            // 
            // txAktivitas
            // 
            this.txAktivitas.Location = new System.Drawing.Point(139, 294);
            this.txAktivitas.Name = "txAktivitas";
            this.txAktivitas.Size = new System.Drawing.Size(223, 20);
            this.txAktivitas.TabIndex = 10;
            // 
            // txjenisPeriksa
            // 
            this.txjenisPeriksa.Location = new System.Drawing.Point(139, 249);
            this.txjenisPeriksa.Name = "txjenisPeriksa";
            this.txjenisPeriksa.Size = new System.Drawing.Size(223, 20);
            this.txjenisPeriksa.TabIndex = 8;
            // 
            // labelControl53
            // 
            this.labelControl53.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl53.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl53.Location = new System.Drawing.Point(489, 364);
            this.labelControl53.Name = "labelControl53";
            this.labelControl53.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl53.Size = new System.Drawing.Size(90, 20);
            this.labelControl53.TabIndex = 259;
            this.labelControl53.Text = "Frekuensi/Waktu";
            // 
            // labelControl54
            // 
            this.labelControl54.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl54.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl54.Location = new System.Drawing.Point(246, 364);
            this.labelControl54.Name = "labelControl54";
            this.labelControl54.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl54.Size = new System.Drawing.Size(90, 20);
            this.labelControl54.TabIndex = 260;
            this.labelControl54.Text = "Yang Melakukan";
            // 
            // labelControl55
            // 
            this.labelControl55.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl55.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl55.Location = new System.Drawing.Point(358, 454);
            this.labelControl55.Name = "labelControl55";
            this.labelControl55.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl55.Size = new System.Drawing.Size(124, 20);
            this.labelControl55.TabIndex = 261;
            this.labelControl55.Text = "Poliklinik/Dokter dituju";
            // 
            // labelControl56
            // 
            this.labelControl56.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl56.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl56.Location = new System.Drawing.Point(362, 317);
            this.labelControl56.Name = "labelControl56";
            this.labelControl56.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl56.Size = new System.Drawing.Size(124, 20);
            this.labelControl56.TabIndex = 262;
            this.labelControl56.Text = "Kebiasaan Lain";
            // 
            // labelControl57
            // 
            this.labelControl57.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl57.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl57.Location = new System.Drawing.Point(358, 409);
            this.labelControl57.Name = "labelControl57";
            this.labelControl57.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl57.Size = new System.Drawing.Size(124, 20);
            this.labelControl57.TabIndex = 263;
            this.labelControl57.Text = "Tindakan yang dilakukan";
            // 
            // labelControl58
            // 
            this.labelControl58.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl58.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl58.Location = new System.Drawing.Point(5, 364);
            this.labelControl58.Name = "labelControl58";
            this.labelControl58.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl58.Size = new System.Drawing.Size(62, 20);
            this.labelControl58.TabIndex = 264;
            this.labelControl58.Text = "Procedure";
            // 
            // labelControl59
            // 
            this.labelControl59.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl59.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl59.Location = new System.Drawing.Point(362, 294);
            this.labelControl59.Name = "labelControl59";
            this.labelControl59.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl59.Size = new System.Drawing.Size(124, 20);
            this.labelControl59.TabIndex = 265;
            this.labelControl59.Text = "Psikologis";
            // 
            // labelControl60
            // 
            this.labelControl60.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl60.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl60.Location = new System.Drawing.Point(5, 454);
            this.labelControl60.Name = "labelControl60";
            this.labelControl60.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl60.Size = new System.Drawing.Size(133, 20);
            this.labelControl60.TabIndex = 266;
            this.labelControl60.Text = "Hari/Tanggal";
            // 
            // labelControl61
            // 
            this.labelControl61.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl61.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl61.Location = new System.Drawing.Point(5, 317);
            this.labelControl61.Name = "labelControl61";
            this.labelControl61.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl61.Size = new System.Drawing.Size(135, 20);
            this.labelControl61.TabIndex = 275;
            this.labelControl61.Text = "Pola Makan";
            // 
            // labelControl62
            // 
            this.labelControl62.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl62.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl62.Location = new System.Drawing.Point(5, 409);
            this.labelControl62.Name = "labelControl62";
            this.labelControl62.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl62.Size = new System.Drawing.Size(134, 20);
            this.labelControl62.TabIndex = 276;
            this.labelControl62.Text = "Unit Pelayanan Kesehatan";
            // 
            // labelControl63
            // 
            this.labelControl63.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl63.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl63.Location = new System.Drawing.Point(362, 249);
            this.labelControl63.Name = "labelControl63";
            this.labelControl63.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl63.Size = new System.Drawing.Size(124, 20);
            this.labelControl63.TabIndex = 277;
            this.labelControl63.Text = "Prosedure persiapan";
            // 
            // labelControl64
            // 
            this.labelControl64.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl64.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl64.Location = new System.Drawing.Point(6, 294);
            this.labelControl64.Name = "labelControl64";
            this.labelControl64.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl64.Size = new System.Drawing.Size(134, 20);
            this.labelControl64.TabIndex = 278;
            this.labelControl64.Text = "Aktivitas";
            // 
            // labelControl66
            // 
            this.labelControl66.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl66.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl66.Location = new System.Drawing.Point(6, 249);
            this.labelControl66.Name = "labelControl66";
            this.labelControl66.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl66.Size = new System.Drawing.Size(134, 20);
            this.labelControl66.TabIndex = 279;
            this.labelControl66.Text = "Jenis Pemeriksaan";
            // 
            // dtkeluar
            // 
            this.dtkeluar.EditValue = null;
            this.dtkeluar.Location = new System.Drawing.Point(103, 6);
            this.dtkeluar.Name = "dtkeluar";
            this.dtkeluar.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dtkeluar.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dtkeluar.Size = new System.Drawing.Size(107, 20);
            this.dtkeluar.TabIndex = 1;
            // 
            // labelControl26
            // 
            this.labelControl26.Appearance.BackColor = System.Drawing.Color.DarkGray;
            this.labelControl26.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl26.Appearance.ForeColor = System.Drawing.Color.White;
            this.labelControl26.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelControl26.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl26.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelControl26.Location = new System.Drawing.Point(0, 0);
            this.labelControl26.Name = "labelControl26";
            this.labelControl26.Size = new System.Drawing.Size(695, 30);
            this.labelControl26.TabIndex = 210;
            this.labelControl26.Text = "PERENCANAAN PULANG";
            // 
            // panel14
            // 
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel14.Controls.Add(this.xtraScrollableControl9);
            this.panel14.Controls.Add(this.labelControl93);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel14.Location = new System.Drawing.Point(706, 3);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(543, 479);
            this.panel14.TabIndex = 1;
            // 
            // xtraScrollableControl9
            // 
            this.xtraScrollableControl9.Controls.Add(this.xtraScrollableControl11);
            this.xtraScrollableControl9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraScrollableControl9.Location = new System.Drawing.Point(0, 30);
            this.xtraScrollableControl9.Name = "xtraScrollableControl9";
            this.xtraScrollableControl9.Size = new System.Drawing.Size(541, 447);
            this.xtraScrollableControl9.TabIndex = 188;
            // 
            // xtraScrollableControl11
            // 
            this.xtraScrollableControl11.Controls.Add(this.labelControl25);
            this.xtraScrollableControl11.Controls.Add(this.labelControl21);
            this.xtraScrollableControl11.Controls.Add(this.labelControl20);
            this.xtraScrollableControl11.Controls.Add(this.labelControl24);
            this.xtraScrollableControl11.Controls.Add(this.labelControl23);
            this.xtraScrollableControl11.Controls.Add(this.labelControl22);
            this.xtraScrollableControl11.Controls.Add(this.labelControl19);
            this.xtraScrollableControl11.Controls.Add(this.labelControl18);
            this.xtraScrollableControl11.Controls.Add(this.labelControl13);
            this.xtraScrollableControl11.Controls.Add(this.labelControl94);
            this.xtraScrollableControl11.Controls.Add(this.txAnjuran);
            this.xtraScrollableControl11.Controls.Add(this.mmPeriksaFisik);
            this.xtraScrollableControl11.Controls.Add(this.txAnamesa);
            this.xtraScrollableControl11.Controls.Add(this.txTerapiLanjtan);
            this.xtraScrollableControl11.Controls.Add(this.txTindakanDo);
            this.xtraScrollableControl11.Controls.Add(this.txPengobatan);
            this.xtraScrollableControl11.Controls.Add(this.txDiagnosaAkhir);
            this.xtraScrollableControl11.Controls.Add(this.txDokterKonsultan);
            this.xtraScrollableControl11.Controls.Add(this.txDokterPengirim);
            this.xtraScrollableControl11.Controls.Add(this.dtKeluarx);
            this.xtraScrollableControl11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraScrollableControl11.Location = new System.Drawing.Point(0, 0);
            this.xtraScrollableControl11.Name = "xtraScrollableControl11";
            this.xtraScrollableControl11.Size = new System.Drawing.Size(541, 447);
            this.xtraScrollableControl11.TabIndex = 0;
            // 
            // labelControl25
            // 
            this.labelControl25.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl25.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl25.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl25.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl25.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl25.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl25.Location = new System.Drawing.Point(8, 371);
            this.labelControl25.Name = "labelControl25";
            this.labelControl25.Size = new System.Drawing.Size(163, 61);
            this.labelControl25.TabIndex = 228;
            this.labelControl25.Text = "Anjuran  ";
            // 
            // labelControl21
            // 
            this.labelControl21.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl21.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl21.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl21.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl21.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl21.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl21.Location = new System.Drawing.Point(8, 211);
            this.labelControl21.Name = "labelControl21";
            this.labelControl21.Size = new System.Drawing.Size(163, 61);
            this.labelControl21.TabIndex = 226;
            this.labelControl21.Text = "Pemeriksaan Fisik,  lab, dll  ";
            // 
            // labelControl20
            // 
            this.labelControl20.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl20.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl20.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl20.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl20.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl20.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl20.Location = new System.Drawing.Point(8, 139);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(163, 61);
            this.labelControl20.TabIndex = 225;
            this.labelControl20.Text = "Anamesa  ";
            // 
            // labelControl24
            // 
            this.labelControl24.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl24.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl24.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl24.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl24.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl24.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl24.Location = new System.Drawing.Point(8, 339);
            this.labelControl24.Name = "labelControl24";
            this.labelControl24.Size = new System.Drawing.Size(163, 25);
            this.labelControl24.TabIndex = 224;
            this.labelControl24.Text = "Terapi Lanjutan  ";
            // 
            // labelControl23
            // 
            this.labelControl23.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl23.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl23.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl23.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl23.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl23.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl23.Location = new System.Drawing.Point(8, 309);
            this.labelControl23.Name = "labelControl23";
            this.labelControl23.Size = new System.Drawing.Size(163, 25);
            this.labelControl23.TabIndex = 223;
            this.labelControl23.Text = "Tindakan yg dilakukan  ";
            // 
            // labelControl22
            // 
            this.labelControl22.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl22.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl22.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl22.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl22.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl22.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl22.Location = new System.Drawing.Point(8, 278);
            this.labelControl22.Name = "labelControl22";
            this.labelControl22.Size = new System.Drawing.Size(163, 25);
            this.labelControl22.TabIndex = 222;
            this.labelControl22.Text = " Pengobatan yg dilakukan  ";
            // 
            // labelControl19
            // 
            this.labelControl19.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl19.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl19.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl19.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl19.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl19.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl19.Location = new System.Drawing.Point(8, 102);
            this.labelControl19.Name = "labelControl19";
            this.labelControl19.Size = new System.Drawing.Size(163, 25);
            this.labelControl19.TabIndex = 221;
            this.labelControl19.Text = "Diagnosa Akhir  ";
            // 
            // labelControl18
            // 
            this.labelControl18.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl18.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl18.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl18.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl18.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl18.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl18.Location = new System.Drawing.Point(8, 71);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(163, 25);
            this.labelControl18.TabIndex = 220;
            this.labelControl18.Text = "Dokter Konsultan  ";
            // 
            // labelControl13
            // 
            this.labelControl13.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl13.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl13.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl13.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl13.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl13.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl13.Location = new System.Drawing.Point(8, 41);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(163, 25);
            this.labelControl13.TabIndex = 227;
            this.labelControl13.Text = "Dokter Pengirim  ";
            // 
            // labelControl94
            // 
            this.labelControl94.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl94.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl94.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl94.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl94.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl94.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl94.Location = new System.Drawing.Point(8, 9);
            this.labelControl94.Name = "labelControl94";
            this.labelControl94.Size = new System.Drawing.Size(163, 25);
            this.labelControl94.TabIndex = 219;
            this.labelControl94.Text = "Tanggal Keluar  ";
            // 
            // txAnjuran
            // 
            this.txAnjuran.Location = new System.Drawing.Point(177, 370);
            this.txAnjuran.Name = "txAnjuran";
            this.txAnjuran.Size = new System.Drawing.Size(357, 60);
            this.txAnjuran.TabIndex = 45;
            // 
            // mmPeriksaFisik
            // 
            this.mmPeriksaFisik.Location = new System.Drawing.Point(177, 210);
            this.mmPeriksaFisik.Name = "mmPeriksaFisik";
            this.mmPeriksaFisik.Size = new System.Drawing.Size(357, 61);
            this.mmPeriksaFisik.TabIndex = 41;
            // 
            // txAnamesa
            // 
            this.txAnamesa.Location = new System.Drawing.Point(177, 138);
            this.txAnamesa.Name = "txAnamesa";
            this.txAnamesa.Size = new System.Drawing.Size(357, 62);
            this.txAnamesa.TabIndex = 40;
            // 
            // txTerapiLanjtan
            // 
            this.txTerapiLanjtan.Location = new System.Drawing.Point(177, 339);
            this.txTerapiLanjtan.Name = "txTerapiLanjtan";
            this.txTerapiLanjtan.Properties.AutoHeight = false;
            this.txTerapiLanjtan.Size = new System.Drawing.Size(357, 25);
            this.txTerapiLanjtan.TabIndex = 44;
            // 
            // txTindakanDo
            // 
            this.txTindakanDo.Location = new System.Drawing.Point(177, 308);
            this.txTindakanDo.Name = "txTindakanDo";
            this.txTindakanDo.Properties.AutoHeight = false;
            this.txTindakanDo.Size = new System.Drawing.Size(357, 25);
            this.txTindakanDo.TabIndex = 43;
            // 
            // txPengobatan
            // 
            this.txPengobatan.Location = new System.Drawing.Point(177, 277);
            this.txPengobatan.Name = "txPengobatan";
            this.txPengobatan.Properties.AutoHeight = false;
            this.txPengobatan.Size = new System.Drawing.Size(357, 25);
            this.txPengobatan.TabIndex = 42;
            // 
            // txDiagnosaAkhir
            // 
            this.txDiagnosaAkhir.Location = new System.Drawing.Point(177, 103);
            this.txDiagnosaAkhir.Name = "txDiagnosaAkhir";
            this.txDiagnosaAkhir.Properties.AutoHeight = false;
            this.txDiagnosaAkhir.Size = new System.Drawing.Size(357, 25);
            this.txDiagnosaAkhir.TabIndex = 39;
            // 
            // txDokterKonsultan
            // 
            this.txDokterKonsultan.Location = new System.Drawing.Point(177, 72);
            this.txDokterKonsultan.Name = "txDokterKonsultan";
            this.txDokterKonsultan.Properties.AutoHeight = false;
            this.txDokterKonsultan.Size = new System.Drawing.Size(357, 25);
            this.txDokterKonsultan.TabIndex = 38;
            // 
            // txDokterPengirim
            // 
            this.txDokterPengirim.Location = new System.Drawing.Point(177, 41);
            this.txDokterPengirim.Name = "txDokterPengirim";
            this.txDokterPengirim.Properties.AutoHeight = false;
            this.txDokterPengirim.Size = new System.Drawing.Size(357, 25);
            this.txDokterPengirim.TabIndex = 37;
            // 
            // dtKeluarx
            // 
            this.dtKeluarx.EditValue = null;
            this.dtKeluarx.Location = new System.Drawing.Point(177, 5);
            this.dtKeluarx.Name = "dtKeluarx";
            this.dtKeluarx.Properties.AutoHeight = false;
            this.dtKeluarx.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dtKeluarx.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dtKeluarx.Size = new System.Drawing.Size(167, 25);
            this.dtKeluarx.TabIndex = 36;
            // 
            // labelControl93
            // 
            this.labelControl93.Appearance.BackColor = System.Drawing.Color.DarkGray;
            this.labelControl93.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl93.Appearance.ForeColor = System.Drawing.Color.White;
            this.labelControl93.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelControl93.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl93.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelControl93.Location = new System.Drawing.Point(0, 0);
            this.labelControl93.Name = "labelControl93";
            this.labelControl93.Size = new System.Drawing.Size(541, 30);
            this.labelControl93.TabIndex = 187;
            this.labelControl93.Text = "RESUME PULANG";
            // 
            // splitContainerControl3
            // 
            this.splitContainerControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl3.Location = new System.Drawing.Point(3, 3);
            this.splitContainerControl3.Name = "splitContainerControl3";
            this.splitContainerControl3.Panel1.Controls.Add(this.tbLayJdObat);
            this.splitContainerControl3.Panel1.Text = "Panel1";
            this.splitContainerControl3.Panel2.Controls.Add(this.pnlAsGizi);
            this.splitContainerControl3.Panel2.Text = "Panel2";
            this.splitContainerControl3.Size = new System.Drawing.Size(1246, 479);
            this.splitContainerControl3.SplitterPosition = 616;
            this.splitContainerControl3.TabIndex = 0;
            this.splitContainerControl3.Text = "splitContainerControl3";
            // 
            // tbLayJdObat
            // 
            this.tbLayJdObat.ColumnCount = 1;
            this.tbLayJdObat.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 54.65498F));
            this.tbLayJdObat.Controls.Add(this.splitContainerControl2, 0, 0);
            this.tbLayJdObat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbLayJdObat.Location = new System.Drawing.Point(0, 0);
            this.tbLayJdObat.Name = "tbLayJdObat";
            this.tbLayJdObat.RowCount = 1;
            this.tbLayJdObat.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tbLayJdObat.Size = new System.Drawing.Size(616, 479);
            this.tbLayJdObat.TabIndex = 0;
            // 
            // splitContainerControl2
            // 
            this.splitContainerControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl2.Horizontal = false;
            this.splitContainerControl2.Location = new System.Drawing.Point(3, 3);
            this.splitContainerControl2.Name = "splitContainerControl2";
            this.splitContainerControl2.Panel1.Controls.Add(this.panel16);
            this.splitContainerControl2.Panel1.Text = "Panel1";
            this.splitContainerControl2.Panel2.Controls.Add(this.panel17);
            this.splitContainerControl2.Panel2.Text = "Panel2";
            this.splitContainerControl2.Size = new System.Drawing.Size(610, 473);
            this.splitContainerControl2.SplitterPosition = 130;
            this.splitContainerControl2.TabIndex = 0;
            this.splitContainerControl2.Text = "splitContainerControl2";
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.btnSaveCppt);
            this.panel16.Controls.Add(this.btnAddCppt);
            this.panel16.Controls.Add(this.gcCppt);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel16.Location = new System.Drawing.Point(0, 0);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(610, 130);
            this.panel16.TabIndex = 0;
            // 
            // btnSaveCppt
            // 
            this.btnSaveCppt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSaveCppt.Image = ((System.Drawing.Image)(resources.GetObject("btnSaveCppt.Image")));
            this.btnSaveCppt.Location = new System.Drawing.Point(525, 7);
            this.btnSaveCppt.Name = "btnSaveCppt";
            this.btnSaveCppt.Size = new System.Drawing.Size(75, 23);
            this.btnSaveCppt.TabIndex = 1;
            this.btnSaveCppt.Text = "Simpan";
            this.btnSaveCppt.Click += new System.EventHandler(this.btnSaveCppt_Click);
            // 
            // btnAddCppt
            // 
            this.btnAddCppt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddCppt.Image = ((System.Drawing.Image)(resources.GetObject("btnAddCppt.Image")));
            this.btnAddCppt.Location = new System.Drawing.Point(444, 7);
            this.btnAddCppt.Name = "btnAddCppt";
            this.btnAddCppt.Size = new System.Drawing.Size(75, 23);
            this.btnAddCppt.TabIndex = 1;
            this.btnAddCppt.Text = "Tambah";
            this.btnAddCppt.Click += new System.EventHandler(this.btnAddCppt_Click);
            // 
            // gcCppt
            // 
            this.gcCppt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcCppt.Location = new System.Drawing.Point(0, 0);
            this.gcCppt.MainView = this.gvCppt;
            this.gcCppt.Name = "gcCppt";
            this.gcCppt.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpDatex,
            this.txJamx,
            this.rpKodePpa});
            this.gcCppt.Size = new System.Drawing.Size(610, 130);
            this.gcCppt.TabIndex = 0;
            this.gcCppt.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvCppt});
            this.gcCppt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gcCppt_KeyDown);
            // 
            // gvCppt
            // 
            this.gvCppt.Appearance.ViewCaption.Options.UseTextOptions = true;
            this.gvCppt.Appearance.ViewCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.gvCppt.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn12,
            this.gridColumn13,
            this.gridColumn14,
            this.gridColumn15,
            this.gridColumn16,
            this.gridColumn17,
            this.gridColumn18});
            this.gvCppt.GridControl = this.gcCppt;
            this.gvCppt.Name = "gvCppt";
            this.gvCppt.OptionsView.ShowGroupPanel = false;
            this.gvCppt.OptionsView.ShowViewCaption = true;
            this.gvCppt.ViewCaption = "Catatan Perkembangan Pasien Terigntegrasi (CPPT)";
            this.gvCppt.ViewCaptionHeight = 35;
            // 
            // gridColumn12
            // 
            this.gridColumn12.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn12.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn12.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn12.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn12.Caption = "No";
            this.gridColumn12.FieldName = "SEQ";
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 0;
            this.gridColumn12.Width = 79;
            // 
            // gridColumn13
            // 
            this.gridColumn13.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn13.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn13.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn13.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn13.Caption = "Tanggal";
            this.gridColumn13.ColumnEdit = this.rpDatex;
            this.gridColumn13.FieldName = "TANGGAL";
            this.gridColumn13.Name = "gridColumn13";
            this.gridColumn13.Visible = true;
            this.gridColumn13.VisibleIndex = 1;
            this.gridColumn13.Width = 188;
            // 
            // rpDatex
            // 
            this.rpDatex.AutoHeight = false;
            this.rpDatex.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpDatex.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpDatex.Name = "rpDatex";
            // 
            // gridColumn14
            // 
            this.gridColumn14.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn14.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn14.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn14.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn14.Caption = "Jam";
            this.gridColumn14.ColumnEdit = this.txJamx;
            this.gridColumn14.FieldName = "JAM";
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.Visible = true;
            this.gridColumn14.VisibleIndex = 2;
            this.gridColumn14.Width = 151;
            // 
            // txJamx
            // 
            this.txJamx.AutoHeight = false;
            this.txJamx.Mask.EditMask = "90:00";
            this.txJamx.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Simple;
            this.txJamx.Name = "txJamx";
            // 
            // gridColumn15
            // 
            this.gridColumn15.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn15.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn15.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn15.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn15.Caption = "Kode PPA";
            this.gridColumn15.ColumnEdit = this.rpKodePpa;
            this.gridColumn15.FieldName = "KODE_PPA";
            this.gridColumn15.Name = "gridColumn15";
            this.gridColumn15.Visible = true;
            this.gridColumn15.VisibleIndex = 3;
            this.gridColumn15.Width = 153;
            // 
            // rpKodePpa
            // 
            this.rpKodePpa.AutoHeight = false;
            this.rpKodePpa.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpKodePpa.Items.AddRange(new object[] {
            "Dokter",
            "Perawat",
            "Bidan",
            "Ahli Gizi",
            "Farmasi"});
            this.rpKodePpa.Name = "rpKodePpa";
            this.rpKodePpa.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            // 
            // gridColumn16
            // 
            this.gridColumn16.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn16.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn16.Caption = "Hasil Asesmen";
            this.gridColumn16.FieldName = "HASIL_ASESMEN";
            this.gridColumn16.Name = "gridColumn16";
            this.gridColumn16.Visible = true;
            this.gridColumn16.VisibleIndex = 4;
            this.gridColumn16.Width = 632;
            // 
            // gridColumn17
            // 
            this.gridColumn17.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn17.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn17.Caption = "Instruksi";
            this.gridColumn17.FieldName = "INSTRUKSI";
            this.gridColumn17.Name = "gridColumn17";
            this.gridColumn17.Visible = true;
            this.gridColumn17.VisibleIndex = 5;
            this.gridColumn17.Width = 266;
            // 
            // gridColumn18
            // 
            this.gridColumn18.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn18.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn18.Caption = "Nama Terang";
            this.gridColumn18.FieldName = "NAMA_TERANG";
            this.gridColumn18.Name = "gridColumn18";
            this.gridColumn18.Visible = true;
            this.gridColumn18.VisibleIndex = 6;
            this.gridColumn18.Width = 163;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.splitContainerControl4);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel17.Location = new System.Drawing.Point(0, 0);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(610, 338);
            this.panel17.TabIndex = 0;
            // 
            // splitContainerControl4
            // 
            this.splitContainerControl4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl4.Horizontal = false;
            this.splitContainerControl4.Location = new System.Drawing.Point(0, 0);
            this.splitContainerControl4.Name = "splitContainerControl4";
            this.splitContainerControl4.Panel1.Controls.Add(this.btnSimpanObat);
            this.splitContainerControl4.Panel1.Controls.Add(this.btnAddJadwalObat);
            this.splitContainerControl4.Panel1.Controls.Add(this.gcJadwalObat);
            this.splitContainerControl4.Panel1.Text = "Panel1";
            this.splitContainerControl4.Panel2.Controls.Add(this.panel7);
            this.splitContainerControl4.Panel2.Text = "Panel2";
            this.splitContainerControl4.Size = new System.Drawing.Size(610, 338);
            this.splitContainerControl4.SplitterPosition = 156;
            this.splitContainerControl4.TabIndex = 0;
            this.splitContainerControl4.Text = "splitContainerControl4";
            // 
            // btnSimpanObat
            // 
            this.btnSimpanObat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSimpanObat.Image = ((System.Drawing.Image)(resources.GetObject("btnSimpanObat.Image")));
            this.btnSimpanObat.Location = new System.Drawing.Point(525, 6);
            this.btnSimpanObat.Name = "btnSimpanObat";
            this.btnSimpanObat.Size = new System.Drawing.Size(75, 23);
            this.btnSimpanObat.TabIndex = 1;
            this.btnSimpanObat.Text = "Simpan";
            this.btnSimpanObat.Click += new System.EventHandler(this.btnSimpanObat_Click);
            // 
            // btnAddJadwalObat
            // 
            this.btnAddJadwalObat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddJadwalObat.Image = ((System.Drawing.Image)(resources.GetObject("btnAddJadwalObat.Image")));
            this.btnAddJadwalObat.Location = new System.Drawing.Point(444, 6);
            this.btnAddJadwalObat.Name = "btnAddJadwalObat";
            this.btnAddJadwalObat.Size = new System.Drawing.Size(75, 23);
            this.btnAddJadwalObat.TabIndex = 1;
            this.btnAddJadwalObat.Text = "Tambah";
            this.btnAddJadwalObat.Click += new System.EventHandler(this.btnAddJadwalObat_Click);
            // 
            // gcJadwalObat
            // 
            this.gcJadwalObat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcJadwalObat.Location = new System.Drawing.Point(0, 0);
            this.gcJadwalObat.MainView = this.gvJadwalObat;
            this.gcJadwalObat.Name = "gcJadwalObat";
            this.gcJadwalObat.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.cbJnisObaT,
            this.rpDate,
            this.rpTimetx});
            this.gcJadwalObat.Size = new System.Drawing.Size(610, 156);
            this.gcJadwalObat.TabIndex = 0;
            this.gcJadwalObat.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvJadwalObat});
            this.gcJadwalObat.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gcJadwalObat_KeyDown);
            // 
            // gvJadwalObat
            // 
            this.gvJadwalObat.Appearance.ViewCaption.Options.UseTextOptions = true;
            this.gvJadwalObat.Appearance.ViewCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.gvJadwalObat.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn11,
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn4,
            this.gridColumn5,
            this.gridColumn6,
            this.gridColumn7,
            this.gridColumn8,
            this.gridColumn9,
            this.gridColumn10});
            this.gvJadwalObat.GridControl = this.gcJadwalObat;
            this.gvJadwalObat.Name = "gvJadwalObat";
            this.gvJadwalObat.OptionsView.ShowGroupPanel = false;
            this.gvJadwalObat.OptionsView.ShowViewCaption = true;
            this.gvJadwalObat.ViewCaption = " Jadwal Pemberian Obat";
            this.gvJadwalObat.ViewCaptionHeight = 35;
            // 
            // gridColumn11
            // 
            this.gridColumn11.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn11.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn11.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn11.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn11.Caption = "No";
            this.gridColumn11.FieldName = "SEQ";
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.Visible = true;
            this.gridColumn11.VisibleIndex = 0;
            this.gridColumn11.Width = 32;
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.Caption = "Jenis Obat";
            this.gridColumn1.ColumnEdit = this.cbJnisObaT;
            this.gridColumn1.FieldName = "JENIS_OBAT";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 1;
            this.gridColumn1.Width = 98;
            // 
            // cbJnisObaT
            // 
            this.cbJnisObaT.AutoHeight = false;
            this.cbJnisObaT.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cbJnisObaT.Items.AddRange(new object[] {
            "OBAT ORAL",
            "OBAT INJEKSI",
            "CAIRAN INPUS",
            "SUPP, INHALASI, TOPIKAL"});
            this.cbJnisObaT.Name = "cbJnisObaT";
            this.cbJnisObaT.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.Caption = "Nama Obat";
            this.gridColumn2.FieldName = "NAMA_OBAT";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 2;
            this.gridColumn2.Width = 103;
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.Caption = "Dosis";
            this.gridColumn3.FieldName = "DOSIS";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 3;
            this.gridColumn3.Width = 72;
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.Caption = "Tanggal";
            this.gridColumn4.ColumnEdit = this.rpDate;
            this.gridColumn4.FieldName = "TANGGAL";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 4;
            this.gridColumn4.Width = 91;
            // 
            // rpDate
            // 
            this.rpDate.AutoHeight = false;
            this.rpDate.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpDate.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpDate.Name = "rpDate";
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.Caption = "Jam-1";
            this.gridColumn5.ColumnEdit = this.rpTimetx;
            this.gridColumn5.FieldName = "JAM1";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 5;
            this.gridColumn5.Width = 47;
            // 
            // rpTimetx
            // 
            this.rpTimetx.AutoHeight = false;
            this.rpTimetx.Mask.EditMask = "90:00";
            this.rpTimetx.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Simple;
            this.rpTimetx.Name = "rpTimetx";
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.Caption = "Jam-2";
            this.gridColumn6.ColumnEdit = this.rpTimetx;
            this.gridColumn6.FieldName = "JAM2";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 6;
            this.gridColumn6.Width = 47;
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.Caption = "Jam-3";
            this.gridColumn7.ColumnEdit = this.rpTimetx;
            this.gridColumn7.FieldName = "JAM3";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 7;
            this.gridColumn7.Width = 47;
            // 
            // gridColumn8
            // 
            this.gridColumn8.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn8.Caption = "Jam-4";
            this.gridColumn8.ColumnEdit = this.rpTimetx;
            this.gridColumn8.FieldName = "JAM4";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 8;
            this.gridColumn8.Width = 47;
            // 
            // gridColumn9
            // 
            this.gridColumn9.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn9.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn9.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn9.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn9.Caption = "Extra";
            this.gridColumn9.ColumnEdit = this.rpTimetx;
            this.gridColumn9.FieldName = "EXTRA";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 9;
            this.gridColumn9.Width = 47;
            // 
            // gridColumn10
            // 
            this.gridColumn10.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn10.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn10.Caption = "TTD";
            this.gridColumn10.FieldName = "TTD";
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 10;
            this.gridColumn10.Width = 71;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.tableLayoutPanel11);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(610, 177);
            this.panel7.TabIndex = 0;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 1;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Controls.Add(this.splitContainerControl5, 0, 0);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 1;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(610, 177);
            this.tableLayoutPanel11.TabIndex = 1;
            // 
            // splitContainerControl5
            // 
            this.splitContainerControl5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl5.Location = new System.Drawing.Point(3, 3);
            this.splitContainerControl5.Name = "splitContainerControl5";
            this.splitContainerControl5.Panel1.Controls.Add(this.panel8);
            this.splitContainerControl5.Panel1.Text = "Panel1";
            this.splitContainerControl5.Panel2.Controls.Add(this.panel9);
            this.splitContainerControl5.Panel2.Text = "Panel2";
            this.splitContainerControl5.Size = new System.Drawing.Size(604, 171);
            this.splitContainerControl5.SplitterPosition = 244;
            this.splitContainerControl5.TabIndex = 0;
            this.splitContainerControl5.Text = "splitContainerControl5";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.btnSaveV);
            this.panel8.Controls.Add(this.btnAddVt);
            this.panel8.Controls.Add(this.gcVt);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(244, 171);
            this.panel8.TabIndex = 0;
            // 
            // btnSaveV
            // 
            this.btnSaveV.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSaveV.Image = ((System.Drawing.Image)(resources.GetObject("btnSaveV.Image")));
            this.btnSaveV.Location = new System.Drawing.Point(164, 5);
            this.btnSaveV.Name = "btnSaveV";
            this.btnSaveV.Size = new System.Drawing.Size(71, 22);
            this.btnSaveV.TabIndex = 2;
            this.btnSaveV.Text = "Simpan";
            this.btnSaveV.Click += new System.EventHandler(this.btnSaveV_Click);
            // 
            // btnAddVt
            // 
            this.btnAddVt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddVt.Image = ((System.Drawing.Image)(resources.GetObject("btnAddVt.Image")));
            this.btnAddVt.Location = new System.Drawing.Point(87, 5);
            this.btnAddVt.Name = "btnAddVt";
            this.btnAddVt.Size = new System.Drawing.Size(71, 22);
            this.btnAddVt.TabIndex = 2;
            this.btnAddVt.Text = "Tambah";
            this.btnAddVt.Click += new System.EventHandler(this.btnAddVt_Click);
            // 
            // gcVt
            // 
            this.gcVt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcVt.Location = new System.Drawing.Point(0, 0);
            this.gcVt.MainView = this.gvVt;
            this.gcVt.Name = "gcVt";
            this.gcVt.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.rpDateVx,
            this.rpTxShu});
            this.gcVt.Size = new System.Drawing.Size(244, 171);
            this.gcVt.TabIndex = 1;
            this.gcVt.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvVt});
            this.gcVt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gcVt_KeyDown);
            // 
            // gvVt
            // 
            this.gvVt.Appearance.ViewCaption.Options.UseTextOptions = true;
            this.gvVt.Appearance.ViewCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.gvVt.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn24,
            this.gridColumn25,
            this.gridColumn26,
            this.gridColumn27});
            this.gvVt.GridControl = this.gcVt;
            this.gvVt.Name = "gvVt";
            this.gvVt.OptionsView.ShowGroupPanel = false;
            this.gvVt.OptionsView.ShowViewCaption = true;
            this.gvVt.ViewCaption = "Tanda Vital";
            this.gvVt.ViewCaptionHeight = 30;
            // 
            // gridColumn24
            // 
            this.gridColumn24.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn24.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn24.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn24.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn24.Caption = "NO";
            this.gridColumn24.FieldName = "SEQ";
            this.gridColumn24.Name = "gridColumn24";
            this.gridColumn24.Visible = true;
            this.gridColumn24.VisibleIndex = 0;
            this.gridColumn24.Width = 36;
            // 
            // gridColumn25
            // 
            this.gridColumn25.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn25.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn25.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn25.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn25.Caption = "Tanggal";
            this.gridColumn25.ColumnEdit = this.rpDateVx;
            this.gridColumn25.FieldName = "TANGGAL";
            this.gridColumn25.Name = "gridColumn25";
            this.gridColumn25.Visible = true;
            this.gridColumn25.VisibleIndex = 1;
            this.gridColumn25.Width = 133;
            // 
            // rpDateVx
            // 
            this.rpDateVx.AutoHeight = false;
            this.rpDateVx.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpDateVx.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.rpDateVx.Name = "rpDateVx";
            // 
            // gridColumn26
            // 
            this.gridColumn26.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn26.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn26.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn26.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn26.Caption = "Suhu";
            this.gridColumn26.ColumnEdit = this.rpTxShu;
            this.gridColumn26.FieldName = "SUHU";
            this.gridColumn26.Name = "gridColumn26";
            this.gridColumn26.Visible = true;
            this.gridColumn26.VisibleIndex = 2;
            this.gridColumn26.Width = 58;
            // 
            // rpTxShu
            // 
            this.rpTxShu.AutoHeight = false;
            this.rpTxShu.Mask.EditMask = "00";
            this.rpTxShu.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.rpTxShu.Name = "rpTxShu";
            // 
            // gridColumn27
            // 
            this.gridColumn27.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn27.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn27.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn27.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn27.Caption = "Tensi";
            this.gridColumn27.FieldName = "TENSI";
            this.gridColumn27.Name = "gridColumn27";
            this.gridColumn27.Visible = true;
            this.gridColumn27.VisibleIndex = 3;
            this.gridColumn27.Width = 62;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.tableLayoutPanel12);
            this.panel9.Controls.Add(this.labelControl98);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(355, 171);
            this.panel9.TabIndex = 0;
            // 
            // tableLayoutPanel12
            // 
            this.tableLayoutPanel12.ColumnCount = 1;
            this.tableLayoutPanel12.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Controls.Add(this.chrVital, 0, 0);
            this.tableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel12.Location = new System.Drawing.Point(0, 30);
            this.tableLayoutPanel12.Name = "tableLayoutPanel12";
            this.tableLayoutPanel12.RowCount = 1;
            this.tableLayoutPanel12.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel12.Size = new System.Drawing.Size(355, 141);
            this.tableLayoutPanel12.TabIndex = 2;
            // 
            // chrVital
            // 
            xyDiagram1.AxisX.VisibleInPanesSerializable = "-1";
            xyDiagram1.AxisY.VisibleInPanesSerializable = "-1";
            xyDiagram1.AxisY.WholeRange.Auto = false;
            xyDiagram1.AxisY.WholeRange.MaxValueSerializable = "210";
            xyDiagram1.AxisY.WholeRange.MinValueSerializable = "10";
            this.chrVital.Diagram = xyDiagram1;
            this.chrVital.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chrVital.Legend.UseCheckBoxes = true;
            this.chrVital.Location = new System.Drawing.Point(3, 3);
            this.chrVital.Name = "chrVital";
            pointSeriesLabel1.ResolveOverlappingMode = DevExpress.XtraCharts.ResolveOverlappingMode.JustifyAroundPoint;
            series1.Label = pointSeriesLabel1;
            series1.LabelsVisibility = DevExpress.Utils.DefaultBoolean.True;
            series1.Name = "Tensi (S)";
            series1.View = lineSeriesView1;
            pointSeriesLabel2.ResolveOverlappingMode = DevExpress.XtraCharts.ResolveOverlappingMode.JustifyAroundPoint;
            series2.Label = pointSeriesLabel2;
            series2.LabelsVisibility = DevExpress.Utils.DefaultBoolean.True;
            series2.Name = "Tensi (D)";
            series2.View = lineSeriesView2;
            pointSeriesLabel3.ResolveOverlappingMode = DevExpress.XtraCharts.ResolveOverlappingMode.JustifyAroundPoint;
            pointSeriesLabel3.TextPattern = "{V} °C";
            series3.Label = pointSeriesLabel3;
            series3.LabelsVisibility = DevExpress.Utils.DefaultBoolean.True;
            series3.Name = "Suhu (°C)";
            series3.View = lineSeriesView3;
            this.chrVital.SeriesSerializable = new DevExpress.XtraCharts.Series[] {
        series1,
        series2,
        series3};
            this.chrVital.Size = new System.Drawing.Size(349, 135);
            this.chrVital.TabIndex = 0;
            // 
            // labelControl98
            // 
            this.labelControl98.Appearance.BackColor = System.Drawing.Color.DarkGray;
            this.labelControl98.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl98.Appearance.ForeColor = System.Drawing.Color.White;
            this.labelControl98.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelControl98.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl98.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelControl98.Location = new System.Drawing.Point(0, 0);
            this.labelControl98.Name = "labelControl98";
            this.labelControl98.Size = new System.Drawing.Size(355, 30);
            this.labelControl98.TabIndex = 1;
            this.labelControl98.Text = "Grafik Tanda Vital";
            // 
            // pnlAsGizi
            // 
            this.pnlAsGizi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlAsGizi.Controls.Add(this.xtraScrollableControl6);
            this.pnlAsGizi.Controls.Add(this.labelControl36);
            this.pnlAsGizi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAsGizi.Location = new System.Drawing.Point(0, 0);
            this.pnlAsGizi.Name = "pnlAsGizi";
            this.pnlAsGizi.Size = new System.Drawing.Size(625, 479);
            this.pnlAsGizi.TabIndex = 0;
            // 
            // xtraScrollableControl6
            // 
            this.xtraScrollableControl6.Controls.Add(this.panel20);
            this.xtraScrollableControl6.Controls.Add(this.labelControl75);
            this.xtraScrollableControl6.Controls.Add(this.labelControl79);
            this.xtraScrollableControl6.Controls.Add(this.labelControl77);
            this.xtraScrollableControl6.Controls.Add(this.labelControl73);
            this.xtraScrollableControl6.Controls.Add(this.labelControl70);
            this.xtraScrollableControl6.Controls.Add(this.labelControl51);
            this.xtraScrollableControl6.Controls.Add(this.txMonitoring);
            this.xtraScrollableControl6.Controls.Add(this.txIntrvnsiGz);
            this.xtraScrollableControl6.Controls.Add(this.txDiagnosGz);
            this.xtraScrollableControl6.Controls.Add(this.txRiwytPerson);
            this.xtraScrollableControl6.Controls.Add(this.labelControl90);
            this.xtraScrollableControl6.Controls.Add(this.txAsupnLbh);
            this.xtraScrollableControl6.Controls.Add(this.labelControl89);
            this.xtraScrollableControl6.Controls.Add(this.txAsupnKurng);
            this.xtraScrollableControl6.Controls.Add(this.labelControl88);
            this.xtraScrollableControl6.Controls.Add(this.txPolaMkn);
            this.xtraScrollableControl6.Controls.Add(this.labelControl87);
            this.xtraScrollableControl6.Controls.Add(this.txAlergiMkn);
            this.xtraScrollableControl6.Controls.Add(this.labelControl86);
            this.xtraScrollableControl6.Controls.Add(this.txBiokimia);
            this.xtraScrollableControl6.Controls.Add(this.labelControl44);
            this.xtraScrollableControl6.Controls.Add(this.txKlinis);
            this.xtraScrollableControl6.Controls.Add(this.labelControl85);
            this.xtraScrollableControl6.Controls.Add(this.labelControl45);
            this.xtraScrollableControl6.Controls.Add(this.labelControl46);
            this.xtraScrollableControl6.Controls.Add(this.txImtDw);
            this.xtraScrollableControl6.Controls.Add(this.txKbthnKarbo);
            this.xtraScrollableControl6.Controls.Add(this.txKbthnLemak);
            this.xtraScrollableControl6.Controls.Add(this.txKbthnProtein);
            this.xtraScrollableControl6.Controls.Add(this.txKbthnEnergi);
            this.xtraScrollableControl6.Controls.Add(this.txPercenKarbo);
            this.xtraScrollableControl6.Controls.Add(this.txNilaiKarbo);
            this.xtraScrollableControl6.Controls.Add(this.txPercenLemak);
            this.xtraScrollableControl6.Controls.Add(this.txNilaiLemak);
            this.xtraScrollableControl6.Controls.Add(this.txPercenProtein);
            this.xtraScrollableControl6.Controls.Add(this.txNilaiProtein);
            this.xtraScrollableControl6.Controls.Add(this.txPercenEnergi);
            this.xtraScrollableControl6.Controls.Add(this.txNlaiEnergi);
            this.xtraScrollableControl6.Controls.Add(this.txBBU);
            this.xtraScrollableControl6.Controls.Add(this.txTgLutut);
            this.xtraScrollableControl6.Controls.Add(this.txBBTB);
            this.xtraScrollableControl6.Controls.Add(this.txBbDw);
            this.xtraScrollableControl6.Controls.Add(this.txImtAnk);
            this.xtraScrollableControl6.Controls.Add(this.txTbDw);
            this.xtraScrollableControl6.Controls.Add(this.txLilaDw);
            this.xtraScrollableControl6.Controls.Add(this.labelControl78);
            this.xtraScrollableControl6.Controls.Add(this.txStsGizi);
            this.xtraScrollableControl6.Controls.Add(this.labelControl37);
            this.xtraScrollableControl6.Controls.Add(this.labelControl39);
            this.xtraScrollableControl6.Controls.Add(this.labelControl43);
            this.xtraScrollableControl6.Controls.Add(this.labelControl42);
            this.xtraScrollableControl6.Controls.Add(this.labelControl41);
            this.xtraScrollableControl6.Controls.Add(this.labelControl40);
            this.xtraScrollableControl6.Controls.Add(this.labelControl65);
            this.xtraScrollableControl6.Controls.Add(this.labelControl74);
            this.xtraScrollableControl6.Controls.Add(this.labelControl91);
            this.xtraScrollableControl6.Controls.Add(this.labelControl84);
            this.xtraScrollableControl6.Controls.Add(this.txBbi);
            this.xtraScrollableControl6.Controls.Add(this.labelControl83);
            this.xtraScrollableControl6.Controls.Add(this.labelControl76);
            this.xtraScrollableControl6.Controls.Add(this.labelControl82);
            this.xtraScrollableControl6.Controls.Add(this.labelControl72);
            this.xtraScrollableControl6.Controls.Add(this.labelControl71);
            this.xtraScrollableControl6.Controls.Add(this.labelControl69);
            this.xtraScrollableControl6.Controls.Add(this.labelControl67);
            this.xtraScrollableControl6.Controls.Add(this.labelControl68);
            this.xtraScrollableControl6.Controls.Add(this.labelControl80);
            this.xtraScrollableControl6.Controls.Add(this.labelControl81);
            this.xtraScrollableControl6.Controls.Add(this.labelControl92);
            this.xtraScrollableControl6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraScrollableControl6.Location = new System.Drawing.Point(0, 30);
            this.xtraScrollableControl6.Name = "xtraScrollableControl6";
            this.xtraScrollableControl6.Size = new System.Drawing.Size(623, 447);
            this.xtraScrollableControl6.TabIndex = 1;
            // 
            // panel20
            // 
            this.panel20.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel20.Location = new System.Drawing.Point(0, 430);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(623, 17);
            this.panel20.TabIndex = 292;
            // 
            // labelControl75
            // 
            this.labelControl75.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl75.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl75.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.labelControl75.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl75.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl75.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl75.Location = new System.Drawing.Point(264, 40);
            this.labelControl75.Name = "labelControl75";
            this.labelControl75.Size = new System.Drawing.Size(30, 25);
            this.labelControl75.TabIndex = 291;
            this.labelControl75.Text = "  KG";
            // 
            // labelControl79
            // 
            this.labelControl79.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl79.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl79.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.labelControl79.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl79.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl79.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl79.Location = new System.Drawing.Point(520, 70);
            this.labelControl79.Name = "labelControl79";
            this.labelControl79.Size = new System.Drawing.Size(65, 25);
            this.labelControl79.TabIndex = 290;
            this.labelControl79.Text = "  Kg / m2";
            // 
            // labelControl77
            // 
            this.labelControl77.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl77.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl77.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.labelControl77.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl77.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl77.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl77.Location = new System.Drawing.Point(330, 70);
            this.labelControl77.Name = "labelControl77";
            this.labelControl77.Size = new System.Drawing.Size(30, 25);
            this.labelControl77.TabIndex = 289;
            this.labelControl77.Text = "  CM";
            // 
            // labelControl73
            // 
            this.labelControl73.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl73.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl73.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.labelControl73.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl73.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl73.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl73.Location = new System.Drawing.Point(412, 40);
            this.labelControl73.Name = "labelControl73";
            this.labelControl73.Size = new System.Drawing.Size(30, 25);
            this.labelControl73.TabIndex = 288;
            this.labelControl73.Text = "  CM";
            // 
            // labelControl70
            // 
            this.labelControl70.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl70.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl70.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.labelControl70.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl70.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl70.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl70.Location = new System.Drawing.Point(555, 40);
            this.labelControl70.Name = "labelControl70";
            this.labelControl70.Size = new System.Drawing.Size(30, 25);
            this.labelControl70.TabIndex = 287;
            this.labelControl70.Text = "  CM";
            // 
            // labelControl51
            // 
            this.labelControl51.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl51.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl51.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.labelControl51.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl51.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl51.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl51.Location = new System.Drawing.Point(264, 9);
            this.labelControl51.Name = "labelControl51";
            this.labelControl51.Size = new System.Drawing.Size(30, 25);
            this.labelControl51.TabIndex = 286;
            this.labelControl51.Text = "  KG";
            // 
            // txMonitoring
            // 
            this.txMonitoring.Location = new System.Drawing.Point(155, 574);
            this.txMonitoring.Name = "txMonitoring";
            this.txMonitoring.Properties.AutoHeight = false;
            this.txMonitoring.Size = new System.Drawing.Size(430, 24);
            this.txMonitoring.TabIndex = 32;
            // 
            // txIntrvnsiGz
            // 
            this.txIntrvnsiGz.Location = new System.Drawing.Point(155, 543);
            this.txIntrvnsiGz.Name = "txIntrvnsiGz";
            this.txIntrvnsiGz.Properties.AutoHeight = false;
            this.txIntrvnsiGz.Size = new System.Drawing.Size(430, 25);
            this.txIntrvnsiGz.TabIndex = 31;
            // 
            // txDiagnosGz
            // 
            this.txDiagnosGz.Location = new System.Drawing.Point(155, 512);
            this.txDiagnosGz.Name = "txDiagnosGz";
            this.txDiagnosGz.Properties.AutoHeight = false;
            this.txDiagnosGz.Size = new System.Drawing.Size(430, 25);
            this.txDiagnosGz.TabIndex = 30;
            // 
            // txRiwytPerson
            // 
            this.txRiwytPerson.Location = new System.Drawing.Point(155, 481);
            this.txRiwytPerson.Name = "txRiwytPerson";
            this.txRiwytPerson.Properties.AutoHeight = false;
            this.txRiwytPerson.Size = new System.Drawing.Size(430, 25);
            this.txRiwytPerson.TabIndex = 29;
            // 
            // labelControl90
            // 
            this.labelControl90.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl90.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl90.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl90.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl90.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl90.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl90.Location = new System.Drawing.Point(17, 573);
            this.labelControl90.Name = "labelControl90";
            this.labelControl90.Size = new System.Drawing.Size(107, 25);
            this.labelControl90.TabIndex = 268;
            this.labelControl90.Text = "Monitoring  ";
            // 
            // txAsupnLbh
            // 
            this.txAsupnLbh.Location = new System.Drawing.Point(155, 450);
            this.txAsupnLbh.Name = "txAsupnLbh";
            this.txAsupnLbh.Properties.AutoHeight = false;
            this.txAsupnLbh.Size = new System.Drawing.Size(430, 25);
            this.txAsupnLbh.TabIndex = 28;
            // 
            // labelControl89
            // 
            this.labelControl89.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl89.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl89.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl89.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl89.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl89.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl89.Location = new System.Drawing.Point(17, 542);
            this.labelControl89.Name = "labelControl89";
            this.labelControl89.Size = new System.Drawing.Size(107, 25);
            this.labelControl89.TabIndex = 269;
            this.labelControl89.Text = "Intervensi Gizi   ";
            // 
            // txAsupnKurng
            // 
            this.txAsupnKurng.Location = new System.Drawing.Point(155, 419);
            this.txAsupnKurng.Name = "txAsupnKurng";
            this.txAsupnKurng.Properties.AutoHeight = false;
            this.txAsupnKurng.Size = new System.Drawing.Size(430, 25);
            this.txAsupnKurng.TabIndex = 27;
            // 
            // labelControl88
            // 
            this.labelControl88.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl88.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl88.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl88.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl88.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl88.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl88.Location = new System.Drawing.Point(17, 511);
            this.labelControl88.Name = "labelControl88";
            this.labelControl88.Size = new System.Drawing.Size(107, 25);
            this.labelControl88.TabIndex = 270;
            this.labelControl88.Text = "Diagnose Gizi  ";
            // 
            // txPolaMkn
            // 
            this.txPolaMkn.Location = new System.Drawing.Point(155, 226);
            this.txPolaMkn.Name = "txPolaMkn";
            this.txPolaMkn.Properties.AutoHeight = false;
            this.txPolaMkn.Size = new System.Drawing.Size(430, 25);
            this.txPolaMkn.TabIndex = 14;
            // 
            // labelControl87
            // 
            this.labelControl87.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl87.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl87.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl87.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl87.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl87.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl87.Location = new System.Drawing.Point(17, 480);
            this.labelControl87.Name = "labelControl87";
            this.labelControl87.Size = new System.Drawing.Size(107, 25);
            this.labelControl87.TabIndex = 272;
            this.labelControl87.Text = "Riwyat Personal   ";
            // 
            // txAlergiMkn
            // 
            this.txAlergiMkn.Location = new System.Drawing.Point(155, 195);
            this.txAlergiMkn.Name = "txAlergiMkn";
            this.txAlergiMkn.Properties.AutoHeight = false;
            this.txAlergiMkn.Size = new System.Drawing.Size(430, 25);
            this.txAlergiMkn.TabIndex = 13;
            // 
            // labelControl86
            // 
            this.labelControl86.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl86.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl86.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl86.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl86.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl86.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl86.Location = new System.Drawing.Point(17, 449);
            this.labelControl86.Name = "labelControl86";
            this.labelControl86.Size = new System.Drawing.Size(107, 25);
            this.labelControl86.TabIndex = 271;
            this.labelControl86.Text = "Asupan Lebih  ";
            // 
            // txBiokimia
            // 
            this.txBiokimia.Location = new System.Drawing.Point(155, 132);
            this.txBiokimia.Name = "txBiokimia";
            this.txBiokimia.Properties.AutoHeight = false;
            this.txBiokimia.Size = new System.Drawing.Size(430, 25);
            this.txBiokimia.TabIndex = 11;
            // 
            // labelControl44
            // 
            this.labelControl44.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl44.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl44.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl44.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl44.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl44.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl44.Location = new System.Drawing.Point(17, 418);
            this.labelControl44.Name = "labelControl44";
            this.labelControl44.Size = new System.Drawing.Size(107, 25);
            this.labelControl44.TabIndex = 273;
            this.labelControl44.Text = "Asupan Kurang  ";
            // 
            // txKlinis
            // 
            this.txKlinis.Location = new System.Drawing.Point(155, 163);
            this.txKlinis.Name = "txKlinis";
            this.txKlinis.Properties.AutoHeight = false;
            this.txKlinis.Size = new System.Drawing.Size(430, 25);
            this.txKlinis.TabIndex = 12;
            // 
            // labelControl85
            // 
            this.labelControl85.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl85.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl85.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl85.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl85.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl85.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl85.Location = new System.Drawing.Point(17, 225);
            this.labelControl85.Name = "labelControl85";
            this.labelControl85.Size = new System.Drawing.Size(107, 25);
            this.labelControl85.TabIndex = 274;
            this.labelControl85.Text = " Pola Makan  ";
            // 
            // labelControl45
            // 
            this.labelControl45.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl45.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl45.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl45.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl45.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl45.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl45.Location = new System.Drawing.Point(17, 194);
            this.labelControl45.Name = "labelControl45";
            this.labelControl45.Size = new System.Drawing.Size(107, 25);
            this.labelControl45.TabIndex = 275;
            this.labelControl45.Text = "Alergi Makan  ";
            // 
            // labelControl46
            // 
            this.labelControl46.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl46.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl46.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl46.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl46.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl46.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl46.Location = new System.Drawing.Point(17, 163);
            this.labelControl46.Name = "labelControl46";
            this.labelControl46.Size = new System.Drawing.Size(107, 25);
            this.labelControl46.TabIndex = 267;
            this.labelControl46.Text = "Klinis / Fisik  ";
            // 
            // txImtDw
            // 
            this.txImtDw.Location = new System.Drawing.Point(442, 70);
            this.txImtDw.Name = "txImtDw";
            this.txImtDw.Properties.AutoHeight = false;
            this.txImtDw.Size = new System.Drawing.Size(81, 25);
            this.txImtDw.TabIndex = 7;
            // 
            // txKbthnKarbo
            // 
            this.txKbthnKarbo.Location = new System.Drawing.Point(457, 388);
            this.txKbthnKarbo.Name = "txKbthnKarbo";
            this.txKbthnKarbo.Properties.AutoHeight = false;
            this.txKbthnKarbo.Size = new System.Drawing.Size(128, 25);
            this.txKbthnKarbo.TabIndex = 26;
            // 
            // txKbthnLemak
            // 
            this.txKbthnLemak.Location = new System.Drawing.Point(457, 357);
            this.txKbthnLemak.Name = "txKbthnLemak";
            this.txKbthnLemak.Properties.AutoHeight = false;
            this.txKbthnLemak.Size = new System.Drawing.Size(128, 25);
            this.txKbthnLemak.TabIndex = 23;
            // 
            // txKbthnProtein
            // 
            this.txKbthnProtein.Location = new System.Drawing.Point(457, 326);
            this.txKbthnProtein.Name = "txKbthnProtein";
            this.txKbthnProtein.Properties.AutoHeight = false;
            this.txKbthnProtein.Size = new System.Drawing.Size(128, 25);
            this.txKbthnProtein.TabIndex = 20;
            // 
            // txKbthnEnergi
            // 
            this.txKbthnEnergi.Location = new System.Drawing.Point(457, 295);
            this.txKbthnEnergi.Name = "txKbthnEnergi";
            this.txKbthnEnergi.Properties.AutoHeight = false;
            this.txKbthnEnergi.Size = new System.Drawing.Size(128, 25);
            this.txKbthnEnergi.TabIndex = 17;
            // 
            // txPercenKarbo
            // 
            this.txPercenKarbo.Location = new System.Drawing.Point(306, 388);
            this.txPercenKarbo.Name = "txPercenKarbo";
            this.txPercenKarbo.Properties.AutoHeight = false;
            this.txPercenKarbo.Size = new System.Drawing.Size(128, 25);
            this.txPercenKarbo.TabIndex = 25;
            // 
            // txNilaiKarbo
            // 
            this.txNilaiKarbo.Location = new System.Drawing.Point(155, 388);
            this.txNilaiKarbo.Name = "txNilaiKarbo";
            this.txNilaiKarbo.Properties.AutoHeight = false;
            this.txNilaiKarbo.Size = new System.Drawing.Size(128, 25);
            this.txNilaiKarbo.TabIndex = 24;
            // 
            // txPercenLemak
            // 
            this.txPercenLemak.Location = new System.Drawing.Point(306, 357);
            this.txPercenLemak.Name = "txPercenLemak";
            this.txPercenLemak.Properties.AutoHeight = false;
            this.txPercenLemak.Size = new System.Drawing.Size(128, 25);
            this.txPercenLemak.TabIndex = 22;
            // 
            // txNilaiLemak
            // 
            this.txNilaiLemak.Location = new System.Drawing.Point(155, 357);
            this.txNilaiLemak.Name = "txNilaiLemak";
            this.txNilaiLemak.Properties.AutoHeight = false;
            this.txNilaiLemak.Size = new System.Drawing.Size(128, 25);
            this.txNilaiLemak.TabIndex = 21;
            // 
            // txPercenProtein
            // 
            this.txPercenProtein.Location = new System.Drawing.Point(306, 326);
            this.txPercenProtein.Name = "txPercenProtein";
            this.txPercenProtein.Properties.AutoHeight = false;
            this.txPercenProtein.Size = new System.Drawing.Size(128, 25);
            this.txPercenProtein.TabIndex = 19;
            // 
            // txNilaiProtein
            // 
            this.txNilaiProtein.Location = new System.Drawing.Point(155, 326);
            this.txNilaiProtein.Name = "txNilaiProtein";
            this.txNilaiProtein.Properties.AutoHeight = false;
            this.txNilaiProtein.Size = new System.Drawing.Size(128, 25);
            this.txNilaiProtein.TabIndex = 18;
            // 
            // txPercenEnergi
            // 
            this.txPercenEnergi.Location = new System.Drawing.Point(306, 295);
            this.txPercenEnergi.Name = "txPercenEnergi";
            this.txPercenEnergi.Properties.AutoHeight = false;
            this.txPercenEnergi.Size = new System.Drawing.Size(128, 25);
            this.txPercenEnergi.TabIndex = 16;
            // 
            // txNlaiEnergi
            // 
            this.txNlaiEnergi.Location = new System.Drawing.Point(155, 295);
            this.txNlaiEnergi.Name = "txNlaiEnergi";
            this.txNlaiEnergi.Properties.AutoHeight = false;
            this.txNlaiEnergi.Size = new System.Drawing.Size(128, 25);
            this.txNlaiEnergi.TabIndex = 15;
            // 
            // txBBU
            // 
            this.txBBU.Location = new System.Drawing.Point(194, 101);
            this.txBBU.Name = "txBBU";
            this.txBBU.Properties.AutoHeight = false;
            this.txBBU.Size = new System.Drawing.Size(100, 25);
            this.txBBU.TabIndex = 8;
            // 
            // txTgLutut
            // 
            this.txTgLutut.Location = new System.Drawing.Point(250, 70);
            this.txTgLutut.Name = "txTgLutut";
            this.txTgLutut.Properties.AutoHeight = false;
            this.txTgLutut.Size = new System.Drawing.Size(81, 25);
            this.txTgLutut.TabIndex = 6;
            // 
            // txBBTB
            // 
            this.txBBTB.Location = new System.Drawing.Point(348, 101);
            this.txBBTB.Name = "txBBTB";
            this.txBBTB.Properties.AutoHeight = false;
            this.txBBTB.Size = new System.Drawing.Size(94, 25);
            this.txBBTB.TabIndex = 9;
            // 
            // txBbDw
            // 
            this.txBbDw.Location = new System.Drawing.Point(187, 40);
            this.txBbDw.Name = "txBbDw";
            this.txBbDw.Properties.AutoHeight = false;
            this.txBbDw.Size = new System.Drawing.Size(81, 25);
            this.txBbDw.TabIndex = 3;
            // 
            // txImtAnk
            // 
            this.txImtAnk.Location = new System.Drawing.Point(487, 101);
            this.txImtAnk.Name = "txImtAnk";
            this.txImtAnk.Properties.AutoHeight = false;
            this.txImtAnk.Size = new System.Drawing.Size(98, 25);
            this.txImtAnk.TabIndex = 10;
            // 
            // txTbDw
            // 
            this.txTbDw.Location = new System.Drawing.Point(336, 40);
            this.txTbDw.Name = "txTbDw";
            this.txTbDw.Properties.AutoHeight = false;
            this.txTbDw.Size = new System.Drawing.Size(76, 25);
            this.txTbDw.TabIndex = 4;
            // 
            // txLilaDw
            // 
            this.txLilaDw.Location = new System.Drawing.Point(487, 40);
            this.txLilaDw.Name = "txLilaDw";
            this.txLilaDw.Properties.AutoHeight = false;
            this.txLilaDw.Size = new System.Drawing.Size(69, 25);
            this.txLilaDw.TabIndex = 5;
            // 
            // labelControl78
            // 
            this.labelControl78.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl78.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl78.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl78.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl78.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl78.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl78.Location = new System.Drawing.Point(385, 70);
            this.labelControl78.Name = "labelControl78";
            this.labelControl78.Size = new System.Drawing.Size(57, 25);
            this.labelControl78.TabIndex = 227;
            this.labelControl78.Text = "IMT  ";
            // 
            // txStsGizi
            // 
            this.txStsGizi.Location = new System.Drawing.Point(395, 8);
            this.txStsGizi.Name = "txStsGizi";
            this.txStsGizi.Properties.AutoHeight = false;
            this.txStsGizi.Size = new System.Drawing.Size(190, 25);
            this.txStsGizi.TabIndex = 2;
            // 
            // labelControl37
            // 
            this.labelControl37.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl37.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl37.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelControl37.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl37.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl37.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl37.Location = new System.Drawing.Point(457, 264);
            this.labelControl37.Name = "labelControl37";
            this.labelControl37.Size = new System.Drawing.Size(128, 25);
            this.labelControl37.TabIndex = 228;
            this.labelControl37.Text = "Kebutuhan";
            // 
            // labelControl39
            // 
            this.labelControl39.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl39.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl39.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelControl39.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl39.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl39.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl39.Location = new System.Drawing.Point(306, 264);
            this.labelControl39.Name = "labelControl39";
            this.labelControl39.Size = new System.Drawing.Size(128, 25);
            this.labelControl39.TabIndex = 229;
            this.labelControl39.Text = "% Dari Kebutuhan";
            // 
            // labelControl43
            // 
            this.labelControl43.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl43.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl43.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl43.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl43.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl43.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl43.Location = new System.Drawing.Point(17, 387);
            this.labelControl43.Name = "labelControl43";
            this.labelControl43.Size = new System.Drawing.Size(107, 25);
            this.labelControl43.TabIndex = 230;
            this.labelControl43.Text = "Karbohidrat (gr)  ";
            // 
            // labelControl42
            // 
            this.labelControl42.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl42.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl42.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl42.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl42.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl42.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl42.Location = new System.Drawing.Point(17, 356);
            this.labelControl42.Name = "labelControl42";
            this.labelControl42.Size = new System.Drawing.Size(107, 25);
            this.labelControl42.TabIndex = 235;
            this.labelControl42.Text = "Lemak (gr)  ";
            // 
            // labelControl41
            // 
            this.labelControl41.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl41.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl41.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl41.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl41.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl41.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl41.Location = new System.Drawing.Point(17, 325);
            this.labelControl41.Name = "labelControl41";
            this.labelControl41.Size = new System.Drawing.Size(107, 25);
            this.labelControl41.TabIndex = 236;
            this.labelControl41.Text = "Protein (gr)  ";
            // 
            // labelControl40
            // 
            this.labelControl40.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl40.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl40.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl40.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl40.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl40.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl40.Location = new System.Drawing.Point(17, 295);
            this.labelControl40.Name = "labelControl40";
            this.labelControl40.Size = new System.Drawing.Size(107, 25);
            this.labelControl40.TabIndex = 231;
            this.labelControl40.Text = "Energi (kkl) ";
            // 
            // labelControl65
            // 
            this.labelControl65.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl65.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl65.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl65.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl65.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl65.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl65.Location = new System.Drawing.Point(17, 263);
            this.labelControl65.Name = "labelControl65";
            this.labelControl65.Size = new System.Drawing.Size(107, 25);
            this.labelControl65.TabIndex = 232;
            this.labelControl65.Text = "Zat Gizi  ";
            // 
            // labelControl74
            // 
            this.labelControl74.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl74.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl74.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelControl74.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl74.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl74.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl74.Location = new System.Drawing.Point(155, 264);
            this.labelControl74.Name = "labelControl74";
            this.labelControl74.Size = new System.Drawing.Size(128, 25);
            this.labelControl74.TabIndex = 233;
            this.labelControl74.Text = "Nilai";
            // 
            // labelControl91
            // 
            this.labelControl91.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl91.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl91.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl91.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl91.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl91.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl91.Location = new System.Drawing.Point(155, 70);
            this.labelControl91.Name = "labelControl91";
            this.labelControl91.Size = new System.Drawing.Size(96, 25);
            this.labelControl91.TabIndex = 234;
            this.labelControl91.Text = "Tinggi Lutut  ";
            // 
            // labelControl84
            // 
            this.labelControl84.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl84.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl84.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl84.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl84.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl84.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl84.Location = new System.Drawing.Point(155, 101);
            this.labelControl84.Name = "labelControl84";
            this.labelControl84.Size = new System.Drawing.Size(39, 25);
            this.labelControl84.TabIndex = 239;
            this.labelControl84.Text = "BB/U  ";
            // 
            // txBbi
            // 
            this.txBbi.Location = new System.Drawing.Point(187, 9);
            this.txBbi.Name = "txBbi";
            this.txBbi.Properties.AutoHeight = false;
            this.txBbi.Size = new System.Drawing.Size(77, 25);
            this.txBbi.TabIndex = 1;
            // 
            // labelControl83
            // 
            this.labelControl83.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl83.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl83.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl83.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl83.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl83.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl83.Location = new System.Drawing.Point(303, 101);
            this.labelControl83.Name = "labelControl83";
            this.labelControl83.Size = new System.Drawing.Size(46, 25);
            this.labelControl83.TabIndex = 237;
            this.labelControl83.Text = "BB/TB ";
            // 
            // labelControl76
            // 
            this.labelControl76.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl76.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl76.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl76.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl76.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl76.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl76.Location = new System.Drawing.Point(155, 40);
            this.labelControl76.Name = "labelControl76";
            this.labelControl76.Size = new System.Drawing.Size(33, 25);
            this.labelControl76.TabIndex = 238;
            this.labelControl76.Text = "BB  ";
            // 
            // labelControl82
            // 
            this.labelControl82.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl82.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl82.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl82.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl82.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl82.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl82.Location = new System.Drawing.Point(455, 101);
            this.labelControl82.Name = "labelControl82";
            this.labelControl82.Size = new System.Drawing.Size(32, 25);
            this.labelControl82.TabIndex = 240;
            this.labelControl82.Text = "IMT  ";
            // 
            // labelControl72
            // 
            this.labelControl72.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl72.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl72.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl72.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl72.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl72.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl72.Location = new System.Drawing.Point(303, 40);
            this.labelControl72.Name = "labelControl72";
            this.labelControl72.Size = new System.Drawing.Size(33, 25);
            this.labelControl72.TabIndex = 241;
            this.labelControl72.Text = "TB  ";
            // 
            // labelControl71
            // 
            this.labelControl71.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl71.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl71.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl71.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl71.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl71.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl71.Location = new System.Drawing.Point(455, 40);
            this.labelControl71.Name = "labelControl71";
            this.labelControl71.Size = new System.Drawing.Size(32, 25);
            this.labelControl71.TabIndex = 242;
            this.labelControl71.Text = "Lila  ";
            // 
            // labelControl69
            // 
            this.labelControl69.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl69.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl69.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl69.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl69.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl69.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl69.Location = new System.Drawing.Point(303, 8);
            this.labelControl69.Name = "labelControl69";
            this.labelControl69.Size = new System.Drawing.Size(92, 25);
            this.labelControl69.TabIndex = 243;
            this.labelControl69.Text = "Status Gizi  ";
            // 
            // labelControl67
            // 
            this.labelControl67.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl67.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl67.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl67.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl67.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl67.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl67.Location = new System.Drawing.Point(155, 9);
            this.labelControl67.Name = "labelControl67";
            this.labelControl67.Size = new System.Drawing.Size(33, 25);
            this.labelControl67.TabIndex = 244;
            this.labelControl67.Text = "BBI  ";
            // 
            // labelControl68
            // 
            this.labelControl68.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl68.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl68.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl68.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl68.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl68.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl68.Location = new System.Drawing.Point(17, 132);
            this.labelControl68.Name = "labelControl68";
            this.labelControl68.Size = new System.Drawing.Size(107, 25);
            this.labelControl68.TabIndex = 226;
            this.labelControl68.Text = "Biokimia  ";
            // 
            // labelControl80
            // 
            this.labelControl80.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl80.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl80.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl80.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl80.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl80.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl80.Location = new System.Drawing.Point(17, 9);
            this.labelControl80.Name = "labelControl80";
            this.labelControl80.Size = new System.Drawing.Size(107, 25);
            this.labelControl80.TabIndex = 225;
            this.labelControl80.Text = "Antropometri  ";
            // 
            // labelControl81
            // 
            this.labelControl81.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl81.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl81.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl81.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl81.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl81.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl81.Location = new System.Drawing.Point(17, 101);
            this.labelControl81.Name = "labelControl81";
            this.labelControl81.Size = new System.Drawing.Size(107, 25);
            this.labelControl81.TabIndex = 224;
            this.labelControl81.Text = "Anak / Balita  ";
            // 
            // labelControl92
            // 
            this.labelControl92.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl92.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl92.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.labelControl92.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl92.LineLocation = DevExpress.XtraEditors.LineLocation.Top;
            this.labelControl92.LineOrientation = DevExpress.XtraEditors.LabelLineOrientation.Horizontal;
            this.labelControl92.Location = new System.Drawing.Point(17, 40);
            this.labelControl92.Name = "labelControl92";
            this.labelControl92.Size = new System.Drawing.Size(107, 25);
            this.labelControl92.TabIndex = 223;
            this.labelControl92.Text = "Dewasa  ";
            // 
            // labelControl36
            // 
            this.labelControl36.Appearance.BackColor = System.Drawing.Color.DarkGray;
            this.labelControl36.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl36.Appearance.ForeColor = System.Drawing.Color.White;
            this.labelControl36.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelControl36.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl36.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelControl36.Location = new System.Drawing.Point(0, 0);
            this.labelControl36.Name = "labelControl36";
            this.labelControl36.Size = new System.Drawing.Size(623, 30);
            this.labelControl36.TabIndex = 0;
            this.labelControl36.Text = "ASESMEN GIZI";
            // 
            // tab3
            // 
            this.tab3.Controls.Add(this.tableLayoutPanel5);
            this.tab3.Name = "tab3";
            this.tab3.Size = new System.Drawing.Size(1252, 485);
            this.tab3.Text = "B. CPPT -Jadwal Obat- Assesmen Gizi";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Controls.Add(this.splitContainerControl3, 0, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 485F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(1252, 485);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // tab1
            // 
            this.tab1.Controls.Add(this.formLayout);
            this.tab1.Name = "tab1";
            this.tab1.Size = new System.Drawing.Size(1252, 492);
            this.tab1.Text = "A1. Pengkajian Awal Medis";
            // 
            // formLayout
            // 
            this.formLayout.ColumnCount = 1;
            this.formLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.formLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.formLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.formLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.formLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.formLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.formLayout.Controls.Add(this.panel3, 0, 0);
            this.formLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.formLayout.Location = new System.Drawing.Point(0, 0);
            this.formLayout.Name = "formLayout";
            this.formLayout.RowCount = 1;
            this.formLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.formLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 485F));
            this.formLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 485F));
            this.formLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 485F));
            this.formLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 485F));
            this.formLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 485F));
            this.formLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 485F));
            this.formLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 485F));
            this.formLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 485F));
            this.formLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 485F));
            this.formLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 485F));
            this.formLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 485F));
            this.formLayout.Size = new System.Drawing.Size(1252, 492);
            this.formLayout.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.frmLayout1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1246, 486);
            this.panel3.TabIndex = 0;
            // 
            // frmLayout1
            // 
            this.frmLayout1.ColumnCount = 3;
            this.frmLayout1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 31F));
            this.frmLayout1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36F));
            this.frmLayout1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33F));
            this.frmLayout1.Controls.Add(this.layout123, 0, 0);
            this.frmLayout1.Controls.Add(this.tableLayoutPanel2, 1, 0);
            this.frmLayout1.Controls.Add(this.tableLayoutPanel3, 2, 0);
            this.frmLayout1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.frmLayout1.Location = new System.Drawing.Point(0, 0);
            this.frmLayout1.Name = "frmLayout1";
            this.frmLayout1.RowCount = 1;
            this.frmLayout1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.frmLayout1.Size = new System.Drawing.Size(1246, 486);
            this.frmLayout1.TabIndex = 0;
            // 
            // layout123
            // 
            this.layout123.ColumnCount = 1;
            this.layout123.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.layout123.Controls.Add(this.gbRwObat, 0, 2);
            this.layout123.Controls.Add(this.g1, 0, 0);
            this.layout123.Controls.Add(this.g2, 0, 1);
            this.layout123.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layout123.Location = new System.Drawing.Point(3, 3);
            this.layout123.Name = "layout123";
            this.layout123.RowCount = 3;
            this.layout123.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 21.05263F));
            this.layout123.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 78.94736F));
            this.layout123.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 55F));
            this.layout123.Size = new System.Drawing.Size(380, 480);
            this.layout123.TabIndex = 1;
            // 
            // gbRwObat
            // 
            this.gbRwObat.Controls.Add(this.txRiwayatObat);
            this.gbRwObat.Controls.Add(this.label35);
            this.gbRwObat.Controls.Add(this.rgRiwayatObat);
            this.gbRwObat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbRwObat.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbRwObat.Location = new System.Drawing.Point(3, 427);
            this.gbRwObat.Name = "gbRwObat";
            this.gbRwObat.Size = new System.Drawing.Size(374, 50);
            this.gbRwObat.TabIndex = 38;
            this.gbRwObat.TabStop = false;
            this.gbRwObat.Text = "Riwayat Penggunaan Obat";
            // 
            // txRiwayatObat
            // 
            this.txRiwayatObat.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txRiwayatObat.Enabled = false;
            this.txRiwayatObat.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txRiwayatObat.Location = new System.Drawing.Point(219, 19);
            this.txRiwayatObat.Name = "txRiwayatObat";
            this.txRiwayatObat.Size = new System.Drawing.Size(144, 21);
            this.txRiwayatObat.TabIndex = 40;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(108, 22);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(111, 13);
            this.label35.TabIndex = 2;
            this.label35.Text = "Obat yang digunkan :";
            // 
            // rgRiwayatObat
            // 
            this.rgRiwayatObat.Location = new System.Drawing.Point(6, 17);
            this.rgRiwayatObat.Name = "rgRiwayatObat";
            this.rgRiwayatObat.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgRiwayatObat.Properties.Columns = 2;
            this.rgRiwayatObat.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Tidak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Ya")});
            this.rgRiwayatObat.Size = new System.Drawing.Size(100, 23);
            this.rgRiwayatObat.TabIndex = 39;
            this.rgRiwayatObat.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // g1
            // 
            this.g1.Controls.Add(this.mmKeluhan);
            this.g1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.g1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.g1.Location = new System.Drawing.Point(3, 3);
            this.g1.Name = "g1";
            this.g1.Size = new System.Drawing.Size(374, 83);
            this.g1.TabIndex = 0;
            this.g1.TabStop = false;
            this.g1.Text = "Keluhan Utama";
            // 
            // mmKeluhan
            // 
            this.mmKeluhan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mmKeluhan.Location = new System.Drawing.Point(3, 17);
            this.mmKeluhan.Name = "mmKeluhan";
            this.mmKeluhan.Size = new System.Drawing.Size(368, 63);
            this.mmKeluhan.TabIndex = 1;
            // 
            // g2
            // 
            this.g2.Controls.Add(this.xtraScrollableControl1);
            this.g2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.g2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.g2.Location = new System.Drawing.Point(3, 92);
            this.g2.Name = "g2";
            this.g2.Size = new System.Drawing.Size(374, 329);
            this.g2.TabIndex = 2;
            this.g2.TabStop = false;
            this.g2.Text = "Riwayat Kesehatan";
            // 
            // xtraScrollableControl1
            // 
            this.xtraScrollableControl1.Controls.Add(this.gbPernahDirawat);
            this.xtraScrollableControl1.Controls.Add(this.gbRwkerja);
            this.xtraScrollableControl1.Controls.Add(this.gbRwAlergi);
            this.xtraScrollableControl1.Controls.Add(this.gbTergantungThdp);
            this.xtraScrollableControl1.Controls.Add(this.gbRwSakitKlrg);
            this.xtraScrollableControl1.Controls.Add(this.gbPernahOperasi);
            this.xtraScrollableControl1.Controls.Add(this.gbRwPenyakitlalu);
            this.xtraScrollableControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraScrollableControl1.Location = new System.Drawing.Point(3, 17);
            this.xtraScrollableControl1.Name = "xtraScrollableControl1";
            this.xtraScrollableControl1.Size = new System.Drawing.Size(368, 309);
            this.xtraScrollableControl1.TabIndex = 0;
            // 
            // gbPernahDirawat
            // 
            this.gbPernahDirawat.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbPernahDirawat.Controls.Add(this.txRawatDi);
            this.gbPernahDirawat.Controls.Add(this.txKapanRawat);
            this.gbPernahDirawat.Controls.Add(this.label4);
            this.gbPernahDirawat.Controls.Add(this.rgPernahRawat);
            this.gbPernahDirawat.Controls.Add(this.txDiagnosa);
            this.gbPernahDirawat.Controls.Add(this.label3);
            this.gbPernahDirawat.Controls.Add(this.label2);
            this.gbPernahDirawat.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbPernahDirawat.Location = new System.Drawing.Point(3, 45);
            this.gbPernahDirawat.Name = "gbPernahDirawat";
            this.gbPernahDirawat.Size = new System.Drawing.Size(365, 94);
            this.gbPernahDirawat.TabIndex = 6;
            this.gbPernahDirawat.TabStop = false;
            this.gbPernahDirawat.Text = "Pernah Dirawat ?";
            // 
            // txRawatDi
            // 
            this.txRawatDi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txRawatDi.Enabled = false;
            this.txRawatDi.Location = new System.Drawing.Point(128, 66);
            this.txRawatDi.Name = "txRawatDi";
            this.txRawatDi.Size = new System.Drawing.Size(231, 21);
            this.txRawatDi.TabIndex = 10;
            // 
            // txKapanRawat
            // 
            this.txKapanRawat.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txKapanRawat.Enabled = false;
            this.txKapanRawat.Location = new System.Drawing.Point(128, 42);
            this.txKapanRawat.Name = "txKapanRawat";
            this.txKapanRawat.Size = new System.Drawing.Size(231, 21);
            this.txKapanRawat.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(71, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Di :";
            // 
            // rgPernahRawat
            // 
            this.rgPernahRawat.Location = new System.Drawing.Point(6, 15);
            this.rgPernahRawat.Name = "rgPernahRawat";
            this.rgPernahRawat.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgPernahRawat.Properties.Columns = 1;
            this.rgPernahRawat.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Tidak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Ya")});
            this.rgPernahRawat.Size = new System.Drawing.Size(58, 50);
            this.rgPernahRawat.TabIndex = 7;
            this.rgPernahRawat.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // txDiagnosa
            // 
            this.txDiagnosa.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txDiagnosa.Enabled = false;
            this.txDiagnosa.Location = new System.Drawing.Point(128, 18);
            this.txDiagnosa.Name = "txDiagnosa";
            this.txDiagnosa.Size = new System.Drawing.Size(231, 21);
            this.txDiagnosa.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(71, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Kapan :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(70, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Diagnosa :";
            // 
            // gbRwkerja
            // 
            this.gbRwkerja.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbRwkerja.Controls.Add(this.txRwytKerja);
            this.gbRwkerja.Controls.Add(this.label33);
            this.gbRwkerja.Controls.Add(this.rgRiwayatKerja);
            this.gbRwkerja.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbRwkerja.Location = new System.Drawing.Point(3, 334);
            this.gbRwkerja.Name = "gbRwkerja";
            this.gbRwkerja.Size = new System.Drawing.Size(365, 48);
            this.gbRwkerja.TabIndex = 29;
            this.gbRwkerja.TabStop = false;
            this.gbRwkerja.Text = "Riwayat Pekerjaan (Berhubungan dengan zat berbahaya?)";
            // 
            // txRwytKerja
            // 
            this.txRwytKerja.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txRwytKerja.Enabled = false;
            this.txRwytKerja.Location = new System.Drawing.Point(170, 19);
            this.txRwytKerja.Name = "txRwytKerja";
            this.txRwytKerja.Size = new System.Drawing.Size(189, 21);
            this.txRwytKerja.TabIndex = 31;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(109, 23);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(59, 13);
            this.label33.TabIndex = 2;
            this.label33.Text = "Sebutkan :";
            // 
            // rgRiwayatKerja
            // 
            this.rgRiwayatKerja.Location = new System.Drawing.Point(6, 17);
            this.rgRiwayatKerja.Name = "rgRiwayatKerja";
            this.rgRiwayatKerja.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgRiwayatKerja.Properties.Columns = 2;
            this.rgRiwayatKerja.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Tidak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Ya")});
            this.rgRiwayatKerja.Size = new System.Drawing.Size(100, 23);
            this.rgRiwayatKerja.TabIndex = 30;
            this.rgRiwayatKerja.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // gbRwAlergi
            // 
            this.gbRwAlergi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbRwAlergi.Controls.Add(this.checkBox18);
            this.gbRwAlergi.Controls.Add(this.txAlergi);
            this.gbRwAlergi.Controls.Add(this.rgAlergi);
            this.gbRwAlergi.Controls.Add(this.txLain2);
            this.gbRwAlergi.Controls.Add(this.checkBox22);
            this.gbRwAlergi.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbRwAlergi.Location = new System.Drawing.Point(3, 383);
            this.gbRwAlergi.Name = "gbRwAlergi";
            this.gbRwAlergi.Size = new System.Drawing.Size(365, 63);
            this.gbRwAlergi.TabIndex = 32;
            this.gbRwAlergi.TabStop = false;
            this.gbRwAlergi.Text = "Riwayat Alergi";
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.Enabled = false;
            this.checkBox18.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox18.Location = new System.Drawing.Point(105, 18);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(50, 17);
            this.checkBox18.TabIndex = 34;
            this.checkBox18.Text = "Obat";
            this.checkBox18.UseVisualStyleBackColor = true;
            // 
            // txAlergi
            // 
            this.txAlergi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txAlergi.Enabled = false;
            this.txAlergi.Location = new System.Drawing.Point(169, 35);
            this.txAlergi.Name = "txAlergi";
            this.txAlergi.Size = new System.Drawing.Size(190, 21);
            this.txAlergi.TabIndex = 37;
            this.txAlergi.Tag = "etc";
            // 
            // rgAlergi
            // 
            this.rgAlergi.Location = new System.Drawing.Point(6, 13);
            this.rgAlergi.Name = "rgAlergi";
            this.rgAlergi.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgAlergi.Properties.Columns = 2;
            this.rgAlergi.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Tidak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Ya")});
            this.rgAlergi.Size = new System.Drawing.Size(100, 23);
            this.rgAlergi.TabIndex = 33;
            this.rgAlergi.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // txLain2
            // 
            this.txLain2.AutoSize = true;
            this.txLain2.Enabled = false;
            this.txLain2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txLain2.Location = new System.Drawing.Point(105, 37);
            this.txLain2.Name = "txLain2";
            this.txLain2.Size = new System.Drawing.Size(63, 17);
            this.txLain2.TabIndex = 36;
            this.txLain2.Text = "Lainnya";
            this.txLain2.UseVisualStyleBackColor = true;
            this.txLain2.CheckedChanged += new System.EventHandler(this.txLain2_CheckedChanged);
            // 
            // checkBox22
            // 
            this.checkBox22.AutoSize = true;
            this.checkBox22.Enabled = false;
            this.checkBox22.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox22.Location = new System.Drawing.Point(155, 18);
            this.checkBox22.Name = "checkBox22";
            this.checkBox22.Size = new System.Drawing.Size(69, 17);
            this.checkBox22.TabIndex = 35;
            this.checkBox22.Text = "Makanan";
            this.checkBox22.UseVisualStyleBackColor = true;
            // 
            // gbTergantungThdp
            // 
            this.gbTergantungThdp.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbTergantungThdp.Controls.Add(this.txketergantungan);
            this.gbTergantungThdp.Controls.Add(this.checkBox19);
            this.gbTergantungThdp.Controls.Add(this.checkBox20);
            this.gbTergantungThdp.Controls.Add(this.rgKetergantungan);
            this.gbTergantungThdp.Controls.Add(this.checkBox6);
            this.gbTergantungThdp.Controls.Add(this.checkBox17);
            this.gbTergantungThdp.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbTergantungThdp.Location = new System.Drawing.Point(3, 258);
            this.gbTergantungThdp.Name = "gbTergantungThdp";
            this.gbTergantungThdp.Size = new System.Drawing.Size(365, 70);
            this.gbTergantungThdp.TabIndex = 22;
            this.gbTergantungThdp.TabStop = false;
            this.gbTergantungThdp.Text = "Ketergantungan Terhadap";
            // 
            // txketergantungan
            // 
            this.txketergantungan.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txketergantungan.Enabled = false;
            this.txketergantungan.Location = new System.Drawing.Point(176, 41);
            this.txketergantungan.Name = "txketergantungan";
            this.txketergantungan.Size = new System.Drawing.Size(183, 21);
            this.txketergantungan.TabIndex = 28;
            this.txketergantungan.Tag = "etc";
            // 
            // checkBox19
            // 
            this.checkBox19.AutoSize = true;
            this.checkBox19.Enabled = false;
            this.checkBox19.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox19.Location = new System.Drawing.Point(246, 18);
            this.checkBox19.Name = "checkBox19";
            this.checkBox19.Size = new System.Drawing.Size(60, 17);
            this.checkBox19.TabIndex = 26;
            this.checkBox19.Text = "Alkohol";
            this.checkBox19.UseVisualStyleBackColor = true;
            // 
            // checkBox20
            // 
            this.checkBox20.AutoSize = true;
            this.checkBox20.Enabled = false;
            this.checkBox20.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox20.Location = new System.Drawing.Point(195, 18);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(55, 17);
            this.checkBox20.TabIndex = 25;
            this.checkBox20.Text = "Rokok";
            this.checkBox20.UseVisualStyleBackColor = true;
            // 
            // rgKetergantungan
            // 
            this.rgKetergantungan.Location = new System.Drawing.Point(6, 14);
            this.rgKetergantungan.Name = "rgKetergantungan";
            this.rgKetergantungan.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgKetergantungan.Properties.Columns = 2;
            this.rgKetergantungan.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Tidak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Ya")});
            this.rgKetergantungan.Size = new System.Drawing.Size(100, 23);
            this.rgKetergantungan.TabIndex = 23;
            this.rgKetergantungan.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Enabled = false;
            this.checkBox6.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox6.Location = new System.Drawing.Point(110, 42);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(63, 17);
            this.checkBox6.TabIndex = 27;
            this.checkBox6.Text = "Lainnya";
            this.checkBox6.UseVisualStyleBackColor = true;
            this.checkBox6.CheckedChanged += new System.EventHandler(this.txLain2_CheckedChanged);
            // 
            // checkBox17
            // 
            this.checkBox17.AutoSize = true;
            this.checkBox17.Enabled = false;
            this.checkBox17.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox17.Location = new System.Drawing.Point(110, 18);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(88, 17);
            this.checkBox17.TabIndex = 24;
            this.checkBox17.Text = "Obat-obatan";
            this.checkBox17.UseVisualStyleBackColor = true;
            // 
            // gbRwSakitKlrg
            // 
            this.gbRwSakitKlrg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbRwSakitKlrg.Controls.Add(this.checkBox13);
            this.gbRwSakitKlrg.Controls.Add(this.txSakitKlrga);
            this.gbRwSakitKlrg.Controls.Add(this.checkBox16);
            this.gbRwSakitKlrg.Controls.Add(this.rgRwSktKlrg);
            this.gbRwSakitKlrg.Controls.Add(this.checkBox28);
            this.gbRwSakitKlrg.Controls.Add(this.checkBox15);
            this.gbRwSakitKlrg.Controls.Add(this.checkBox14);
            this.gbRwSakitKlrg.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbRwSakitKlrg.Location = new System.Drawing.Point(3, 190);
            this.gbRwSakitKlrg.Name = "gbRwSakitKlrg";
            this.gbRwSakitKlrg.Size = new System.Drawing.Size(365, 67);
            this.gbRwSakitKlrg.TabIndex = 14;
            this.gbRwSakitKlrg.TabStop = false;
            this.gbRwSakitKlrg.Text = "Riwayat Penyakit Keluarga";
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Enabled = false;
            this.checkBox13.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox13.Location = new System.Drawing.Point(70, 21);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(74, 17);
            this.checkBox13.TabIndex = 16;
            this.checkBox13.Text = "Hipertensi";
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // txSakitKlrga
            // 
            this.txSakitKlrga.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txSakitKlrga.Enabled = false;
            this.txSakitKlrga.Location = new System.Drawing.Point(139, 40);
            this.txSakitKlrga.Name = "txSakitKlrga";
            this.txSakitKlrga.Size = new System.Drawing.Size(220, 21);
            this.txSakitKlrga.TabIndex = 21;
            this.txSakitKlrga.Tag = "etc";
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Enabled = false;
            this.checkBox16.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox16.Location = new System.Drawing.Point(273, 21);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(52, 17);
            this.checkBox16.TabIndex = 19;
            this.checkBox16.Text = "Ginjal";
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // rgRwSktKlrg
            // 
            this.rgRwSktKlrg.Location = new System.Drawing.Point(6, 14);
            this.rgRwSktKlrg.Name = "rgRwSktKlrg";
            this.rgRwSktKlrg.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgRwSktKlrg.Properties.Columns = 1;
            this.rgRwSktKlrg.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Tidak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Ya")});
            this.rgRwSktKlrg.Size = new System.Drawing.Size(58, 50);
            this.rgRwSktKlrg.TabIndex = 15;
            this.rgRwSktKlrg.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // checkBox28
            // 
            this.checkBox28.AutoSize = true;
            this.checkBox28.Enabled = false;
            this.checkBox28.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox28.Location = new System.Drawing.Point(70, 43);
            this.checkBox28.Name = "checkBox28";
            this.checkBox28.Size = new System.Drawing.Size(63, 17);
            this.checkBox28.TabIndex = 20;
            this.checkBox28.Text = "Lainnya";
            this.checkBox28.UseVisualStyleBackColor = true;
            this.checkBox28.CheckedChanged += new System.EventHandler(this.txLain2_CheckedChanged);
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Enabled = false;
            this.checkBox15.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox15.Location = new System.Drawing.Point(228, 21);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(41, 17);
            this.checkBox15.TabIndex = 18;
            this.checkBox15.Text = "DM";
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Enabled = false;
            this.checkBox14.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox14.Location = new System.Drawing.Point(155, 21);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(65, 17);
            this.checkBox14.TabIndex = 17;
            this.checkBox14.Text = "Jantung";
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // gbPernahOperasi
            // 
            this.gbPernahOperasi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbPernahOperasi.Controls.Add(this.rgPrnhOperasi);
            this.gbPernahOperasi.Controls.Add(this.txJnsOperasi);
            this.gbPernahOperasi.Controls.Add(this.label5);
            this.gbPernahOperasi.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbPernahOperasi.Location = new System.Drawing.Point(3, 145);
            this.gbPernahOperasi.Name = "gbPernahOperasi";
            this.gbPernahOperasi.Size = new System.Drawing.Size(365, 44);
            this.gbPernahOperasi.TabIndex = 11;
            this.gbPernahOperasi.TabStop = false;
            this.gbPernahOperasi.Text = "Pernah Operasi ?";
            // 
            // rgPrnhOperasi
            // 
            this.rgPrnhOperasi.Location = new System.Drawing.Point(6, 15);
            this.rgPrnhOperasi.Name = "rgPrnhOperasi";
            this.rgPrnhOperasi.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgPrnhOperasi.Properties.Columns = 2;
            this.rgPrnhOperasi.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Tidak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Ya")});
            this.rgPrnhOperasi.Size = new System.Drawing.Size(100, 23);
            this.rgPrnhOperasi.TabIndex = 12;
            this.rgPrnhOperasi.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // txJnsOperasi
            // 
            this.txJnsOperasi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txJnsOperasi.Enabled = false;
            this.txJnsOperasi.Location = new System.Drawing.Point(190, 17);
            this.txJnsOperasi.Name = "txJnsOperasi";
            this.txJnsOperasi.Size = new System.Drawing.Size(170, 21);
            this.txJnsOperasi.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(109, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Jenis Operasi :";
            // 
            // gbRwPenyakitlalu
            // 
            this.gbRwPenyakitlalu.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbRwPenyakitlalu.Controls.Add(this.rgSakitLalu);
            this.gbRwPenyakitlalu.Controls.Add(this.txSakitLalu);
            this.gbRwPenyakitlalu.Controls.Add(this.label1);
            this.gbRwPenyakitlalu.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbRwPenyakitlalu.Location = new System.Drawing.Point(3, 1);
            this.gbRwPenyakitlalu.Name = "gbRwPenyakitlalu";
            this.gbRwPenyakitlalu.Size = new System.Drawing.Size(365, 44);
            this.gbRwPenyakitlalu.TabIndex = 3;
            this.gbRwPenyakitlalu.TabStop = false;
            this.gbRwPenyakitlalu.Text = "Riwayat Penyakit Lalu";
            // 
            // rgSakitLalu
            // 
            this.rgSakitLalu.Location = new System.Drawing.Point(6, 15);
            this.rgSakitLalu.Name = "rgSakitLalu";
            this.rgSakitLalu.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgSakitLalu.Properties.Columns = 2;
            this.rgSakitLalu.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Tidak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Ya")});
            this.rgSakitLalu.Size = new System.Drawing.Size(100, 23);
            this.rgSakitLalu.TabIndex = 4;
            this.rgSakitLalu.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // txSakitLalu
            // 
            this.txSakitLalu.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txSakitLalu.Enabled = false;
            this.txSakitLalu.Location = new System.Drawing.Point(170, 17);
            this.txSakitLalu.Name = "txSakitLalu";
            this.txSakitLalu.Size = new System.Drawing.Size(189, 21);
            this.txSakitLalu.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(109, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Penyakit :";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.groupBox6, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(389, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(442, 480);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.Scroll2);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox6.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(3, 3);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(436, 474);
            this.groupBox6.TabIndex = 41;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Pemeriksaan Fisik";
            // 
            // Scroll2
            // 
            this.Scroll2.AllowTouchScroll = true;
            this.Scroll2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Scroll2.Controls.Add(this.groupBox11);
            this.Scroll2.Controls.Add(this.txP);
            this.Scroll2.Controls.Add(this.label36);
            this.Scroll2.Controls.Add(this.label37);
            this.Scroll2.Controls.Add(this.txSuhu);
            this.Scroll2.Controls.Add(this.label41);
            this.Scroll2.Controls.Add(this.groupBox10);
            this.Scroll2.Controls.Add(this.groupBox9);
            this.Scroll2.Controls.Add(this.groupBox8);
            this.Scroll2.Controls.Add(this.groupBox7);
            this.Scroll2.Controls.Add(this.txNadi);
            this.Scroll2.Controls.Add(this.label38);
            this.Scroll2.Controls.Add(this.label39);
            this.Scroll2.Controls.Add(this.txTd);
            this.Scroll2.Controls.Add(this.label40);
            this.Scroll2.FireScrollEventOnMouseWheel = true;
            this.Scroll2.InvertTouchScroll = true;
            this.Scroll2.Location = new System.Drawing.Point(3, 17);
            this.Scroll2.Name = "Scroll2";
            this.Scroll2.ScrollBarSmallChange = 1;
            this.Scroll2.Size = new System.Drawing.Size(430, 521);
            this.Scroll2.TabIndex = 0;
            // 
            // groupBox11
            // 
            this.groupBox11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox11.Controls.Add(this.rgPeriksaKhusus);
            this.groupBox11.Controls.Add(this.txPeriksaFisik);
            this.groupBox11.Controls.Add(this.label70);
            this.groupBox11.Controls.Add(this.label69);
            this.groupBox11.Controls.Add(this.ckLokasiLuka);
            this.groupBox11.Controls.Add(this.pictureBox3);
            this.groupBox11.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox11.Location = new System.Drawing.Point(3, 413);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(427, 169);
            this.groupBox11.TabIndex = 83;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Lokasi Luka / Lesi Lain";
            // 
            // rgPeriksaKhusus
            // 
            this.rgPeriksaKhusus.EditValue = ((short)(0));
            this.rgPeriksaKhusus.Location = new System.Drawing.Point(186, 82);
            this.rgPeriksaKhusus.Name = "rgPeriksaKhusus";
            this.rgPeriksaKhusus.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgPeriksaKhusus.Properties.Columns = 2;
            this.rgPeriksaKhusus.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Ya"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Tidak")});
            this.rgPeriksaKhusus.Size = new System.Drawing.Size(100, 23);
            this.rgPeriksaKhusus.TabIndex = 86;
            // 
            // txPeriksaFisik
            // 
            this.txPeriksaFisik.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txPeriksaFisik.Location = new System.Drawing.Point(186, 40);
            this.txPeriksaFisik.Name = "txPeriksaFisik";
            this.txPeriksaFisik.Size = new System.Drawing.Size(227, 21);
            this.txPeriksaFisik.TabIndex = 85;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(183, 66);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(229, 13);
            this.label70.TabIndex = 2;
            this.label70.Text = "Terlampir form pemeriksaan kelompok khusus :";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(183, 24);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(223, 13);
            this.label69.TabIndex = 2;
            this.label69.Text = "Pemeriksaan fisik lain terkait penyakit pasien:";
            // 
            // ckLokasiLuka
            // 
            this.ckLokasiLuka.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.ckLokasiLuka.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ckLokasiLuka.CheckOnClick = true;
            this.ckLokasiLuka.FormattingEnabled = true;
            this.ckLokasiLuka.Items.AddRange(new object[] {
            "Kepala",
            "Badan",
            "Tangan",
            "Kaki"});
            this.ckLokasiLuka.Location = new System.Drawing.Point(109, 20);
            this.ckLokasiLuka.Name = "ckLokasiLuka";
            this.ckLokasiLuka.Size = new System.Drawing.Size(63, 96);
            this.ckLokasiLuka.TabIndex = 84;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Clinic.Properties.Resources.manFronBack;
            this.pictureBox3.Location = new System.Drawing.Point(8, 18);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 100);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // txP
            // 
            this.txP.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txP.Location = new System.Drawing.Point(265, 5);
            this.txP.Name = "txP";
            this.txP.Size = new System.Drawing.Size(48, 21);
            this.txP.TabIndex = 44;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(245, 9);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(20, 13);
            this.label36.TabIndex = 44;
            this.label36.Text = "P :";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(201, 11);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(35, 11);
            this.label37.TabIndex = 43;
            this.label37.Text = "x/menit";
            // 
            // txSuhu
            // 
            this.txSuhu.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txSuhu.Location = new System.Drawing.Point(355, 5);
            this.txSuhu.Name = "txSuhu";
            this.txSuhu.Size = new System.Drawing.Size(48, 21);
            this.txSuhu.TabIndex = 45;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(319, 9);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(38, 13);
            this.label41.TabIndex = 38;
            this.label41.Text = "Suhu :";
            // 
            // groupBox10
            // 
            this.groupBox10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox10.Controls.Add(this.pnlKulit);
            this.groupBox10.Controls.Add(this.pnlDekubitus);
            this.groupBox10.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.Location = new System.Drawing.Point(2, 334);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(427, 76);
            this.groupBox10.TabIndex = 76;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Kulit Dan Kelamin";
            // 
            // pnlKulit
            // 
            this.pnlKulit.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlKulit.Controls.Add(this.txKulitDtl);
            this.pnlKulit.Controls.Add(this.label65);
            this.pnlKulit.Controls.Add(this.rgKulit);
            this.pnlKulit.Controls.Add(this.label64);
            this.pnlKulit.Location = new System.Drawing.Point(7, 15);
            this.pnlKulit.Name = "pnlKulit";
            this.pnlKulit.Size = new System.Drawing.Size(416, 26);
            this.pnlKulit.TabIndex = 77;
            // 
            // txKulitDtl
            // 
            this.txKulitDtl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txKulitDtl.Enabled = false;
            this.txKulitDtl.Location = new System.Drawing.Point(292, 3);
            this.txKulitDtl.Name = "txKulitDtl";
            this.txKulitDtl.Size = new System.Drawing.Size(116, 21);
            this.txKulitDtl.TabIndex = 79;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(235, 7);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(59, 13);
            this.label65.TabIndex = 2;
            this.label65.Text = "Sebutkan :";
            // 
            // rgKulit
            // 
            this.rgKulit.Location = new System.Drawing.Point(89, 2);
            this.rgKulit.Margin = new System.Windows.Forms.Padding(0);
            this.rgKulit.Name = "rgKulit";
            this.rgKulit.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgKulit.Properties.Columns = 2;
            this.rgKulit.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Normal"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Tidak Normal")});
            this.rgKulit.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Flow;
            this.rgKulit.Size = new System.Drawing.Size(157, 20);
            this.rgKulit.TabIndex = 78;
            this.rgKulit.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // label64
            // 
            this.label64.Location = new System.Drawing.Point(4, 6);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(82, 13);
            this.label64.TabIndex = 2;
            this.label64.Text = "Keadaan Kulit  :";
            // 
            // pnlDekubitus
            // 
            this.pnlDekubitus.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlDekubitus.Controls.Add(this.txSkorNorton);
            this.pnlDekubitus.Controls.Add(this.label63);
            this.pnlDekubitus.Controls.Add(this.label62);
            this.pnlDekubitus.Controls.Add(this.rbDekubitus);
            this.pnlDekubitus.Controls.Add(this.label66);
            this.pnlDekubitus.Location = new System.Drawing.Point(7, 42);
            this.pnlDekubitus.Name = "pnlDekubitus";
            this.pnlDekubitus.Size = new System.Drawing.Size(416, 26);
            this.pnlDekubitus.TabIndex = 80;
            // 
            // txSkorNorton
            // 
            this.txSkorNorton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txSkorNorton.Location = new System.Drawing.Point(292, 3);
            this.txSkorNorton.Name = "txSkorNorton";
            this.txSkorNorton.Size = new System.Drawing.Size(83, 21);
            this.txSkorNorton.TabIndex = 82;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(223, 7);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(71, 13);
            this.label63.TabIndex = 2;
            this.label63.Text = "Skor Norton :";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(4, 6);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(95, 13);
            this.label62.TabIndex = 2;
            this.label62.Text = "Resiko Dekubitus :";
            // 
            // rbDekubitus
            // 
            this.rbDekubitus.Location = new System.Drawing.Point(101, 1);
            this.rbDekubitus.Name = "rbDekubitus";
            this.rbDekubitus.Properties.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.rbDekubitus.Properties.Appearance.Options.UseBackColor = true;
            this.rbDekubitus.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rbDekubitus.Properties.Columns = 2;
            this.rbDekubitus.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Tidak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Ya")});
            this.rbDekubitus.Size = new System.Drawing.Size(121, 23);
            this.rbDekubitus.TabIndex = 81;
            // 
            // label66
            // 
            this.label66.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(373, 6);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(23, 13);
            this.label66.TabIndex = 2;
            this.label66.Text = "/20";
            // 
            // groupBox9
            // 
            this.groupBox9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox9.Controls.Add(this.pnlMiksi);
            this.groupBox9.Controls.Add(this.pnlDefekasi);
            this.groupBox9.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.Location = new System.Drawing.Point(3, 257);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(427, 76);
            this.groupBox9.TabIndex = 69;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Eleminasi";
            // 
            // pnlMiksi
            // 
            this.pnlMiksi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlMiksi.Controls.Add(this.txMiksiDtl);
            this.pnlMiksi.Controls.Add(this.label59);
            this.pnlMiksi.Controls.Add(this.rgMiksi);
            this.pnlMiksi.Controls.Add(this.label58);
            this.pnlMiksi.Location = new System.Drawing.Point(7, 42);
            this.pnlMiksi.Name = "pnlMiksi";
            this.pnlMiksi.Size = new System.Drawing.Size(414, 26);
            this.pnlMiksi.TabIndex = 73;
            // 
            // txMiksiDtl
            // 
            this.txMiksiDtl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txMiksiDtl.Enabled = false;
            this.txMiksiDtl.Location = new System.Drawing.Point(292, 3);
            this.txMiksiDtl.Name = "txMiksiDtl";
            this.txMiksiDtl.Size = new System.Drawing.Size(114, 21);
            this.txMiksiDtl.TabIndex = 75;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(236, 8);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(59, 13);
            this.label59.TabIndex = 2;
            this.label59.Text = "Sebutkan :";
            // 
            // rgMiksi
            // 
            this.rgMiksi.Location = new System.Drawing.Point(83, 3);
            this.rgMiksi.Margin = new System.Windows.Forms.Padding(0);
            this.rgMiksi.Name = "rgMiksi";
            this.rgMiksi.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgMiksi.Properties.Columns = 2;
            this.rgMiksi.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Normal"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Tidak Normal")});
            this.rgMiksi.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Flow;
            this.rgMiksi.Size = new System.Drawing.Size(157, 20);
            this.rgMiksi.TabIndex = 74;
            this.rgMiksi.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // label58
            // 
            this.label58.Location = new System.Drawing.Point(4, 6);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(82, 13);
            this.label58.TabIndex = 2;
            this.label58.Text = "Miksi                :";
            // 
            // pnlDefekasi
            // 
            this.pnlDefekasi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlDefekasi.Controls.Add(this.txDefekasiDtl);
            this.pnlDefekasi.Controls.Add(this.label61);
            this.pnlDefekasi.Controls.Add(this.rgDefekasi);
            this.pnlDefekasi.Controls.Add(this.label60);
            this.pnlDefekasi.Location = new System.Drawing.Point(7, 15);
            this.pnlDefekasi.Name = "pnlDefekasi";
            this.pnlDefekasi.Size = new System.Drawing.Size(414, 26);
            this.pnlDefekasi.TabIndex = 70;
            // 
            // txDefekasiDtl
            // 
            this.txDefekasiDtl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txDefekasiDtl.Enabled = false;
            this.txDefekasiDtl.Location = new System.Drawing.Point(292, 3);
            this.txDefekasiDtl.Name = "txDefekasiDtl";
            this.txDefekasiDtl.Size = new System.Drawing.Size(114, 21);
            this.txDefekasiDtl.TabIndex = 72;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(236, 8);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(59, 13);
            this.label61.TabIndex = 2;
            this.label61.Text = "Sebutkan :";
            // 
            // rgDefekasi
            // 
            this.rgDefekasi.Location = new System.Drawing.Point(83, 3);
            this.rgDefekasi.Margin = new System.Windows.Forms.Padding(0);
            this.rgDefekasi.Name = "rgDefekasi";
            this.rgDefekasi.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgDefekasi.Properties.Columns = 2;
            this.rgDefekasi.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Normal"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Tidak Normal")});
            this.rgDefekasi.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Flow;
            this.rgDefekasi.Size = new System.Drawing.Size(157, 20);
            this.rgDefekasi.TabIndex = 71;
            this.rgDefekasi.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // label60
            // 
            this.label60.Location = new System.Drawing.Point(4, 6);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(82, 13);
            this.label60.TabIndex = 2;
            this.label60.Text = "Defekasi          :";
            // 
            // groupBox8
            // 
            this.groupBox8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox8.Controls.Add(this.pnlPenglihatan);
            this.groupBox8.Controls.Add(this.pnlPendengaran);
            this.groupBox8.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(2, 180);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(427, 76);
            this.groupBox8.TabIndex = 62;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Neurosemsori";
            // 
            // pnlPenglihatan
            // 
            this.pnlPenglihatan.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlPenglihatan.Controls.Add(this.txPnglihtDtl);
            this.pnlPenglihatan.Controls.Add(this.label57);
            this.pnlPenglihatan.Controls.Add(this.rgPenglihatan);
            this.pnlPenglihatan.Controls.Add(this.label56);
            this.pnlPenglihatan.Location = new System.Drawing.Point(7, 42);
            this.pnlPenglihatan.Name = "pnlPenglihatan";
            this.pnlPenglihatan.Size = new System.Drawing.Size(415, 26);
            this.pnlPenglihatan.TabIndex = 66;
            // 
            // txPnglihtDtl
            // 
            this.txPnglihtDtl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txPnglihtDtl.Enabled = false;
            this.txPnglihtDtl.Location = new System.Drawing.Point(292, 3);
            this.txPnglihtDtl.Name = "txPnglihtDtl";
            this.txPnglihtDtl.Size = new System.Drawing.Size(117, 21);
            this.txPnglihtDtl.TabIndex = 68;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(235, 6);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(59, 13);
            this.label57.TabIndex = 2;
            this.label57.Text = "Sebutkan :";
            // 
            // rgPenglihatan
            // 
            this.rgPenglihatan.Location = new System.Drawing.Point(83, 2);
            this.rgPenglihatan.Margin = new System.Windows.Forms.Padding(0);
            this.rgPenglihatan.Name = "rgPenglihatan";
            this.rgPenglihatan.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgPenglihatan.Properties.Columns = 2;
            this.rgPenglihatan.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Normal"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Tidak Normal")});
            this.rgPenglihatan.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Flow;
            this.rgPenglihatan.Size = new System.Drawing.Size(155, 20);
            this.rgPenglihatan.TabIndex = 67;
            this.rgPenglihatan.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(4, 6);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(82, 13);
            this.label56.TabIndex = 2;
            this.label56.Text = "Penglihatan     :";
            // 
            // pnlPendengaran
            // 
            this.pnlPendengaran.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlPendengaran.Controls.Add(this.txPdngrDtl);
            this.pnlPendengaran.Controls.Add(this.label68);
            this.pnlPendengaran.Controls.Add(this.rgPendengaran);
            this.pnlPendengaran.Controls.Add(this.label67);
            this.pnlPendengaran.Location = new System.Drawing.Point(7, 15);
            this.pnlPendengaran.Name = "pnlPendengaran";
            this.pnlPendengaran.Size = new System.Drawing.Size(415, 26);
            this.pnlPendengaran.TabIndex = 63;
            // 
            // txPdngrDtl
            // 
            this.txPdngrDtl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txPdngrDtl.Enabled = false;
            this.txPdngrDtl.Location = new System.Drawing.Point(292, 3);
            this.txPdngrDtl.Name = "txPdngrDtl";
            this.txPdngrDtl.Size = new System.Drawing.Size(117, 21);
            this.txPdngrDtl.TabIndex = 65;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(235, 7);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(59, 13);
            this.label68.TabIndex = 2;
            this.label68.Text = "Sebutkan :";
            // 
            // rgPendengaran
            // 
            this.rgPendengaran.Location = new System.Drawing.Point(83, 3);
            this.rgPendengaran.Margin = new System.Windows.Forms.Padding(0);
            this.rgPendengaran.Name = "rgPendengaran";
            this.rgPendengaran.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgPendengaran.Properties.Columns = 2;
            this.rgPendengaran.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Normal"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Tidak Normal")});
            this.rgPendengaran.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Flow;
            this.rgPendengaran.Size = new System.Drawing.Size(157, 20);
            this.rgPendengaran.TabIndex = 64;
            this.rgPendengaran.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // label67
            // 
            this.label67.Location = new System.Drawing.Point(4, 6);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(82, 13);
            this.label67.TabIndex = 2;
            this.label67.Text = "Pendengaran  :";
            // 
            // groupBox7
            // 
            this.groupBox7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox7.Controls.Add(this.txImt);
            this.groupBox7.Controls.Add(this.label51);
            this.groupBox7.Controls.Add(this.txGstKet);
            this.groupBox7.Controls.Add(this.label52);
            this.groupBox7.Controls.Add(this.label50);
            this.groupBox7.Controls.Add(this.txTbPb);
            this.groupBox7.Controls.Add(this.label53);
            this.groupBox7.Controls.Add(this.label54);
            this.groupBox7.Controls.Add(this.txBB);
            this.groupBox7.Controls.Add(this.label55);
            this.groupBox7.Controls.Add(this.pnlBatasMakan);
            this.groupBox7.Controls.Add(this.pnlMuntah);
            this.groupBox7.Controls.Add(this.pnlMual);
            this.groupBox7.Controls.Add(this.pnlGigiPalsu);
            this.groupBox7.Controls.Add(this.pnKeluhan);
            this.groupBox7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(2, 29);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(427, 150);
            this.groupBox7.TabIndex = 46;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Gastrointestinal";
            // 
            // txImt
            // 
            this.txImt.Location = new System.Drawing.Point(250, 122);
            this.txImt.Name = "txImt";
            this.txImt.Size = new System.Drawing.Size(47, 21);
            this.txImt.TabIndex = 60;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(220, 126);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(32, 13);
            this.label51.TabIndex = 26;
            this.label51.Text = "IMT :";
            // 
            // txGstKet
            // 
            this.txGstKet.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txGstKet.Location = new System.Drawing.Point(334, 123);
            this.txGstKet.Name = "txGstKet";
            this.txGstKet.Size = new System.Drawing.Size(82, 21);
            this.txGstKet.TabIndex = 61;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(199, 128);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(16, 11);
            this.label52.TabIndex = 25;
            this.label52.Text = "Kg";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(306, 126);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(30, 13);
            this.label50.TabIndex = 2;
            this.label50.Text = "Ket :";
            // 
            // txTbPb
            // 
            this.txTbPb.Location = new System.Drawing.Point(142, 122);
            this.txTbPb.Name = "txTbPb";
            this.txTbPb.Size = new System.Drawing.Size(56, 21);
            this.txTbPb.TabIndex = 59;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(103, 126);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(42, 13);
            this.label53.TabIndex = 23;
            this.label53.Text = "PB/TB :";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(82, 127);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(16, 11);
            this.label54.TabIndex = 22;
            this.label54.Text = "Kg";
            // 
            // txBB
            // 
            this.txBB.Location = new System.Drawing.Point(34, 122);
            this.txBB.Name = "txBB";
            this.txBB.Size = new System.Drawing.Size(48, 21);
            this.txBB.TabIndex = 58;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(9, 126);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(26, 13);
            this.label55.TabIndex = 20;
            this.label55.Text = "BB :";
            // 
            // pnlBatasMakan
            // 
            this.pnlBatasMakan.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlBatasMakan.Controls.Add(this.label45);
            this.pnlBatasMakan.Controls.Add(this.txBtsMakan);
            this.pnlBatasMakan.Controls.Add(this.label46);
            this.pnlBatasMakan.Location = new System.Drawing.Point(7, 40);
            this.pnlBatasMakan.Name = "pnlBatasMakan";
            this.pnlBatasMakan.Size = new System.Drawing.Size(415, 26);
            this.pnlBatasMakan.TabIndex = 50;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(4, 6);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(125, 13);
            this.label45.TabIndex = 2;
            this.label45.Text = "Pembatasan Makanan   :";
            // 
            // txBtsMakan
            // 
            this.txBtsMakan.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txBtsMakan.Location = new System.Drawing.Point(196, 3);
            this.txBtsMakan.Name = "txBtsMakan";
            this.txBtsMakan.Size = new System.Drawing.Size(209, 21);
            this.txBtsMakan.TabIndex = 51;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(135, 7);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(59, 13);
            this.label46.TabIndex = 2;
            this.label46.Text = "Sebutkan :";
            // 
            // pnlMuntah
            // 
            this.pnlMuntah.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlMuntah.Controls.Add(this.rgMuntah);
            this.pnlMuntah.Controls.Add(this.label49);
            this.pnlMuntah.Location = new System.Drawing.Point(203, 92);
            this.pnlMuntah.Name = "pnlMuntah";
            this.pnlMuntah.Size = new System.Drawing.Size(219, 26);
            this.pnlMuntah.TabIndex = 56;
            // 
            // rgMuntah
            // 
            this.rgMuntah.Location = new System.Drawing.Point(56, 2);
            this.rgMuntah.Name = "rgMuntah";
            this.rgMuntah.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgMuntah.Properties.Columns = 2;
            this.rgMuntah.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem("N", "Tidak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("Y", "Ya")});
            this.rgMuntah.Size = new System.Drawing.Size(126, 20);
            this.rgMuntah.TabIndex = 57;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(4, 5);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(53, 13);
            this.label49.TabIndex = 2;
            this.label49.Text = "Muntah  :";
            // 
            // pnlMual
            // 
            this.pnlMual.Controls.Add(this.rgMual);
            this.pnlMual.Controls.Add(this.label48);
            this.pnlMual.Location = new System.Drawing.Point(7, 92);
            this.pnlMual.Name = "pnlMual";
            this.pnlMual.Size = new System.Drawing.Size(194, 26);
            this.pnlMual.TabIndex = 54;
            // 
            // rgMual
            // 
            this.rgMual.Location = new System.Drawing.Point(45, 2);
            this.rgMual.Name = "rgMual";
            this.rgMual.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgMual.Properties.Columns = 2;
            this.rgMual.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem("N", "Tidak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("Y", "Ya")});
            this.rgMual.Size = new System.Drawing.Size(126, 20);
            this.rgMual.TabIndex = 55;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(4, 5);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(42, 13);
            this.label48.TabIndex = 2;
            this.label48.Text = "Mual   :";
            // 
            // pnlGigiPalsu
            // 
            this.pnlGigiPalsu.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlGigiPalsu.Controls.Add(this.rgGigiPalsu);
            this.pnlGigiPalsu.Controls.Add(this.label47);
            this.pnlGigiPalsu.Location = new System.Drawing.Point(7, 66);
            this.pnlGigiPalsu.Name = "pnlGigiPalsu";
            this.pnlGigiPalsu.Size = new System.Drawing.Size(415, 26);
            this.pnlGigiPalsu.TabIndex = 52;
            // 
            // rgGigiPalsu
            // 
            this.rgGigiPalsu.Location = new System.Drawing.Point(76, 2);
            this.rgGigiPalsu.Name = "rgGigiPalsu";
            this.rgGigiPalsu.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgGigiPalsu.Properties.Columns = 3;
            this.rgGigiPalsu.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Gigi Atas"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Gigi Bawah"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(2)), "Tidak Ada")});
            this.rgGigiPalsu.Size = new System.Drawing.Size(242, 23);
            this.rgGigiPalsu.TabIndex = 53;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(4, 5);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(65, 13);
            this.label47.TabIndex = 2;
            this.label47.Text = "Gigi Palsu   :";
            // 
            // pnKeluhan
            // 
            this.pnKeluhan.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnKeluhan.Controls.Add(this.txKeluhan);
            this.pnKeluhan.Controls.Add(this.label43);
            this.pnKeluhan.Controls.Add(this.rgKeluhan);
            this.pnKeluhan.Controls.Add(this.label44);
            this.pnKeluhan.Location = new System.Drawing.Point(7, 15);
            this.pnKeluhan.Name = "pnKeluhan";
            this.pnKeluhan.Size = new System.Drawing.Size(415, 26);
            this.pnKeluhan.TabIndex = 47;
            // 
            // txKeluhan
            // 
            this.txKeluhan.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txKeluhan.Enabled = false;
            this.txKeluhan.Location = new System.Drawing.Point(247, 3);
            this.txKeluhan.Name = "txKeluhan";
            this.txKeluhan.Size = new System.Drawing.Size(158, 21);
            this.txKeluhan.TabIndex = 49;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(186, 6);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(59, 13);
            this.label43.TabIndex = 2;
            this.label43.Text = "Sebutkan :";
            // 
            // rgKeluhan
            // 
            this.rgKeluhan.Location = new System.Drawing.Point(66, 1);
            this.rgKeluhan.Name = "rgKeluhan";
            this.rgKeluhan.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgKeluhan.Properties.Columns = 2;
            this.rgKeluhan.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Tidak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Ya")});
            this.rgKeluhan.Size = new System.Drawing.Size(121, 23);
            this.rgKeluhan.TabIndex = 48;
            this.rgKeluhan.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(4, 6);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(64, 13);
            this.label44.TabIndex = 2;
            this.label44.Text = "Keluhan     :";
            // 
            // txNadi
            // 
            this.txNadi.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txNadi.Location = new System.Drawing.Point(152, 5);
            this.txNadi.Name = "txNadi";
            this.txNadi.Size = new System.Drawing.Size(48, 21);
            this.txNadi.TabIndex = 43;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(121, 9);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(35, 13);
            this.label38.TabIndex = 39;
            this.label38.Text = "Nadi :";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(83, 11);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(33, 11);
            this.label39.TabIndex = 37;
            this.label39.Text = "mmHg";
            // 
            // txTd
            // 
            this.txTd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txTd.Location = new System.Drawing.Point(35, 5);
            this.txTd.Name = "txTd";
            this.txTd.Size = new System.Drawing.Size(48, 21);
            this.txTd.TabIndex = 42;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(6, 9);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(27, 13);
            this.label40.TabIndex = 35;
            this.label40.Text = "TD :";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.xtraScrollableControl3, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.xtraScrollableControl4, 0, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(837, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 68F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 32F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(406, 480);
            this.tableLayoutPanel3.TabIndex = 3;
            // 
            // xtraScrollableControl3
            // 
            this.xtraScrollableControl3.Controls.Add(this.groupBox12);
            this.xtraScrollableControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraScrollableControl3.Location = new System.Drawing.Point(3, 3);
            this.xtraScrollableControl3.Name = "xtraScrollableControl3";
            this.xtraScrollableControl3.Size = new System.Drawing.Size(400, 320);
            this.xtraScrollableControl3.TabIndex = 0;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.xtraScrollableControl2);
            this.groupBox12.Controls.Add(this.groupBox13);
            this.groupBox12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox12.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox12.Location = new System.Drawing.Point(0, 0);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(400, 320);
            this.groupBox12.TabIndex = 87;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Riwayat Psikososial Dan Spiritual";
            // 
            // xtraScrollableControl2
            // 
            this.xtraScrollableControl2.Controls.Add(this.groupBox23);
            this.xtraScrollableControl2.Controls.Add(this.groupBox14);
            this.xtraScrollableControl2.Controls.Add(this.groupBox25);
            this.xtraScrollableControl2.Controls.Add(this.gbStsPsikologi);
            this.xtraScrollableControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraScrollableControl2.Location = new System.Drawing.Point(3, 17);
            this.xtraScrollableControl2.Name = "xtraScrollableControl2";
            this.xtraScrollableControl2.Size = new System.Drawing.Size(394, 300);
            this.xtraScrollableControl2.TabIndex = 0;
            // 
            // groupBox23
            // 
            this.groupBox23.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox23.Controls.Add(this.pnlTempatTinggal);
            this.groupBox23.Controls.Add(this.txTlpKerabat);
            this.groupBox23.Controls.Add(this.label75);
            this.groupBox23.Controls.Add(this.txHubKerabat);
            this.groupBox23.Controls.Add(this.label76);
            this.groupBox23.Controls.Add(this.txNmKerabat);
            this.groupBox23.Controls.Add(this.label77);
            this.groupBox23.Controls.Add(this.label74);
            this.groupBox23.Controls.Add(this.rgHubKluarga);
            this.groupBox23.Controls.Add(this.label72);
            this.groupBox23.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox23.Location = new System.Drawing.Point(4, 145);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(390, 165);
            this.groupBox23.TabIndex = 102;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "Status Sosial";
            // 
            // pnlTempatTinggal
            // 
            this.pnlTempatTinggal.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlTempatTinggal.Controls.Add(this.txTpTinggalDtl);
            this.pnlTempatTinggal.Controls.Add(this.rgTmpTinggal);
            this.pnlTempatTinggal.Controls.Add(this.label73);
            this.pnlTempatTinggal.Location = new System.Drawing.Point(9, 35);
            this.pnlTempatTinggal.Name = "pnlTempatTinggal";
            this.pnlTempatTinggal.Size = new System.Drawing.Size(377, 55);
            this.pnlTempatTinggal.TabIndex = 104;
            // 
            // txTpTinggalDtl
            // 
            this.txTpTinggalDtl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txTpTinggalDtl.Enabled = false;
            this.txTpTinggalDtl.Location = new System.Drawing.Point(98, 26);
            this.txTpTinggalDtl.Name = "txTpTinggalDtl";
            this.txTpTinggalDtl.Size = new System.Drawing.Size(275, 21);
            this.txTpTinggalDtl.TabIndex = 106;
            this.txTpTinggalDtl.Tag = "etc";
            // 
            // rgTmpTinggal
            // 
            this.rgTmpTinggal.Location = new System.Drawing.Point(93, 4);
            this.rgTmpTinggal.Margin = new System.Windows.Forms.Padding(0);
            this.rgTmpTinggal.Name = "rgTmpTinggal";
            this.rgTmpTinggal.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgTmpTinggal.Properties.Columns = 2;
            this.rgTmpTinggal.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(2, "Rumah"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(3, "Apartemen"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(4, "Panti"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(1, "Lainnya")});
            this.rgTmpTinggal.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Flow;
            this.rgTmpTinggal.Size = new System.Drawing.Size(259, 20);
            this.rgTmpTinggal.TabIndex = 105;
            this.rgTmpTinggal.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // label73
            // 
            this.label73.Location = new System.Drawing.Point(3, 6);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(89, 20);
            this.label73.TabIndex = 45;
            this.label73.Text = "Tempat Tinggal :";
            // 
            // txTlpKerabat
            // 
            this.txTlpKerabat.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txTlpKerabat.Location = new System.Drawing.Point(48, 136);
            this.txTlpKerabat.Name = "txTlpKerabat";
            this.txTlpKerabat.Size = new System.Drawing.Size(113, 21);
            this.txTlpKerabat.TabIndex = 109;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(22, 140);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(28, 13);
            this.label75.TabIndex = 48;
            this.label75.Text = "Tlp :";
            // 
            // txHubKerabat
            // 
            this.txHubKerabat.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txHubKerabat.Location = new System.Drawing.Point(221, 112);
            this.txHubKerabat.Name = "txHubKerabat";
            this.txHubKerabat.Size = new System.Drawing.Size(161, 21);
            this.txHubKerabat.TabIndex = 108;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(165, 116);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(57, 13);
            this.label76.TabIndex = 46;
            this.label76.Text = "Hubugan :";
            // 
            // txNmKerabat
            // 
            this.txNmKerabat.Location = new System.Drawing.Point(48, 112);
            this.txNmKerabat.Name = "txNmKerabat";
            this.txNmKerabat.Size = new System.Drawing.Size(113, 21);
            this.txNmKerabat.TabIndex = 107;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(9, 116);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(41, 13);
            this.label77.TabIndex = 44;
            this.label77.Text = "Nama :";
            // 
            // label74
            // 
            this.label74.BackColor = System.Drawing.Color.Transparent;
            this.label74.Location = new System.Drawing.Point(8, 95);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(197, 20);
            this.label74.TabIndex = 42;
            this.label74.Text = "Kerabat dekat yang dapat dihubungi :";
            // 
            // rgHubKluarga
            // 
            this.rgHubKluarga.Location = new System.Drawing.Point(157, 12);
            this.rgHubKluarga.Margin = new System.Windows.Forms.Padding(0);
            this.rgHubKluarga.Name = "rgHubKluarga";
            this.rgHubKluarga.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgHubKluarga.Properties.Columns = 2;
            this.rgHubKluarga.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem("Y", "Baik"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("N", "Tidak Baik")});
            this.rgHubKluarga.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Flow;
            this.rgHubKluarga.Size = new System.Drawing.Size(157, 20);
            this.rgHubKluarga.TabIndex = 103;
            // 
            // label72
            // 
            this.label72.Location = new System.Drawing.Point(9, 17);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(145, 15);
            this.label72.TabIndex = 42;
            this.label72.Text = "Hubungan dengan keluarga : ";
            // 
            // groupBox14
            // 
            this.groupBox14.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox14.Controls.Add(this.txStsMental3);
            this.groupBox14.Controls.Add(this.txStsMental2);
            this.groupBox14.Controls.Add(this.chkStasMental3);
            this.groupBox14.Controls.Add(this.chkStsMental2);
            this.groupBox14.Controls.Add(this.ckStsMental1);
            this.groupBox14.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox14.Location = new System.Drawing.Point(4, 61);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(390, 83);
            this.groupBox14.TabIndex = 96;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Status Mental";
            // 
            // txStsMental3
            // 
            this.txStsMental3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txStsMental3.Enabled = false;
            this.txStsMental3.Location = new System.Drawing.Point(216, 57);
            this.txStsMental3.Name = "txStsMental3";
            this.txStsMental3.Size = new System.Drawing.Size(166, 21);
            this.txStsMental3.TabIndex = 101;
            // 
            // txStsMental2
            // 
            this.txStsMental2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txStsMental2.Enabled = false;
            this.txStsMental2.Location = new System.Drawing.Point(130, 35);
            this.txStsMental2.Name = "txStsMental2";
            this.txStsMental2.Size = new System.Drawing.Size(252, 21);
            this.txStsMental2.TabIndex = 99;
            // 
            // chkStasMental3
            // 
            this.chkStasMental3.AutoSize = true;
            this.chkStasMental3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkStasMental3.Location = new System.Drawing.Point(9, 58);
            this.chkStasMental3.Name = "chkStasMental3";
            this.chkStasMental3.Size = new System.Drawing.Size(206, 17);
            this.chkStasMental3.TabIndex = 100;
            this.chkStasMental3.Text = "Kekerasan yang dialami sebelummnya";
            this.chkStasMental3.UseVisualStyleBackColor = true;
            this.chkStasMental3.CheckedChanged += new System.EventHandler(this.chkStasMental3_CheckedChanged);
            // 
            // chkStsMental2
            // 
            this.chkStsMental2.AutoSize = true;
            this.chkStsMental2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkStsMental2.Location = new System.Drawing.Point(9, 38);
            this.chkStsMental2.Name = "chkStsMental2";
            this.chkStsMental2.Size = new System.Drawing.Size(121, 17);
            this.chkStsMental2.TabIndex = 98;
            this.chkStsMental2.Text = "Ada masalah prilaku";
            this.chkStsMental2.UseVisualStyleBackColor = true;
            this.chkStsMental2.CheckedChanged += new System.EventHandler(this.chkStsMental2_CheckedChanged);
            // 
            // ckStsMental1
            // 
            this.ckStsMental1.AutoSize = true;
            this.ckStsMental1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ckStsMental1.Location = new System.Drawing.Point(9, 18);
            this.ckStsMental1.Name = "ckStsMental1";
            this.ckStsMental1.Size = new System.Drawing.Size(141, 17);
            this.ckStsMental1.TabIndex = 97;
            this.ckStsMental1.Text = "Sadar dan orientasi baik";
            this.ckStsMental1.UseVisualStyleBackColor = true;
            // 
            // groupBox25
            // 
            this.groupBox25.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox25.Controls.Add(this.txkegSpirit);
            this.groupBox25.Controls.Add(this.label80);
            this.groupBox25.Controls.Add(this.txkegAgama);
            this.groupBox25.Controls.Add(this.label79);
            this.groupBox25.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox25.Location = new System.Drawing.Point(5, 314);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(389, 74);
            this.groupBox25.TabIndex = 110;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "Status Spiritual";
            // 
            // txkegSpirit
            // 
            this.txkegSpirit.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txkegSpirit.Location = new System.Drawing.Point(215, 41);
            this.txkegSpirit.Name = "txkegSpirit";
            this.txkegSpirit.Size = new System.Drawing.Size(168, 21);
            this.txkegSpirit.TabIndex = 112;
            // 
            // label80
            // 
            this.label80.Location = new System.Drawing.Point(6, 44);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(210, 13);
            this.label80.TabIndex = 2;
            this.label80.Text = "Kegiatan keagamaan yang dibutuhkan     :";
            // 
            // txkegAgama
            // 
            this.txkegAgama.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txkegAgama.Location = new System.Drawing.Point(215, 16);
            this.txkegAgama.Name = "txkegAgama";
            this.txkegAgama.Size = new System.Drawing.Size(168, 21);
            this.txkegAgama.TabIndex = 111;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(6, 19);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(210, 13);
            this.label79.TabIndex = 2;
            this.label79.Text = "Kegiatan keagamaan yang bisa dilkaukan :";
            // 
            // gbStsPsikologi
            // 
            this.gbStsPsikologi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbStsPsikologi.Controls.Add(this.checkBox32);
            this.gbStsPsikologi.Controls.Add(this.checkBox33);
            this.gbStsPsikologi.Controls.Add(this.checkBox34);
            this.gbStsPsikologi.Controls.Add(this.checkBox35);
            this.gbStsPsikologi.Controls.Add(this.chkEtc5);
            this.gbStsPsikologi.Controls.Add(this.checkBox36);
            this.gbStsPsikologi.Controls.Add(this.txStsPsikologi);
            this.gbStsPsikologi.Controls.Add(this.label78);
            this.gbStsPsikologi.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbStsPsikologi.Location = new System.Drawing.Point(2, -3);
            this.gbStsPsikologi.Name = "gbStsPsikologi";
            this.gbStsPsikologi.Size = new System.Drawing.Size(392, 63);
            this.gbStsPsikologi.TabIndex = 4;
            this.gbStsPsikologi.TabStop = false;
            this.gbStsPsikologi.Text = "Status Psikologi";
            // 
            // checkBox32
            // 
            this.checkBox32.AutoSize = true;
            this.checkBox32.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox32.Location = new System.Drawing.Point(218, 18);
            this.checkBox32.Name = "checkBox32";
            this.checkBox32.Size = new System.Drawing.Size(152, 17);
            this.checkBox32.TabIndex = 93;
            this.checkBox32.Text = "Kecenderungan Bunuh Diri";
            this.checkBox32.UseVisualStyleBackColor = true;
            // 
            // checkBox33
            // 
            this.checkBox33.AutoSize = true;
            this.checkBox33.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox33.Location = new System.Drawing.Point(169, 18);
            this.checkBox33.Name = "checkBox33";
            this.checkBox33.Size = new System.Drawing.Size(52, 17);
            this.checkBox33.TabIndex = 92;
            this.checkBox33.Text = "Sedih";
            this.checkBox33.UseVisualStyleBackColor = true;
            // 
            // checkBox34
            // 
            this.checkBox34.AutoSize = true;
            this.checkBox34.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox34.Location = new System.Drawing.Point(115, 18);
            this.checkBox34.Name = "checkBox34";
            this.checkBox34.Size = new System.Drawing.Size(56, 17);
            this.checkBox34.TabIndex = 91;
            this.checkBox34.Text = "Marah";
            this.checkBox34.UseVisualStyleBackColor = true;
            // 
            // checkBox35
            // 
            this.checkBox35.AutoSize = true;
            this.checkBox35.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox35.Location = new System.Drawing.Point(66, 18);
            this.checkBox35.Name = "checkBox35";
            this.checkBox35.Size = new System.Drawing.Size(53, 17);
            this.checkBox35.TabIndex = 90;
            this.checkBox35.Text = "Takut";
            this.checkBox35.UseVisualStyleBackColor = true;
            // 
            // chkEtc5
            // 
            this.chkEtc5.AutoSize = true;
            this.chkEtc5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkEtc5.Location = new System.Drawing.Point(9, 35);
            this.chkEtc5.Name = "chkEtc5";
            this.chkEtc5.Size = new System.Drawing.Size(63, 17);
            this.chkEtc5.TabIndex = 94;
            this.chkEtc5.Text = "Lainnya";
            this.chkEtc5.UseVisualStyleBackColor = true;
            this.chkEtc5.CheckedChanged += new System.EventHandler(this.chkEtc5_CheckedChanged);
            // 
            // checkBox36
            // 
            this.checkBox36.AutoSize = true;
            this.checkBox36.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox36.Location = new System.Drawing.Point(9, 18);
            this.checkBox36.Name = "checkBox36";
            this.checkBox36.Size = new System.Drawing.Size(58, 17);
            this.checkBox36.TabIndex = 89;
            this.checkBox36.Text = "Cemas";
            this.checkBox36.UseVisualStyleBackColor = true;
            // 
            // txStsPsikologi
            // 
            this.txStsPsikologi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txStsPsikologi.Location = new System.Drawing.Point(142, 35);
            this.txStsPsikologi.Name = "txStsPsikologi";
            this.txStsPsikologi.Size = new System.Drawing.Size(244, 21);
            this.txStsPsikologi.TabIndex = 95;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(77, 37);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(59, 13);
            this.label78.TabIndex = 2;
            this.label78.Text = "Sebutkan :";
            // 
            // groupBox13
            // 
            this.groupBox13.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox13.Controls.Add(this.checkBox27);
            this.groupBox13.Controls.Add(this.checkBox26);
            this.groupBox13.Controls.Add(this.checkBox23);
            this.groupBox13.Controls.Add(this.checkBox24);
            this.groupBox13.Controls.Add(this.checkBox25);
            this.groupBox13.Controls.Add(this.checkBox21);
            this.groupBox13.Controls.Add(this.textBox41);
            this.groupBox13.Controls.Add(this.label71);
            this.groupBox13.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox13.Location = new System.Drawing.Point(4, 14);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(388, 63);
            this.groupBox13.TabIndex = 88;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Status Psikologi";
            this.groupBox13.Visible = false;
            // 
            // checkBox27
            // 
            this.checkBox27.AutoSize = true;
            this.checkBox27.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox27.Location = new System.Drawing.Point(370, 18);
            this.checkBox27.Name = "checkBox27";
            this.checkBox27.Size = new System.Drawing.Size(63, 17);
            this.checkBox27.TabIndex = 43;
            this.checkBox27.Text = "Lainnya";
            this.checkBox27.UseVisualStyleBackColor = true;
            // 
            // checkBox26
            // 
            this.checkBox26.AutoSize = true;
            this.checkBox26.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox26.Location = new System.Drawing.Point(218, 18);
            this.checkBox26.Name = "checkBox26";
            this.checkBox26.Size = new System.Drawing.Size(152, 17);
            this.checkBox26.TabIndex = 42;
            this.checkBox26.Text = "Kecenderungan Bunuh Diri";
            this.checkBox26.UseVisualStyleBackColor = true;
            // 
            // checkBox23
            // 
            this.checkBox23.AutoSize = true;
            this.checkBox23.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox23.Location = new System.Drawing.Point(169, 18);
            this.checkBox23.Name = "checkBox23";
            this.checkBox23.Size = new System.Drawing.Size(52, 17);
            this.checkBox23.TabIndex = 38;
            this.checkBox23.Text = "Sedih";
            this.checkBox23.UseVisualStyleBackColor = true;
            // 
            // checkBox24
            // 
            this.checkBox24.AutoSize = true;
            this.checkBox24.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox24.Location = new System.Drawing.Point(115, 18);
            this.checkBox24.Name = "checkBox24";
            this.checkBox24.Size = new System.Drawing.Size(56, 17);
            this.checkBox24.TabIndex = 39;
            this.checkBox24.Text = "Marah";
            this.checkBox24.UseVisualStyleBackColor = true;
            // 
            // checkBox25
            // 
            this.checkBox25.AutoSize = true;
            this.checkBox25.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox25.Location = new System.Drawing.Point(66, 18);
            this.checkBox25.Name = "checkBox25";
            this.checkBox25.Size = new System.Drawing.Size(53, 17);
            this.checkBox25.TabIndex = 40;
            this.checkBox25.Text = "Takut";
            this.checkBox25.UseVisualStyleBackColor = true;
            // 
            // checkBox21
            // 
            this.checkBox21.AutoSize = true;
            this.checkBox21.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox21.Location = new System.Drawing.Point(9, 18);
            this.checkBox21.Name = "checkBox21";
            this.checkBox21.Size = new System.Drawing.Size(58, 17);
            this.checkBox21.TabIndex = 41;
            this.checkBox21.Text = "Cemas";
            this.checkBox21.UseVisualStyleBackColor = true;
            // 
            // textBox41
            // 
            this.textBox41.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox41.Location = new System.Drawing.Point(67, 35);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(315, 21);
            this.textBox41.TabIndex = 4;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(6, 38);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(59, 13);
            this.label71.TabIndex = 2;
            this.label71.Text = "Sebutkan :";
            // 
            // xtraScrollableControl4
            // 
            this.xtraScrollableControl4.Controls.Add(this.label96);
            this.xtraScrollableControl4.Controls.Add(this.rgMnrimaInfo);
            this.xtraScrollableControl4.Controls.Add(this.pnlButuhPnrjmh);
            this.xtraScrollableControl4.Controls.Add(this.pnlKbthnEdukasi);
            this.xtraScrollableControl4.Controls.Add(this.pnlSedia);
            this.xtraScrollableControl4.Controls.Add(this.label82);
            this.xtraScrollableControl4.Controls.Add(this.gbResikoCedera);
            this.xtraScrollableControl4.Controls.Add(this.gbHambatanBljr);
            this.xtraScrollableControl4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraScrollableControl4.FireScrollEventOnMouseWheel = true;
            this.xtraScrollableControl4.Location = new System.Drawing.Point(3, 329);
            this.xtraScrollableControl4.Name = "xtraScrollableControl4";
            this.xtraScrollableControl4.ScrollBarSmallChange = 1;
            this.xtraScrollableControl4.Size = new System.Drawing.Size(400, 148);
            this.xtraScrollableControl4.TabIndex = 1;
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label96.Location = new System.Drawing.Point(2, 249);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(160, 13);
            this.label96.TabIndex = 50;
            this.label96.Text = "Kesediaan menerima Informasi :";
            // 
            // rgMnrimaInfo
            // 
            this.rgMnrimaInfo.Location = new System.Drawing.Point(162, 245);
            this.rgMnrimaInfo.Name = "rgMnrimaInfo";
            this.rgMnrimaInfo.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgMnrimaInfo.Properties.Columns = 2;
            this.rgMnrimaInfo.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem("Y", "Ya"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("N", "Tidak")});
            this.rgMnrimaInfo.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Flow;
            this.rgMnrimaInfo.Size = new System.Drawing.Size(109, 29);
            this.rgMnrimaInfo.TabIndex = 137;
            // 
            // pnlButuhPnrjmh
            // 
            this.pnlButuhPnrjmh.Controls.Add(this.txPnrjmhDtl);
            this.pnlButuhPnrjmh.Controls.Add(this.rgPnrjemah);
            this.pnlButuhPnrjmh.Controls.Add(this.label81);
            this.pnlButuhPnrjmh.Location = new System.Drawing.Point(2, 40);
            this.pnlButuhPnrjmh.Name = "pnlButuhPnrjmh";
            this.pnlButuhPnrjmh.Size = new System.Drawing.Size(378, 27);
            this.pnlButuhPnrjmh.TabIndex = 48;
            // 
            // txPnrjmhDtl
            // 
            this.txPnrjmhDtl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txPnrjmhDtl.Enabled = false;
            this.txPnrjmhDtl.Location = new System.Drawing.Point(222, 3);
            this.txPnrjmhDtl.Name = "txPnrjmhDtl";
            this.txPnrjmhDtl.Size = new System.Drawing.Size(154, 21);
            this.txPnrjmhDtl.TabIndex = 120;
            // 
            // rgPnrjemah
            // 
            this.rgPnrjemah.Location = new System.Drawing.Point(131, 3);
            this.rgPnrjemah.Name = "rgPnrjemah";
            this.rgPnrjemah.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgPnrjemah.Properties.Columns = 2;
            this.rgPnrjemah.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Tidak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Ya")});
            this.rgPnrjemah.Size = new System.Drawing.Size(106, 19);
            this.rgPnrjemah.TabIndex = 119;
            this.rgPnrjemah.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(4, 7);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(128, 13);
            this.label81.TabIndex = 10;
            this.label81.Text = "Dibutuhkan Penerjemah :";
            // 
            // pnlKbthnEdukasi
            // 
            this.pnlKbthnEdukasi.Controls.Add(this.txKbthnEdukasi);
            this.pnlKbthnEdukasi.Controls.Add(this.chkEtc12);
            this.pnlKbthnEdukasi.Controls.Add(this.txHmbtan);
            this.pnlKbthnEdukasi.Controls.Add(this.checkBox44);
            this.pnlKbthnEdukasi.Controls.Add(this.checkBox9);
            this.pnlKbthnEdukasi.Controls.Add(this.txSedia);
            this.pnlKbthnEdukasi.Controls.Add(this.checkBox12);
            this.pnlKbthnEdukasi.Controls.Add(this.checkBox11);
            this.pnlKbthnEdukasi.Controls.Add(this.checkBox8);
            this.pnlKbthnEdukasi.Controls.Add(this.checkBox7);
            this.pnlKbthnEdukasi.Location = new System.Drawing.Point(4, 84);
            this.pnlKbthnEdukasi.Name = "pnlKbthnEdukasi";
            this.pnlKbthnEdukasi.Size = new System.Drawing.Size(376, 85);
            this.pnlKbthnEdukasi.TabIndex = 121;
            // 
            // txKbthnEdukasi
            // 
            this.txKbthnEdukasi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txKbthnEdukasi.Enabled = false;
            this.txKbthnEdukasi.Location = new System.Drawing.Point(74, 57);
            this.txKbthnEdukasi.Name = "txKbthnEdukasi";
            this.txKbthnEdukasi.Size = new System.Drawing.Size(292, 21);
            this.txKbthnEdukasi.TabIndex = 129;
            this.txKbthnEdukasi.Tag = "etc";
            // 
            // chkEtc12
            // 
            this.chkEtc12.AutoSize = true;
            this.chkEtc12.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkEtc12.Location = new System.Drawing.Point(2, 57);
            this.chkEtc12.Name = "chkEtc12";
            this.chkEtc12.Size = new System.Drawing.Size(63, 17);
            this.chkEtc12.TabIndex = 128;
            this.chkEtc12.Text = "Lainnya";
            this.chkEtc12.UseVisualStyleBackColor = true;
            this.chkEtc12.CheckedChanged += new System.EventHandler(this.chkEtc12_CheckedChanged);
            // 
            // txHmbtan
            // 
            this.txHmbtan.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txHmbtan.Enabled = false;
            this.txHmbtan.Location = new System.Drawing.Point(378, 57);
            this.txHmbtan.Name = "txHmbtan";
            this.txHmbtan.Size = new System.Drawing.Size(2, 21);
            this.txHmbtan.TabIndex = 74;
            this.txHmbtan.Visible = false;
            // 
            // checkBox44
            // 
            this.checkBox44.AutoSize = true;
            this.checkBox44.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox44.Location = new System.Drawing.Point(216, 39);
            this.checkBox44.Name = "checkBox44";
            this.checkBox44.Size = new System.Drawing.Size(109, 17);
            this.checkBox44.TabIndex = 127;
            this.checkBox44.Text = "Manajemen Nyeri";
            this.checkBox44.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox9.Location = new System.Drawing.Point(2, 39);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(128, 17);
            this.checkBox9.TabIndex = 126;
            this.checkBox9.Text = "Obat-obatan / Terapi";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // txSedia
            // 
            this.txSedia.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txSedia.Enabled = false;
            this.txSedia.Location = new System.Drawing.Point(374, 57);
            this.txSedia.Name = "txSedia";
            this.txSedia.Size = new System.Drawing.Size(2, 21);
            this.txSedia.TabIndex = 73;
            this.txSedia.Visible = false;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox12.Location = new System.Drawing.Point(216, 21);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(99, 17);
            this.checkBox12.TabIndex = 125;
            this.checkBox12.Text = "Diet dan Nutrisi";
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox11.Location = new System.Drawing.Point(216, 3);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(80, 17);
            this.checkBox11.TabIndex = 123;
            this.checkBox11.Text = "Rehabilitasi";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox8.Location = new System.Drawing.Point(2, 21);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(136, 17);
            this.checkBox8.TabIndex = 124;
            this.checkBox8.Text = "Tindakan Keperawatan";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox7.Location = new System.Drawing.Point(2, 3);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(193, 17);
            this.checkBox7.TabIndex = 122;
            this.checkBox7.Text = "Diagnosa dan Manajemen Penyakit";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // pnlSedia
            // 
            this.pnlSedia.Controls.Add(this.checkBox42);
            this.pnlSedia.Controls.Add(this.checkBox43);
            this.pnlSedia.Controls.Add(this.checkBox41);
            this.pnlSedia.Controls.Add(this.rgSedia);
            this.pnlSedia.Controls.Add(this.label84);
            this.pnlSedia.Location = new System.Drawing.Point(1, 175);
            this.pnlSedia.Name = "pnlSedia";
            this.pnlSedia.Size = new System.Drawing.Size(379, 26);
            this.pnlSedia.TabIndex = 130;
            // 
            // checkBox42
            // 
            this.checkBox42.AutoSize = true;
            this.checkBox42.Enabled = false;
            this.checkBox42.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox42.Location = new System.Drawing.Point(292, 6);
            this.checkBox42.Name = "checkBox42";
            this.checkBox42.Size = new System.Drawing.Size(85, 17);
            this.checkBox42.TabIndex = 134;
            this.checkBox42.Text = "Rohaniawan";
            this.checkBox42.UseVisualStyleBackColor = true;
            // 
            // checkBox43
            // 
            this.checkBox43.AutoSize = true;
            this.checkBox43.Enabled = false;
            this.checkBox43.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox43.Location = new System.Drawing.Point(233, 6);
            this.checkBox43.Name = "checkBox43";
            this.checkBox43.Size = new System.Drawing.Size(64, 17);
            this.checkBox43.TabIndex = 133;
            this.checkBox43.Text = "Kerabat";
            this.checkBox43.UseVisualStyleBackColor = true;
            // 
            // checkBox41
            // 
            this.checkBox41.AutoSize = true;
            this.checkBox41.Enabled = false;
            this.checkBox41.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox41.Location = new System.Drawing.Point(168, 6);
            this.checkBox41.Name = "checkBox41";
            this.checkBox41.Size = new System.Drawing.Size(68, 17);
            this.checkBox41.TabIndex = 132;
            this.checkBox41.Text = "Keluarga";
            this.checkBox41.UseVisualStyleBackColor = true;
            // 
            // rgSedia
            // 
            this.rgSedia.Location = new System.Drawing.Point(84, 2);
            this.rgSedia.Name = "rgSedia";
            this.rgSedia.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgSedia.Properties.Columns = 2;
            this.rgSedia.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Tidak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Ya")});
            this.rgSedia.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Column;
            this.rgSedia.Size = new System.Drawing.Size(95, 23);
            this.rgSedia.TabIndex = 131;
            this.rgSedia.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(1, 7);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(85, 13);
            this.label84.TabIndex = 8;
            this.label84.Text = "Mau dikunjungi :";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(4, 68);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(111, 13);
            this.label82.TabIndex = 8;
            this.label82.Text = "Kebutuhuan Edukasi :";
            // 
            // gbResikoCedera
            // 
            this.gbResikoCedera.Controls.Add(this.label83);
            this.gbResikoCedera.Controls.Add(this.rgResikoCedera);
            this.gbResikoCedera.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbResikoCedera.Location = new System.Drawing.Point(3, 205);
            this.gbResikoCedera.Name = "gbResikoCedera";
            this.gbResikoCedera.Size = new System.Drawing.Size(377, 40);
            this.gbResikoCedera.TabIndex = 135;
            this.gbResikoCedera.TabStop = false;
            this.gbResikoCedera.Text = "Resiko Cedera/Jatuh (isi formulir monitoring pencegahan jatuh)";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.ForeColor = System.Drawing.Color.Red;
            this.label83.Location = new System.Drawing.Point(90, 19);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(277, 13);
            this.label83.TabIndex = 8;
            this.label83.Text = "Jika ya, gelang risiko jatuh warna kuning harus dipasang";
            // 
            // rgResikoCedera
            // 
            this.rgResikoCedera.Location = new System.Drawing.Point(6, 14);
            this.rgResikoCedera.Name = "rgResikoCedera";
            this.rgResikoCedera.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgResikoCedera.Properties.Columns = 2;
            this.rgResikoCedera.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Tidak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Ya")});
            this.rgResikoCedera.Size = new System.Drawing.Size(102, 20);
            this.rgResikoCedera.TabIndex = 136;
            // 
            // gbHambatanBljr
            // 
            this.gbHambatanBljr.Controls.Add(this.checkBox40);
            this.gbHambatanBljr.Controls.Add(this.checkBox39);
            this.gbHambatanBljr.Controls.Add(this.checkBox38);
            this.gbHambatanBljr.Controls.Add(this.checkBox37);
            this.gbHambatanBljr.Controls.Add(this.rgHmbtanBljr);
            this.gbHambatanBljr.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbHambatanBljr.Location = new System.Drawing.Point(2, 0);
            this.gbHambatanBljr.Name = "gbHambatanBljr";
            this.gbHambatanBljr.Size = new System.Drawing.Size(378, 40);
            this.gbHambatanBljr.TabIndex = 113;
            this.gbHambatanBljr.TabStop = false;
            this.gbHambatanBljr.Text = "Terdapat Hambatan dalam pembelajran";
            // 
            // checkBox40
            // 
            this.checkBox40.AutoSize = true;
            this.checkBox40.Enabled = false;
            this.checkBox40.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox40.Location = new System.Drawing.Point(315, 17);
            this.checkBox40.Name = "checkBox40";
            this.checkBox40.Size = new System.Drawing.Size(46, 17);
            this.checkBox40.TabIndex = 118;
            this.checkBox40.Text = "Fisik";
            this.checkBox40.UseVisualStyleBackColor = true;
            // 
            // checkBox39
            // 
            this.checkBox39.AutoSize = true;
            this.checkBox39.Enabled = false;
            this.checkBox39.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox39.Location = new System.Drawing.Point(255, 17);
            this.checkBox39.Name = "checkBox39";
            this.checkBox39.Size = new System.Drawing.Size(62, 17);
            this.checkBox39.TabIndex = 117;
            this.checkBox39.Text = "Kognitif";
            this.checkBox39.UseVisualStyleBackColor = true;
            // 
            // checkBox38
            // 
            this.checkBox38.AutoSize = true;
            this.checkBox38.Enabled = false;
            this.checkBox38.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox38.Location = new System.Drawing.Point(178, 16);
            this.checkBox38.Name = "checkBox38";
            this.checkBox38.Size = new System.Drawing.Size(82, 17);
            this.checkBox38.TabIndex = 116;
            this.checkBox38.Text = "Penglihatan";
            this.checkBox38.UseVisualStyleBackColor = true;
            // 
            // checkBox37
            // 
            this.checkBox37.AutoSize = true;
            this.checkBox37.Enabled = false;
            this.checkBox37.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox37.Location = new System.Drawing.Point(92, 16);
            this.checkBox37.Name = "checkBox37";
            this.checkBox37.Size = new System.Drawing.Size(90, 17);
            this.checkBox37.TabIndex = 115;
            this.checkBox37.Text = "Pendengaran";
            this.checkBox37.UseVisualStyleBackColor = true;
            // 
            // rgHmbtanBljr
            // 
            this.rgHmbtanBljr.Location = new System.Drawing.Point(6, 14);
            this.rgHmbtanBljr.Name = "rgHmbtanBljr";
            this.rgHmbtanBljr.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgHmbtanBljr.Properties.Columns = 2;
            this.rgHmbtanBljr.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Tidak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Ya")});
            this.rgHmbtanBljr.Size = new System.Drawing.Size(103, 20);
            this.rgHmbtanBljr.TabIndex = 114;
            this.rgHmbtanBljr.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.btnSimpan);
            this.panel1.Controls.Add(this.labelControl1);
            this.panel1.Controls.Add(this.btnInputData);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1258, 32);
            this.panel1.TabIndex = 0;
            // 
            // btnSimpan
            // 
            this.btnSimpan.Image = ((System.Drawing.Image)(resources.GetObject("btnSimpan.Image")));
            this.btnSimpan.Location = new System.Drawing.Point(1161, 4);
            this.btnSimpan.Name = "btnSimpan";
            this.btnSimpan.Size = new System.Drawing.Size(91, 23);
            this.btnSimpan.TabIndex = 26;
            this.btnSimpan.Text = "Simpan";
            this.btnSimpan.Click += new System.EventHandler(this.btnSimpan_Click);
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Location = new System.Drawing.Point(10, 5);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(197, 19);
            this.labelControl1.TabIndex = 2;
            this.labelControl1.Text = "Daftar List Pemeriksaan";
            // 
            // btnInputData
            // 
            this.btnInputData.Location = new System.Drawing.Point(705, 9);
            this.btnInputData.Name = "btnInputData";
            this.btnInputData.Size = new System.Drawing.Size(103, 16);
            this.btnInputData.TabIndex = 0;
            this.btnInputData.Text = "Mulai Input Data";
            this.btnInputData.UseVisualStyleBackColor = true;
            this.btnInputData.Visible = false;
            this.btnInputData.Click += new System.EventHandler(this.btnInputData_Click);
            // 
            // splitContainerControl1
            // 
            this.splitContainerControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerControl1.FixedPanel = DevExpress.XtraEditors.SplitFixedPanel.None;
            this.splitContainerControl1.Horizontal = false;
            this.splitContainerControl1.Location = new System.Drawing.Point(3, 46);
            this.splitContainerControl1.Name = "splitContainerControl1";
            this.splitContainerControl1.Panel1.Controls.Add(this.panTbl);
            this.splitContainerControl1.Panel1.Text = "Panel1";
            this.splitContainerControl1.Panel2.Controls.Add(this.mainTab);
            this.splitContainerControl1.Panel2.Text = "Panel2";
            this.splitContainerControl1.Size = new System.Drawing.Size(1258, 632);
            this.splitContainerControl1.SplitterPosition = 106;
            this.splitContainerControl1.TabIndex = 5;
            this.splitContainerControl1.Text = "splitContainerControl1";
            // 
            // panTbl
            // 
            this.panTbl.Controls.Add(this.grdMain);
            this.panTbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panTbl.Location = new System.Drawing.Point(0, 0);
            this.panTbl.Name = "panTbl";
            this.panTbl.Size = new System.Drawing.Size(1258, 107);
            this.panTbl.TabIndex = 0;
            // 
            // grdMain
            // 
            this.grdMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdMain.Location = new System.Drawing.Point(0, 0);
            this.grdMain.MainView = this.gvwMain;
            this.grdMain.Name = "grdMain";
            this.grdMain.Size = new System.Drawing.Size(1258, 107);
            this.grdMain.TabIndex = 0;
            this.grdMain.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvwMain});
            this.grdMain.DoubleClick += new System.EventHandler(this.grdMain_DoubleClick);
            // 
            // gvwMain
            // 
            this.gvwMain.Appearance.FocusedCell.BackColor = System.Drawing.Color.Honeydew;
            this.gvwMain.Appearance.FocusedCell.BackColor2 = System.Drawing.Color.Honeydew;
            this.gvwMain.Appearance.FocusedCell.BorderColor = System.Drawing.Color.Honeydew;
            this.gvwMain.Appearance.FocusedCell.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gvwMain.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gvwMain.Appearance.FocusedCell.Options.UseBorderColor = true;
            this.gvwMain.Appearance.FocusedCell.Options.UseFont = true;
            this.gvwMain.Appearance.FocusedRow.BackColor = System.Drawing.Color.Honeydew;
            this.gvwMain.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.Honeydew;
            this.gvwMain.Appearance.FocusedRow.BorderColor = System.Drawing.Color.Honeydew;
            this.gvwMain.Appearance.FocusedRow.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.gvwMain.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gvwMain.Appearance.FocusedRow.Options.UseBorderColor = true;
            this.gvwMain.Appearance.FocusedRow.Options.UseFont = true;
            this.gvwMain.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn28,
            this.gridColumn29,
            this.gridColumn30,
            this.gridColumn31,
            this.gridColumn32,
            this.gridColumn33,
            this.gridColumn34,
            this.gridColumn35});
            this.gvwMain.GridControl = this.grdMain;
            this.gvwMain.IndicatorWidth = 40;
            this.gvwMain.Name = "gvwMain";
            this.gvwMain.OptionsView.ShowGroupPanel = false;
            this.gvwMain.CustomDrawRowIndicator += new DevExpress.XtraGrid.Views.Grid.RowIndicatorCustomDrawEventHandler(this.gvwMain_CustomDrawRowIndicator);
            // 
            // gridColumn28
            // 
            this.gridColumn28.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn28.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn28.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn28.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn28.Caption = "RM NO";
            this.gridColumn28.FieldName = "RM_NO";
            this.gridColumn28.Name = "gridColumn28";
            this.gridColumn28.OptionsColumn.AllowEdit = false;
            this.gridColumn28.OptionsColumn.ReadOnly = true;
            this.gridColumn28.Visible = true;
            this.gridColumn28.VisibleIndex = 0;
            // 
            // gridColumn29
            // 
            this.gridColumn29.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn29.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn29.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn29.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn29.Caption = "PASIEN NO";
            this.gridColumn29.FieldName = "PATIENT_NO";
            this.gridColumn29.Name = "gridColumn29";
            this.gridColumn29.OptionsColumn.AllowEdit = false;
            this.gridColumn29.OptionsColumn.ReadOnly = true;
            this.gridColumn29.Visible = true;
            this.gridColumn29.VisibleIndex = 1;
            // 
            // gridColumn30
            // 
            this.gridColumn30.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn30.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn30.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn30.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn30.Caption = "Tanggal Masuk";
            this.gridColumn30.FieldName = "INSP_DATE";
            this.gridColumn30.Name = "gridColumn30";
            this.gridColumn30.OptionsColumn.AllowEdit = false;
            this.gridColumn30.OptionsColumn.ReadOnly = true;
            this.gridColumn30.Visible = true;
            this.gridColumn30.VisibleIndex = 2;
            // 
            // gridColumn31
            // 
            this.gridColumn31.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn31.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn31.Caption = "NAMA PASIEN";
            this.gridColumn31.FieldName = "NAME";
            this.gridColumn31.Name = "gridColumn31";
            this.gridColumn31.OptionsColumn.AllowEdit = false;
            this.gridColumn31.OptionsColumn.ReadOnly = true;
            this.gridColumn31.Visible = true;
            this.gridColumn31.VisibleIndex = 3;
            // 
            // gridColumn32
            // 
            this.gridColumn32.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn32.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn32.Caption = "TIPE PASIEN";
            this.gridColumn32.FieldName = "GROUP_PATIENT";
            this.gridColumn32.Name = "gridColumn32";
            this.gridColumn32.OptionsColumn.AllowEdit = false;
            this.gridColumn32.OptionsColumn.ReadOnly = true;
            this.gridColumn32.Visible = true;
            this.gridColumn32.VisibleIndex = 4;
            // 
            // gridColumn33
            // 
            this.gridColumn33.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn33.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn33.Caption = "STATUS";
            this.gridColumn33.FieldName = "STATUS";
            this.gridColumn33.Name = "gridColumn33";
            this.gridColumn33.OptionsColumn.AllowEdit = false;
            this.gridColumn33.OptionsColumn.ReadOnly = true;
            this.gridColumn33.Visible = true;
            this.gridColumn33.VisibleIndex = 5;
            // 
            // gridColumn34
            // 
            this.gridColumn34.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn34.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn34.Caption = "PENJAMIN";
            this.gridColumn34.FieldName = "FAMILY_HEAD";
            this.gridColumn34.Name = "gridColumn34";
            this.gridColumn34.OptionsColumn.AllowEdit = false;
            this.gridColumn34.OptionsColumn.ReadOnly = true;
            this.gridColumn34.Visible = true;
            this.gridColumn34.VisibleIndex = 6;
            // 
            // gridColumn35
            // 
            this.gridColumn35.Caption = "ID";
            this.gridColumn35.FieldName = "ANAMNESA_ID";
            this.gridColumn35.Name = "gridColumn35";
            // 
            // mainTab
            // 
            this.mainTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainTab.Enabled = false;
            this.mainTab.Location = new System.Drawing.Point(0, 0);
            this.mainTab.Name = "mainTab";
            this.mainTab.SelectedTabPage = this.tab1;
            this.mainTab.Size = new System.Drawing.Size(1258, 520);
            this.mainTab.TabIndex = 4;
            this.mainTab.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.tab1,
            this.tab2,
            this.tab3,
            this.tab5});
            // 
            // tab2
            // 
            this.tab2.Controls.Add(this.tableLayoutPanel4);
            this.tab2.Name = "tab2";
            this.tab2.Size = new System.Drawing.Size(1252, 485);
            this.tab2.Text = "A2. Pengkajian Awal Medis";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel7, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.tableLayoutPanel6, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(1252, 485);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 1;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.Controls.Add(this.groupBox18, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.pnlRisikoJatuh, 0, 1);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(629, 3);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 27.29084F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 72.70916F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(620, 479);
            this.tableLayoutPanel7.TabIndex = 3;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.tableLayoutPanel13);
            this.groupBox18.Controls.Add(this.panel13);
            this.groupBox18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox18.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox18.Location = new System.Drawing.Point(3, 3);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(614, 124);
            this.groupBox18.TabIndex = 0;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Daftar Masalah Keperawatan Prioritas";
            // 
            // tableLayoutPanel13
            // 
            this.tableLayoutPanel13.ColumnCount = 3;
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel13.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel13.Controls.Add(this.panel15, 0, 0);
            this.tableLayoutPanel13.Controls.Add(this.panel18, 1, 0);
            this.tableLayoutPanel13.Controls.Add(this.panel19, 2, 0);
            this.tableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel13.Location = new System.Drawing.Point(3, 17);
            this.tableLayoutPanel13.Name = "tableLayoutPanel13";
            this.tableLayoutPanel13.RowCount = 1;
            this.tableLayoutPanel13.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel13.Size = new System.Drawing.Size(608, 81);
            this.tableLayoutPanel13.TabIndex = 1;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.mmPerawat);
            this.panel15.Controls.Add(this.label88);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(3, 3);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(196, 75);
            this.panel15.TabIndex = 0;
            // 
            // mmPerawat
            // 
            this.mmPerawat.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mmPerawat.Location = new System.Drawing.Point(4, 20);
            this.mmPerawat.Name = "mmPerawat";
            this.mmPerawat.Size = new System.Drawing.Size(189, 52);
            this.mmPerawat.TabIndex = 34;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.Location = new System.Drawing.Point(4, 5);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(47, 13);
            this.label88.TabIndex = 8;
            this.label88.Text = "Perawat";
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.mmDokter);
            this.panel18.Controls.Add(this.label13);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel18.Location = new System.Drawing.Point(205, 3);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(196, 75);
            this.panel18.TabIndex = 1;
            // 
            // mmDokter
            // 
            this.mmDokter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mmDokter.Location = new System.Drawing.Point(3, 21);
            this.mmDokter.Name = "mmDokter";
            this.mmDokter.Size = new System.Drawing.Size(190, 51);
            this.mmDokter.TabIndex = 35;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(3, 6);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(39, 13);
            this.label13.TabIndex = 8;
            this.label13.Text = "Dokter";
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.mmTujuanTerukur);
            this.panel19.Controls.Add(this.label90);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel19.Location = new System.Drawing.Point(407, 3);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(198, 75);
            this.panel19.TabIndex = 2;
            // 
            // mmTujuanTerukur
            // 
            this.mmTujuanTerukur.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.mmTujuanTerukur.Location = new System.Drawing.Point(4, 21);
            this.mmTujuanTerukur.Name = "mmTujuanTerukur";
            this.mmTujuanTerukur.Size = new System.Drawing.Size(191, 51);
            this.mmTujuanTerukur.TabIndex = 36;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label90.Location = new System.Drawing.Point(4, 7);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(80, 13);
            this.label90.TabIndex = 8;
            this.label90.Text = "Tujuan Terukur";
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.chkSusunRencana);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel13.Location = new System.Drawing.Point(3, 98);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(608, 23);
            this.panel13.TabIndex = 0;
            // 
            // chkSusunRencana
            // 
            this.chkSusunRencana.AutoSize = true;
            this.chkSusunRencana.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkSusunRencana.Location = new System.Drawing.Point(6, 5);
            this.chkSusunRencana.Name = "chkSusunRencana";
            this.chkSusunRencana.Size = new System.Drawing.Size(175, 17);
            this.chkSusunRencana.TabIndex = 44;
            this.chkSusunRencana.Text = "Disusun Rencana Keperawatan";
            this.chkSusunRencana.UseVisualStyleBackColor = true;
            // 
            // pnlRisikoJatuh
            // 
            this.pnlRisikoJatuh.Controls.Add(this.pnlRJAnak);
            this.pnlRisikoJatuh.Controls.Add(this.pnlRJDewasa);
            this.pnlRisikoJatuh.Controls.Add(this.panel12);
            this.pnlRisikoJatuh.Controls.Add(this.labelControl100);
            this.pnlRisikoJatuh.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRisikoJatuh.Location = new System.Drawing.Point(3, 133);
            this.pnlRisikoJatuh.Name = "pnlRisikoJatuh";
            this.pnlRisikoJatuh.Size = new System.Drawing.Size(614, 343);
            this.pnlRisikoJatuh.TabIndex = 1;
            // 
            // pnlRJAnak
            // 
            this.pnlRJAnak.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlRJAnak.Controls.Add(this.xtraScrollableControl7);
            this.pnlRJAnak.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRJAnak.Location = new System.Drawing.Point(0, 53);
            this.pnlRJAnak.Name = "pnlRJAnak";
            this.pnlRJAnak.Size = new System.Drawing.Size(614, 290);
            this.pnlRJAnak.TabIndex = 11;
            // 
            // xtraScrollableControl7
            // 
            this.xtraScrollableControl7.Controls.Add(this.panel22);
            this.xtraScrollableControl7.Controls.Add(this.rgJenkel);
            this.xtraScrollableControl7.Controls.Add(this.rgSedasiAnestesi);
            this.xtraScrollableControl7.Controls.Add(this.rgGangguan);
            this.xtraScrollableControl7.Controls.Add(this.labelControl32);
            this.xtraScrollableControl7.Controls.Add(this.rguseObat);
            this.xtraScrollableControl7.Controls.Add(this.labelControl30);
            this.xtraScrollableControl7.Controls.Add(this.rgFlingkungan);
            this.xtraScrollableControl7.Controls.Add(this.labelControl31);
            this.xtraScrollableControl7.Controls.Add(this.rgDiagnosis);
            this.xtraScrollableControl7.Controls.Add(this.labelControl29);
            this.xtraScrollableControl7.Controls.Add(this.rgUsia);
            this.xtraScrollableControl7.Controls.Add(this.labelControl28);
            this.xtraScrollableControl7.Controls.Add(this.labelControl27);
            this.xtraScrollableControl7.Controls.Add(this.labelControl17);
            this.xtraScrollableControl7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraScrollableControl7.Location = new System.Drawing.Point(0, 0);
            this.xtraScrollableControl7.Name = "xtraScrollableControl7";
            this.xtraScrollableControl7.Size = new System.Drawing.Size(612, 288);
            this.xtraScrollableControl7.TabIndex = 0;
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.labelControl101);
            this.panel22.Controls.Add(this.txResikoAnak);
            this.panel22.Controls.Add(this.txScoreAnak);
            this.panel22.Location = new System.Drawing.Point(473, 5);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(119, 62);
            this.panel22.TabIndex = 45;
            // 
            // labelControl101
            // 
            this.labelControl101.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelControl101.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl101.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl101.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl101.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelControl101.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl101.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.labelControl101.Location = new System.Drawing.Point(3, 2);
            this.labelControl101.Name = "labelControl101";
            this.labelControl101.Size = new System.Drawing.Size(81, 30);
            this.labelControl101.TabIndex = 14;
            this.labelControl101.Text = "SCORE";
            // 
            // txResikoAnak
            // 
            this.txResikoAnak.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txResikoAnak.BackColor = System.Drawing.Color.White;
            this.txResikoAnak.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txResikoAnak.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txResikoAnak.ForeColor = System.Drawing.Color.DimGray;
            this.txResikoAnak.Location = new System.Drawing.Point(3, 35);
            this.txResikoAnak.Name = "txResikoAnak";
            this.txResikoAnak.Size = new System.Drawing.Size(115, 24);
            this.txResikoAnak.TabIndex = 12;
            this.txResikoAnak.Text = "RESIKO TINGGI";
            this.txResikoAnak.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txScoreAnak
            // 
            this.txScoreAnak.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txScoreAnak.BackColor = System.Drawing.Color.White;
            this.txScoreAnak.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txScoreAnak.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txScoreAnak.ForeColor = System.Drawing.Color.DimGray;
            this.txScoreAnak.Location = new System.Drawing.Point(83, 2);
            this.txScoreAnak.Name = "txScoreAnak";
            this.txScoreAnak.Size = new System.Drawing.Size(35, 30);
            this.txScoreAnak.TabIndex = 11;
            this.txScoreAnak.Text = "0";
            this.txScoreAnak.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rgJenkel
            // 
            this.rgJenkel.Location = new System.Drawing.Point(97, 32);
            this.rgJenkel.Name = "rgJenkel";
            this.rgJenkel.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgJenkel.Properties.Columns = 2;
            this.rgJenkel.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(2, "Laki-laki"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(1, "Perempuan")});
            this.rgJenkel.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Flow;
            this.rgJenkel.Size = new System.Drawing.Size(156, 25);
            this.rgJenkel.TabIndex = 39;
            this.rgJenkel.SelectedIndexChanged += new System.EventHandler(this.getScoreAnak);
            // 
            // rgSedasiAnestesi
            // 
            this.rgSedasiAnestesi.Location = new System.Drawing.Point(17, 298);
            this.rgSedasiAnestesi.Name = "rgSedasiAnestesi";
            this.rgSedasiAnestesi.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgSedasiAnestesi.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(3, "Dalam 24 Jam"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(2, "Dalam 48 jam"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(1, "> 48 jam atau tidak menjalani pembedahan atau anestesi")});
            this.rgSedasiAnestesi.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Column;
            this.rgSedasiAnestesi.Size = new System.Drawing.Size(427, 60);
            this.rgSedasiAnestesi.TabIndex = 43;
            this.rgSedasiAnestesi.SelectedIndexChanged += new System.EventHandler(this.getScoreAnak);
            // 
            // rgGangguan
            // 
            this.rgGangguan.Location = new System.Drawing.Point(17, 156);
            this.rgGangguan.Name = "rgGangguan";
            this.rgGangguan.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgGangguan.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(3, "Tidak menyadari kesehatan diri"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(2, "Lupa keterbatasan diri"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(1, "Orientasi terhadap diri sendiri baik")});
            this.rgGangguan.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Column;
            this.rgGangguan.Size = new System.Drawing.Size(390, 41);
            this.rgGangguan.TabIndex = 41;
            this.rgGangguan.SelectedIndexChanged += new System.EventHandler(this.getScoreAnak);
            // 
            // labelControl32
            // 
            this.labelControl32.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.labelControl32.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl32.Location = new System.Drawing.Point(8, 361);
            this.labelControl32.Name = "labelControl32";
            this.labelControl32.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl32.Size = new System.Drawing.Size(172, 21);
            this.labelControl32.TabIndex = 9;
            this.labelControl32.Text = "7. Penggunaan Obat :";
            // 
            // rguseObat
            // 
            this.rguseObat.Location = new System.Drawing.Point(17, 378);
            this.rguseObat.Name = "rguseObat";
            this.rguseObat.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rguseObat.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(3, "Penggunaan bermacam-macam obat : Sedatif, golongan hypnotik,barbiturat,  narcotic" +
                    "s, "),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(2, "Salah satu obat yang tertera diatas"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(1, "Obat golongan lain atau tidak ada")});
            this.rguseObat.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Column;
            this.rguseObat.Size = new System.Drawing.Size(468, 58);
            this.rguseObat.TabIndex = 44;
            this.rguseObat.SelectedIndexChanged += new System.EventHandler(this.getScoreAnak);
            // 
            // labelControl30
            // 
            this.labelControl30.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.labelControl30.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl30.Location = new System.Drawing.Point(8, 194);
            this.labelControl30.Name = "labelControl30";
            this.labelControl30.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl30.Size = new System.Drawing.Size(172, 21);
            this.labelControl30.TabIndex = 9;
            this.labelControl30.Text = "5. Faktor Lingkungan :";
            // 
            // rgFlingkungan
            // 
            this.rgFlingkungan.Location = new System.Drawing.Point(17, 211);
            this.rgFlingkungan.Name = "rgFlingkungan";
            this.rgFlingkungan.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgFlingkungan.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(4, "Riwayat jatuh tempat tidur"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(3, "Pasien menggunkan alat bantu/diletakan dalam tempat tidur bayi atau perbot rumah"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(2, "Pasien diletakan ditempat tidur"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(1, "Area rawat jalan")});
            this.rgFlingkungan.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Column;
            this.rgFlingkungan.Size = new System.Drawing.Size(435, 68);
            this.rgFlingkungan.TabIndex = 42;
            this.rgFlingkungan.SelectedIndexChanged += new System.EventHandler(this.getScoreAnak);
            // 
            // labelControl31
            // 
            this.labelControl31.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.labelControl31.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl31.Location = new System.Drawing.Point(8, 281);
            this.labelControl31.Name = "labelControl31";
            this.labelControl31.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl31.Size = new System.Drawing.Size(287, 21);
            this.labelControl31.TabIndex = 9;
            this.labelControl31.Text = "6. Response terhadap pembedahan/ Sedasi anestesi :";
            // 
            // rgDiagnosis
            // 
            this.rgDiagnosis.Location = new System.Drawing.Point(17, 73);
            this.rgDiagnosis.Name = "rgDiagnosis";
            this.rgDiagnosis.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgDiagnosis.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(4, "Diagnosis Neurologis"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(3, "Gangguan Oksigenasi (respirasi, dehidrasi, anemia, anoreksia, pusing)"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(2, "Psikosis/Gangguan perilkau)"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(1, "Diagnosa Lainnya")});
            this.rgDiagnosis.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Column;
            this.rgDiagnosis.Size = new System.Drawing.Size(365, 71);
            this.rgDiagnosis.TabIndex = 40;
            this.rgDiagnosis.SelectedIndexChanged += new System.EventHandler(this.getScoreAnak);
            // 
            // labelControl29
            // 
            this.labelControl29.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.labelControl29.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl29.Location = new System.Drawing.Point(8, 139);
            this.labelControl29.Name = "labelControl29";
            this.labelControl29.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl29.Size = new System.Drawing.Size(172, 21);
            this.labelControl29.TabIndex = 9;
            this.labelControl29.Text = "4. Gangguan fungsi kognitif :";
            // 
            // rgUsia
            // 
            this.rgUsia.Location = new System.Drawing.Point(97, 11);
            this.rgUsia.Name = "rgUsia";
            this.rgUsia.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgUsia.Properties.Columns = 4;
            this.rgUsia.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(4, "< 3 thn"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(3, "3 ~ < 7 thn"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(2, "7 ~ < 13 thn"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(1, "13 thn keatas")});
            this.rgUsia.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Flow;
            this.rgUsia.Size = new System.Drawing.Size(347, 30);
            this.rgUsia.TabIndex = 38;
            this.rgUsia.SelectedIndexChanged += new System.EventHandler(this.getScoreAnak);
            // 
            // labelControl28
            // 
            this.labelControl28.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.labelControl28.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl28.Location = new System.Drawing.Point(8, 56);
            this.labelControl28.Name = "labelControl28";
            this.labelControl28.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl28.Size = new System.Drawing.Size(99, 21);
            this.labelControl28.TabIndex = 9;
            this.labelControl28.Text = "3. Diagnosis  :";
            // 
            // labelControl27
            // 
            this.labelControl27.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.labelControl27.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl27.Location = new System.Drawing.Point(8, 34);
            this.labelControl27.Name = "labelControl27";
            this.labelControl27.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl27.Size = new System.Drawing.Size(99, 21);
            this.labelControl27.TabIndex = 9;
            this.labelControl27.Text = "2. Jenis kelamin  :";
            // 
            // labelControl17
            // 
            this.labelControl17.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.labelControl17.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl17.Location = new System.Drawing.Point(8, 12);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl17.Size = new System.Drawing.Size(99, 21);
            this.labelControl17.TabIndex = 9;
            this.labelControl17.Text = "1. Usia  (Tahun) :";
            // 
            // pnlRJDewasa
            // 
            this.pnlRJDewasa.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlRJDewasa.Controls.Add(this.xScrolJatuhDwasa);
            this.pnlRJDewasa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRJDewasa.Location = new System.Drawing.Point(0, 53);
            this.pnlRJDewasa.Name = "pnlRJDewasa";
            this.pnlRJDewasa.Size = new System.Drawing.Size(614, 290);
            this.pnlRJDewasa.TabIndex = 11;
            this.pnlRJDewasa.Visible = false;
            // 
            // xScrolJatuhDwasa
            // 
            this.xScrolJatuhDwasa.Controls.Add(this.panel21);
            this.xScrolJatuhDwasa.Controls.Add(this.pnlStsmental);
            this.xScrolJatuhDwasa.Controls.Add(this.pnlGayaJalan);
            this.xScrolJatuhDwasa.Controls.Add(this.pnlInfus);
            this.xScrolJatuhDwasa.Controls.Add(this.pnlLatBantuJalan);
            this.xScrolJatuhDwasa.Controls.Add(this.pnlDiagnosaSekunder);
            this.xScrolJatuhDwasa.Controls.Add(this.pnlRiwayatJatuh);
            this.xScrolJatuhDwasa.Controls.Add(this.labelControl8);
            this.xScrolJatuhDwasa.Controls.Add(this.labelControl9);
            this.xScrolJatuhDwasa.Controls.Add(this.labelControl7);
            this.xScrolJatuhDwasa.Controls.Add(this.labelControl6);
            this.xScrolJatuhDwasa.Controls.Add(this.labelControl5);
            this.xScrolJatuhDwasa.Controls.Add(this.labelControl3);
            this.xScrolJatuhDwasa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xScrolJatuhDwasa.Location = new System.Drawing.Point(0, 0);
            this.xScrolJatuhDwasa.Name = "xScrolJatuhDwasa";
            this.xScrolJatuhDwasa.Size = new System.Drawing.Size(612, 288);
            this.xScrolJatuhDwasa.TabIndex = 0;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.txResikoDewasa);
            this.panel21.Controls.Add(this.lblTindakan);
            this.panel21.Controls.Add(this.txTotalNilai);
            this.panel21.Controls.Add(this.labelControl97);
            this.panel21.Location = new System.Drawing.Point(443, 6);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(152, 126);
            this.panel21.TabIndex = 30;
            // 
            // txResikoDewasa
            // 
            this.txResikoDewasa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txResikoDewasa.Appearance.BackColor = System.Drawing.Color.White;
            this.txResikoDewasa.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txResikoDewasa.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.txResikoDewasa.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.txResikoDewasa.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.txResikoDewasa.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.txResikoDewasa.Location = new System.Drawing.Point(2, 34);
            this.txResikoDewasa.Name = "txResikoDewasa";
            this.txResikoDewasa.Size = new System.Drawing.Size(147, 30);
            this.txResikoDewasa.TabIndex = 14;
            this.txResikoDewasa.Text = "Resiko Tinggi";
            // 
            // lblTindakan
            // 
            this.lblTindakan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTindakan.Appearance.BackColor = System.Drawing.Color.White;
            this.lblTindakan.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTindakan.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.lblTindakan.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.lblTindakan.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.Vertical;
            this.lblTindakan.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.lblTindakan.Location = new System.Drawing.Point(2, 67);
            this.lblTindakan.Name = "lblTindakan";
            this.lblTindakan.Padding = new System.Windows.Forms.Padding(3);
            this.lblTindakan.Size = new System.Drawing.Size(147, 47);
            this.lblTindakan.TabIndex = 14;
            this.lblTindakan.Text = "Pelaksanaan intervensi, pencegahan jatuh resiko tinggi";
            // 
            // txTotalNilai
            // 
            this.txTotalNilai.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txTotalNilai.BackColor = System.Drawing.Color.White;
            this.txTotalNilai.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txTotalNilai.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txTotalNilai.ForeColor = System.Drawing.Color.DimGray;
            this.txTotalNilai.Location = new System.Drawing.Point(112, 2);
            this.txTotalNilai.Name = "txTotalNilai";
            this.txTotalNilai.Size = new System.Drawing.Size(37, 30);
            this.txTotalNilai.TabIndex = 10;
            this.txTotalNilai.Text = "10";
            this.txTotalNilai.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelControl97
            // 
            this.labelControl97.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelControl97.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl97.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl97.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl97.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelControl97.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl97.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.labelControl97.Location = new System.Drawing.Point(2, 2);
            this.labelControl97.Name = "labelControl97";
            this.labelControl97.Size = new System.Drawing.Size(111, 30);
            this.labelControl97.TabIndex = 14;
            this.labelControl97.Text = "SCORE";
            // 
            // pnlStsmental
            // 
            this.pnlStsmental.Controls.Add(this.txket6);
            this.pnlStsmental.Controls.Add(this.rgstsMental);
            this.pnlStsmental.Location = new System.Drawing.Point(21, 388);
            this.pnlStsmental.Name = "pnlStsmental";
            this.pnlStsmental.Size = new System.Drawing.Size(393, 74);
            this.pnlStsmental.TabIndex = 29;
            // 
            // txket6
            // 
            this.txket6.Location = new System.Drawing.Point(30, 50);
            this.txket6.Name = "txket6";
            this.txket6.Size = new System.Drawing.Size(352, 21);
            this.txket6.TabIndex = 102;
            this.txket6.Tag = "exc";
            // 
            // rgstsMental
            // 
            this.rgstsMental.Location = new System.Drawing.Point(8, 3);
            this.rgstsMental.Name = "rgstsMental";
            this.rgstsMental.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgstsMental.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(0, "Lansia menyadari kondisi dirinya"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(15, "Lansia mengalami keterbatsan daya ingat")});
            this.rgstsMental.Size = new System.Drawing.Size(374, 47);
            this.rgstsMental.TabIndex = 101;
            this.rgstsMental.SelectedIndexChanged += new System.EventHandler(this.getScoreDewasa);
            // 
            // pnlGayaJalan
            // 
            this.pnlGayaJalan.Controls.Add(this.txKet5);
            this.pnlGayaJalan.Controls.Add(this.rgGayaJalan);
            this.pnlGayaJalan.Location = new System.Drawing.Point(21, 281);
            this.pnlGayaJalan.Name = "pnlGayaJalan";
            this.pnlGayaJalan.Size = new System.Drawing.Size(393, 91);
            this.pnlGayaJalan.TabIndex = 28;
            // 
            // txKet5
            // 
            this.txKet5.Location = new System.Drawing.Point(30, 64);
            this.txKet5.Name = "txKet5";
            this.txKet5.Size = new System.Drawing.Size(352, 21);
            this.txKet5.TabIndex = 100;
            this.txKet5.Tag = "exc";
            // 
            // rgGayaJalan
            // 
            this.rgGayaJalan.Location = new System.Drawing.Point(8, 3);
            this.rgGayaJalan.Name = "rgGayaJalan";
            this.rgGayaJalan.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgGayaJalan.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(0, "Normal/bed rest/immobile"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(10, "Lemah (tidak bertenaga)"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(20, "Gangguan/tidak normal (pincang/diseret)")});
            this.rgGayaJalan.Size = new System.Drawing.Size(382, 64);
            this.rgGayaJalan.TabIndex = 99;
            this.rgGayaJalan.SelectedIndexChanged += new System.EventHandler(this.getScoreDewasa);
            // 
            // pnlInfus
            // 
            this.pnlInfus.Controls.Add(this.txket4);
            this.pnlInfus.Controls.Add(this.rgInfus);
            this.pnlInfus.Location = new System.Drawing.Point(21, 227);
            this.pnlInfus.Name = "pnlInfus";
            this.pnlInfus.Size = new System.Drawing.Size(393, 27);
            this.pnlInfus.TabIndex = 27;
            // 
            // txket4
            // 
            this.txket4.Location = new System.Drawing.Point(117, 3);
            this.txket4.Name = "txket4";
            this.txket4.Size = new System.Drawing.Size(265, 21);
            this.txket4.TabIndex = 98;
            this.txket4.Tag = "exc";
            // 
            // rgInfus
            // 
            this.rgInfus.Location = new System.Drawing.Point(8, 2);
            this.rgInfus.Name = "rgInfus";
            this.rgInfus.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgInfus.Properties.Columns = 2;
            this.rgInfus.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(0, "Tidak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(25, "Ya")});
            this.rgInfus.Size = new System.Drawing.Size(125, 22);
            this.rgInfus.TabIndex = 97;
            this.rgInfus.SelectedIndexChanged += new System.EventHandler(this.getScoreDewasa);
            // 
            // pnlLatBantuJalan
            // 
            this.pnlLatBantuJalan.Controls.Add(this.txKet3);
            this.pnlLatBantuJalan.Controls.Add(this.rgAltBantuJalan);
            this.pnlLatBantuJalan.Location = new System.Drawing.Point(21, 113);
            this.pnlLatBantuJalan.Name = "pnlLatBantuJalan";
            this.pnlLatBantuJalan.Size = new System.Drawing.Size(393, 92);
            this.pnlLatBantuJalan.TabIndex = 26;
            // 
            // txKet3
            // 
            this.txKet3.Location = new System.Drawing.Point(28, 68);
            this.txKet3.Name = "txKet3";
            this.txKet3.Size = new System.Drawing.Size(354, 21);
            this.txKet3.TabIndex = 96;
            this.txKet3.Tag = "exc";
            // 
            // rgAltBantuJalan
            // 
            this.rgAltBantuJalan.Location = new System.Drawing.Point(8, 4);
            this.rgAltBantuJalan.Name = "rgAltBantuJalan";
            this.rgAltBantuJalan.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgAltBantuJalan.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(0, "Bed rest / Dibantu Perawat"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(15, "Kruk/Tongkat/Walker"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(30, "Berpegangan pada benda sekitar")});
            this.rgAltBantuJalan.Size = new System.Drawing.Size(374, 70);
            this.rgAltBantuJalan.TabIndex = 95;
            this.rgAltBantuJalan.SelectedIndexChanged += new System.EventHandler(this.getScoreDewasa);
            // 
            // pnlDiagnosaSekunder
            // 
            this.pnlDiagnosaSekunder.Controls.Add(this.txKet2);
            this.pnlDiagnosaSekunder.Controls.Add(this.rgDiagnosaSekunder);
            this.pnlDiagnosaSekunder.Location = new System.Drawing.Point(21, 73);
            this.pnlDiagnosaSekunder.Name = "pnlDiagnosaSekunder";
            this.pnlDiagnosaSekunder.Size = new System.Drawing.Size(393, 27);
            this.pnlDiagnosaSekunder.TabIndex = 25;
            // 
            // txKet2
            // 
            this.txKet2.Location = new System.Drawing.Point(113, 4);
            this.txKet2.Name = "txKet2";
            this.txKet2.Size = new System.Drawing.Size(269, 21);
            this.txKet2.TabIndex = 94;
            this.txKet2.Tag = "exc";
            // 
            // rgDiagnosaSekunder
            // 
            this.rgDiagnosaSekunder.Location = new System.Drawing.Point(7, 3);
            this.rgDiagnosaSekunder.Name = "rgDiagnosaSekunder";
            this.rgDiagnosaSekunder.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgDiagnosaSekunder.Properties.Columns = 2;
            this.rgDiagnosaSekunder.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(0, "Tidak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(25, "Ya")});
            this.rgDiagnosaSekunder.Size = new System.Drawing.Size(125, 19);
            this.rgDiagnosaSekunder.TabIndex = 93;
            this.rgDiagnosaSekunder.SelectedIndexChanged += new System.EventHandler(this.getScoreDewasa);
            // 
            // pnlRiwayatJatuh
            // 
            this.pnlRiwayatJatuh.Controls.Add(this.txKet1);
            this.pnlRiwayatJatuh.Controls.Add(this.rgRiwayatJatuh);
            this.pnlRiwayatJatuh.Location = new System.Drawing.Point(21, 29);
            this.pnlRiwayatJatuh.Name = "pnlRiwayatJatuh";
            this.pnlRiwayatJatuh.Size = new System.Drawing.Size(393, 27);
            this.pnlRiwayatJatuh.TabIndex = 24;
            // 
            // txKet1
            // 
            this.txKet1.Location = new System.Drawing.Point(113, 4);
            this.txKet1.Name = "txKet1";
            this.txKet1.Size = new System.Drawing.Size(269, 21);
            this.txKet1.TabIndex = 92;
            this.txKet1.Tag = "exc";
            // 
            // rgRiwayatJatuh
            // 
            this.rgRiwayatJatuh.Location = new System.Drawing.Point(7, 4);
            this.rgRiwayatJatuh.Name = "rgRiwayatJatuh";
            this.rgRiwayatJatuh.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgRiwayatJatuh.Properties.Columns = 2;
            this.rgRiwayatJatuh.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(0, "Tidak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(25, "Ya")});
            this.rgRiwayatJatuh.Size = new System.Drawing.Size(125, 19);
            this.rgRiwayatJatuh.TabIndex = 91;
            this.rgRiwayatJatuh.SelectedIndexChanged += new System.EventHandler(this.getScoreDewasa);
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.labelControl8.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl8.Location = new System.Drawing.Point(17, 254);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl8.Size = new System.Drawing.Size(363, 21);
            this.labelControl8.TabIndex = 11;
            this.labelControl8.Text = "5. Gaya berjalan / cara berpindah :";
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.labelControl9.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl9.Location = new System.Drawing.Point(17, 367);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl9.Size = new System.Drawing.Size(363, 21);
            this.labelControl9.TabIndex = 12;
            this.labelControl9.Text = "6. Status Mental :";
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.labelControl7.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl7.Location = new System.Drawing.Point(19, 206);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl7.Size = new System.Drawing.Size(363, 21);
            this.labelControl7.TabIndex = 13;
            this.labelControl7.Text = "4. Terapi Intravena : apakah  saat ini lansia terpasang infus?";
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.labelControl6.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl6.Location = new System.Drawing.Point(19, 96);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl6.Size = new System.Drawing.Size(144, 21);
            this.labelControl6.TabIndex = 14;
            this.labelControl6.Text = "3. Alat Bantu Jalan  :";
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.labelControl5.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl5.Location = new System.Drawing.Point(19, 52);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl5.Size = new System.Drawing.Size(365, 21);
            this.labelControl5.TabIndex = 15;
            this.labelControl5.Text = "2. Diagnosa sekunder : apakah lansia memiliki lebih dari satu penyakit? ";
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.labelControl3.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl3.Location = new System.Drawing.Point(17, 9);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl3.Size = new System.Drawing.Size(365, 21);
            this.labelControl3.TabIndex = 16;
            this.labelControl3.Text = "1. Riwayat Jatuh : apakah lansia pernah jatuh dalam 3 bulan terakhir?  :";
            // 
            // panel12
            // 
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.Controls.Add(this.btnSaveX);
            this.panel12.Controls.Add(this.rgKatgriPasien);
            this.panel12.Controls.Add(this.labelControl2);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel12.Location = new System.Drawing.Point(0, 25);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(614, 28);
            this.panel12.TabIndex = 10;
            // 
            // btnSaveX
            // 
            this.btnSaveX.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSaveX.Location = new System.Drawing.Point(541, 3);
            this.btnSaveX.Name = "btnSaveX";
            this.btnSaveX.Size = new System.Drawing.Size(66, 20);
            this.btnSaveX.TabIndex = 11;
            this.btnSaveX.Text = "Save";
            this.btnSaveX.Click += new System.EventHandler(this.btnSaveX_Click);
            // 
            // rgKatgriPasien
            // 
            this.rgKatgriPasien.EditValue = 1;
            this.rgKatgriPasien.Location = new System.Drawing.Point(113, 2);
            this.rgKatgriPasien.Name = "rgKatgriPasien";
            this.rgKatgriPasien.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgKatgriPasien.Properties.Columns = 2;
            this.rgKatgriPasien.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(1, "Anak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(2, "Dewasa")});
            this.rgKatgriPasien.Size = new System.Drawing.Size(125, 25);
            this.rgKatgriPasien.TabIndex = 37;
            this.rgKatgriPasien.SelectedIndexChanged += new System.EventHandler(this.rgKatgriPasien_SelectedIndexChanged);
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.labelControl2.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl2.Location = new System.Drawing.Point(7, 4);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Padding = new System.Windows.Forms.Padding(3);
            this.labelControl2.Size = new System.Drawing.Size(126, 21);
            this.labelControl2.TabIndex = 9;
            this.labelControl2.Text = "Pilih Kategori Pasien :";
            // 
            // labelControl100
            // 
            this.labelControl100.Appearance.BackColor = System.Drawing.Color.DarkGray;
            this.labelControl100.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl100.Appearance.ForeColor = System.Drawing.Color.White;
            this.labelControl100.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelControl100.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl100.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.labelControl100.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelControl100.Location = new System.Drawing.Point(0, 0);
            this.labelControl100.Name = "labelControl100";
            this.labelControl100.Size = new System.Drawing.Size(614, 25);
            this.labelControl100.TabIndex = 189;
            this.labelControl100.Text = "Formulir Pengkajian dan Pemantuan Risiko Jatuh pada pasien";
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.gbStsFungsi, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.groupBox16, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.xtraScrollableControl5, 0, 2);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 3;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.22523F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 74.77477F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 247F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(620, 479);
            this.tableLayoutPanel6.TabIndex = 2;
            // 
            // gbStsFungsi
            // 
            this.gbStsFungsi.Controls.Add(this.txAltBantujalan);
            this.gbStsFungsi.Controls.Add(this.txMobilisasiDtl);
            this.gbStsFungsi.Controls.Add(this.label7);
            this.gbStsFungsi.Controls.Add(this.rgMobilisasi);
            this.gbStsFungsi.Controls.Add(this.label95);
            this.gbStsFungsi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbStsFungsi.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbStsFungsi.Location = new System.Drawing.Point(3, 3);
            this.gbStsFungsi.Name = "gbStsFungsi";
            this.gbStsFungsi.Size = new System.Drawing.Size(614, 52);
            this.gbStsFungsi.TabIndex = 1;
            this.gbStsFungsi.TabStop = false;
            this.gbStsFungsi.Text = "Status Fungsional (Isi formulir Barthel Index)";
            // 
            // txAltBantujalan
            // 
            this.txAltBantujalan.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txAltBantujalan.Location = new System.Drawing.Point(484, 18);
            this.txAltBantujalan.Name = "txAltBantujalan";
            this.txAltBantujalan.Size = new System.Drawing.Size(124, 21);
            this.txAltBantujalan.TabIndex = 3;
            this.txAltBantujalan.Tag = "exc";
            // 
            // txMobilisasiDtl
            // 
            this.txMobilisasiDtl.Enabled = false;
            this.txMobilisasiDtl.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txMobilisasiDtl.Location = new System.Drawing.Point(280, 17);
            this.txMobilisasiDtl.Name = "txMobilisasiDtl";
            this.txMobilisasiDtl.Size = new System.Drawing.Size(116, 21);
            this.txMobilisasiDtl.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(397, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Alat bantu jalan :";
            // 
            // rgMobilisasi
            // 
            this.rgMobilisasi.Location = new System.Drawing.Point(124, 16);
            this.rgMobilisasi.Name = "rgMobilisasi";
            this.rgMobilisasi.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgMobilisasi.Properties.Columns = 2;
            this.rgMobilisasi.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Mandiri"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Perlu Bantuan")});
            this.rgMobilisasi.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Flow;
            this.rgMobilisasi.Size = new System.Drawing.Size(178, 20);
            this.rgMobilisasi.TabIndex = 1;
            this.rgMobilisasi.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label95.Location = new System.Drawing.Point(7, 20);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(123, 13);
            this.label95.TabIndex = 8;
            this.label95.Text = "Aktivitas dan mobilisasi :";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.xtraScrollableControl10);
            this.groupBox16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox16.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox16.Location = new System.Drawing.Point(3, 61);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(614, 167);
            this.groupBox16.TabIndex = 1;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Skala Nyeri";
            // 
            // xtraScrollableControl10
            // 
            this.xtraScrollableControl10.Controls.Add(this.pnlSkalaNyeri);
            this.xtraScrollableControl10.Controls.Add(this.gbNyeriHilang);
            this.xtraScrollableControl10.Controls.Add(this.label9);
            this.xtraScrollableControl10.Controls.Add(this.rgNyeri);
            this.xtraScrollableControl10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraScrollableControl10.Location = new System.Drawing.Point(3, 17);
            this.xtraScrollableControl10.Name = "xtraScrollableControl10";
            this.xtraScrollableControl10.ScrollBarSmallChange = 1;
            this.xtraScrollableControl10.Size = new System.Drawing.Size(608, 147);
            this.xtraScrollableControl10.TabIndex = 0;
            // 
            // pnlSkalaNyeri
            // 
            this.pnlSkalaNyeri.Controls.Add(this.labelControl99);
            this.pnlSkalaNyeri.Controls.Add(this.chkSkalaNyeri);
            this.pnlSkalaNyeri.Controls.Add(this.pictureBox1);
            this.pnlSkalaNyeri.Controls.Add(this.panel4);
            this.pnlSkalaNyeri.Enabled = false;
            this.pnlSkalaNyeri.Location = new System.Drawing.Point(-2, 26);
            this.pnlSkalaNyeri.Name = "pnlSkalaNyeri";
            this.pnlSkalaNyeri.Size = new System.Drawing.Size(589, 191);
            this.pnlSkalaNyeri.TabIndex = 17;
            // 
            // labelControl99
            // 
            this.labelControl99.Appearance.BackColor = System.Drawing.Color.DarkGray;
            this.labelControl99.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl99.Appearance.ForeColor = System.Drawing.Color.White;
            this.labelControl99.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelControl99.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl99.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.labelControl99.Location = new System.Drawing.Point(2, 1);
            this.labelControl99.Name = "labelControl99";
            this.labelControl99.Size = new System.Drawing.Size(595, 25);
            this.labelControl99.TabIndex = 189;
            this.labelControl99.Text = "SKALA NYERI";
            // 
            // chkSkalaNyeri
            // 
            this.chkSkalaNyeri.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.chkSkalaNyeri.CheckOnClick = true;
            this.chkSkalaNyeri.FormattingEnabled = true;
            this.chkSkalaNyeri.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.chkSkalaNyeri.Location = new System.Drawing.Point(327, 25);
            this.chkSkalaNyeri.Name = "chkSkalaNyeri";
            this.chkSkalaNyeri.Size = new System.Drawing.Size(42, 162);
            this.chkSkalaNyeri.TabIndex = 5;
            this.chkSkalaNyeri.SelectedIndexChanged += new System.EventHandler(this.chkSkalaNyeri_SelectedIndexChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = global::Clinic.Properties.Resources.painScale;
            this.pictureBox1.Location = new System.Drawing.Point(2, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(326, 162);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 53;
            this.pictureBox1.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.txScorNyeri);
            this.panel4.Controls.Add(this.label87);
            this.panel4.Controls.Add(this.txDurasiNyeri);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.txFrekuensi);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.txLokasiNyeri);
            this.panel4.Controls.Add(this.panel10);
            this.panel4.Controls.Add(this.rgTingkatNyeri);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Location = new System.Drawing.Point(368, 25);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(221, 162);
            this.panel4.TabIndex = 54;
            // 
            // txScorNyeri
            // 
            this.txScorNyeri.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txScorNyeri.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txScorNyeri.Location = new System.Drawing.Point(65, 136);
            this.txScorNyeri.Name = "txScorNyeri";
            this.txScorNyeri.Size = new System.Drawing.Size(148, 21);
            this.txScorNyeri.TabIndex = 10;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.Location = new System.Drawing.Point(6, 139);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(56, 13);
            this.label87.TabIndex = 15;
            this.label87.Text = "Skor Nyeri";
            // 
            // txDurasiNyeri
            // 
            this.txDurasiNyeri.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txDurasiNyeri.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txDurasiNyeri.Location = new System.Drawing.Point(65, 117);
            this.txDurasiNyeri.Name = "txDurasiNyeri";
            this.txDurasiNyeri.Size = new System.Drawing.Size(148, 21);
            this.txDurasiNyeri.TabIndex = 9;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(6, 120);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(37, 13);
            this.label16.TabIndex = 13;
            this.label16.Text = "Durasi";
            // 
            // txFrekuensi
            // 
            this.txFrekuensi.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txFrekuensi.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txFrekuensi.Location = new System.Drawing.Point(65, 97);
            this.txFrekuensi.Name = "txFrekuensi";
            this.txFrekuensi.Size = new System.Drawing.Size(148, 21);
            this.txFrekuensi.TabIndex = 8;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(6, 101);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 13);
            this.label15.TabIndex = 13;
            this.label15.Text = "Frekuensi";
            // 
            // txLokasiNyeri
            // 
            this.txLokasiNyeri.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txLokasiNyeri.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txLokasiNyeri.Location = new System.Drawing.Point(65, 77);
            this.txLokasiNyeri.Name = "txLokasiNyeri";
            this.txLokasiNyeri.Size = new System.Drawing.Size(148, 21);
            this.txLokasiNyeri.TabIndex = 7;
            // 
            // panel10
            // 
            this.panel10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel10.BackColor = System.Drawing.Color.FloralWhite;
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.label11);
            this.panel10.Controls.Add(this.label10);
            this.panel10.Controls.Add(this.label8);
            this.panel10.Location = new System.Drawing.Point(-1, -1);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(221, 58);
            this.panel10.TabIndex = 12;
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(6, 38);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(230, 18);
            this.label11.TabIndex = 10;
            this.label11.Text = "8-10 : Nyeri berat, Konsul Nyeri";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(-10, 20);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(215, 18);
            this.label10.TabIndex = 9;
            this.label10.Text = "4 - 7 : Nyeri sedang, Perlu analgetic injeksi";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(6, 2);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(230, 18);
            this.label8.TabIndex = 8;
            this.label8.Text = "1 - 3 : Nyeri ringan, analgetic oral";
            // 
            // rgTingkatNyeri
            // 
            this.rgTingkatNyeri.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.rgTingkatNyeri.Location = new System.Drawing.Point(-1, 56);
            this.rgTingkatNyeri.Name = "rgTingkatNyeri";
            this.rgTingkatNyeri.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgTingkatNyeri.Properties.Columns = 2;
            this.rgTingkatNyeri.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Kronis"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Akut")});
            this.rgTingkatNyeri.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Flow;
            this.rgTingkatNyeri.Size = new System.Drawing.Size(233, 20);
            this.rgTingkatNyeri.TabIndex = 6;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(6, 79);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(36, 13);
            this.label12.TabIndex = 8;
            this.label12.Text = "Lokasi";
            // 
            // gbNyeriHilang
            // 
            this.gbNyeriHilang.Controls.Add(this.txNyeriHilang);
            this.gbNyeriHilang.Controls.Add(this.chkEtc7);
            this.gbNyeriHilang.Controls.Add(this.checkBox2);
            this.gbNyeriHilang.Controls.Add(this.checkBox3);
            this.gbNyeriHilang.Controls.Add(this.checkBox4);
            this.gbNyeriHilang.Controls.Add(this.checkBox5);
            this.gbNyeriHilang.Enabled = false;
            this.gbNyeriHilang.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbNyeriHilang.Location = new System.Drawing.Point(0, 221);
            this.gbNyeriHilang.Name = "gbNyeriHilang";
            this.gbNyeriHilang.Size = new System.Drawing.Size(587, 50);
            this.gbNyeriHilang.TabIndex = 16;
            this.gbNyeriHilang.TabStop = false;
            this.gbNyeriHilang.Text = "Nyeri Hilang";
            // 
            // txNyeriHilang
            // 
            this.txNyeriHilang.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txNyeriHilang.Enabled = false;
            this.txNyeriHilang.Location = new System.Drawing.Point(441, 18);
            this.txNyeriHilang.Name = "txNyeriHilang";
            this.txNyeriHilang.Size = new System.Drawing.Size(138, 21);
            this.txNyeriHilang.TabIndex = 16;
            // 
            // chkEtc7
            // 
            this.chkEtc7.AutoSize = true;
            this.chkEtc7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkEtc7.Location = new System.Drawing.Point(380, 20);
            this.chkEtc7.Name = "chkEtc7";
            this.chkEtc7.Size = new System.Drawing.Size(66, 17);
            this.chkEtc7.TabIndex = 15;
            this.chkEtc7.Text = "Lainnya ";
            this.chkEtc7.UseVisualStyleBackColor = true;
            this.chkEtc7.CheckedChanged += new System.EventHandler(this.chkEtc7_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.Location = new System.Drawing.Point(261, 20);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(122, 17);
            this.checkBox2.TabIndex = 14;
            this.checkBox2.Text = "Berubah Posisi Tidur";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox3.Location = new System.Drawing.Point(155, 20);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(109, 17);
            this.checkBox3.TabIndex = 13;
            this.checkBox3.Text = "Mendengar Musik";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox4.Location = new System.Drawing.Point(88, 20);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(70, 17);
            this.checkBox4.TabIndex = 12;
            this.checkBox4.Text = " Istirahat";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox5.Location = new System.Drawing.Point(6, 20);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(83, 17);
            this.checkBox5.TabIndex = 11;
            this.checkBox5.Text = "Minum Obat";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(-432, 1262);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(39, 13);
            this.label9.TabIndex = 15;
            this.label9.Text = "Nyeri :";
            // 
            // rgNyeri
            // 
            this.rgNyeri.Location = new System.Drawing.Point(4, 0);
            this.rgNyeri.Name = "rgNyeri";
            this.rgNyeri.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgNyeri.Properties.Columns = 2;
            this.rgNyeri.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(1, "Ya"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(0, "Tidak")});
            this.rgNyeri.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Flow;
            this.rgNyeri.Size = new System.Drawing.Size(109, 20);
            this.rgNyeri.TabIndex = 4;
            this.rgNyeri.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // xtraScrollableControl5
            // 
            this.xtraScrollableControl5.Controls.Add(this.labelControl95);
            this.xtraScrollableControl5.Controls.Add(this.panel11);
            this.xtraScrollableControl5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraScrollableControl5.Location = new System.Drawing.Point(3, 234);
            this.xtraScrollableControl5.Name = "xtraScrollableControl5";
            this.xtraScrollableControl5.Size = new System.Drawing.Size(614, 242);
            this.xtraScrollableControl5.TabIndex = 2;
            // 
            // labelControl95
            // 
            this.labelControl95.Appearance.BackColor = System.Drawing.Color.DarkGray;
            this.labelControl95.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl95.Appearance.ForeColor = System.Drawing.Color.White;
            this.labelControl95.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelControl95.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl95.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.labelControl95.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelControl95.Location = new System.Drawing.Point(0, 0);
            this.labelControl95.Name = "labelControl95";
            this.labelControl95.Size = new System.Drawing.Size(614, 25);
            this.labelControl95.TabIndex = 188;
            this.labelControl95.Text = "SKRINING GIZI (Berdasarkan Malnutrition Screening Tools / MST)";
            // 
            // panel11
            // 
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.labelControl96);
            this.panel11.Controls.Add(this.pnlDiagnoseKhusus);
            this.panel11.Controls.Add(this.pnlLaporTim);
            this.panel11.Controls.Add(this.pnlBeratBadan);
            this.panel11.Controls.Add(this.txScoreScrining);
            this.panel11.Controls.Add(this.label21);
            this.panel11.Controls.Add(this.rgAsupanMakan);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(614, 242);
            this.panel11.TabIndex = 9;
            // 
            // labelControl96
            // 
            this.labelControl96.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelControl96.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.labelControl96.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl96.Appearance.ForeColor = System.Drawing.Color.DimGray;
            this.labelControl96.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelControl96.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl96.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.labelControl96.Location = new System.Drawing.Point(520, 28);
            this.labelControl96.Name = "labelControl96";
            this.labelControl96.Size = new System.Drawing.Size(50, 30);
            this.labelControl96.TabIndex = 14;
            this.labelControl96.Text = "SCORE";
            // 
            // pnlDiagnoseKhusus
            // 
            this.pnlDiagnoseKhusus.Controls.Add(this.txDiagnoseDtl);
            this.pnlDiagnoseKhusus.Controls.Add(this.checkBox53);
            this.pnlDiagnoseKhusus.Controls.Add(this.checkBox52);
            this.pnlDiagnoseKhusus.Controls.Add(this.checkBox51);
            this.pnlDiagnoseKhusus.Controls.Add(this.checkBox50);
            this.pnlDiagnoseKhusus.Controls.Add(this.checkBox48);
            this.pnlDiagnoseKhusus.Controls.Add(this.checkBox47);
            this.pnlDiagnoseKhusus.Controls.Add(this.checkBox46);
            this.pnlDiagnoseKhusus.Controls.Add(this.label22);
            this.pnlDiagnoseKhusus.Controls.Add(this.checkBox54);
            this.pnlDiagnoseKhusus.Controls.Add(this.chkEtc14);
            this.pnlDiagnoseKhusus.Controls.Add(this.rgDiagnoseKh);
            this.pnlDiagnoseKhusus.Controls.Add(this.checkBox45);
            this.pnlDiagnoseKhusus.Location = new System.Drawing.Point(1, 131);
            this.pnlDiagnoseKhusus.Name = "pnlDiagnoseKhusus";
            this.pnlDiagnoseKhusus.Size = new System.Drawing.Size(605, 75);
            this.pnlDiagnoseKhusus.TabIndex = 13;
            // 
            // txDiagnoseDtl
            // 
            this.txDiagnoseDtl.Enabled = false;
            this.txDiagnoseDtl.Location = new System.Drawing.Point(320, 52);
            this.txDiagnoseDtl.Name = "txDiagnoseDtl";
            this.txDiagnoseDtl.Size = new System.Drawing.Size(231, 21);
            this.txDiagnoseDtl.TabIndex = 31;
            // 
            // checkBox53
            // 
            this.checkBox53.AutoSize = true;
            this.checkBox53.Enabled = false;
            this.checkBox53.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox53.Location = new System.Drawing.Point(481, 27);
            this.checkBox53.Name = "checkBox53";
            this.checkBox53.Size = new System.Drawing.Size(61, 17);
            this.checkBox53.TabIndex = 28;
            this.checkBox53.Text = "Geriatri";
            this.checkBox53.UseVisualStyleBackColor = true;
            // 
            // checkBox52
            // 
            this.checkBox52.AutoSize = true;
            this.checkBox52.Enabled = false;
            this.checkBox52.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox52.Location = new System.Drawing.Point(419, 27);
            this.checkBox52.Name = "checkBox52";
            this.checkBox52.Size = new System.Drawing.Size(59, 17);
            this.checkBox52.TabIndex = 27;
            this.checkBox52.Text = "Kanker";
            this.checkBox52.UseVisualStyleBackColor = true;
            // 
            // checkBox51
            // 
            this.checkBox51.AutoSize = true;
            this.checkBox51.Enabled = false;
            this.checkBox51.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox51.Location = new System.Drawing.Point(364, 27);
            this.checkBox51.Name = "checkBox51";
            this.checkBox51.Size = new System.Drawing.Size(57, 17);
            this.checkBox51.TabIndex = 26;
            this.checkBox51.Text = "Stroke";
            this.checkBox51.UseVisualStyleBackColor = true;
            // 
            // checkBox50
            // 
            this.checkBox50.AutoSize = true;
            this.checkBox50.Enabled = false;
            this.checkBox50.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox50.Location = new System.Drawing.Point(320, 27);
            this.checkBox50.Name = "checkBox50";
            this.checkBox50.Size = new System.Drawing.Size(48, 17);
            this.checkBox50.TabIndex = 25;
            this.checkBox50.Text = "Paru";
            this.checkBox50.UseVisualStyleBackColor = true;
            // 
            // checkBox48
            // 
            this.checkBox48.AutoSize = true;
            this.checkBox48.Enabled = false;
            this.checkBox48.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox48.Location = new System.Drawing.Point(257, 27);
            this.checkBox48.Name = "checkBox48";
            this.checkBox48.Size = new System.Drawing.Size(65, 17);
            this.checkBox48.TabIndex = 24;
            this.checkBox48.Text = "Jantung";
            this.checkBox48.UseVisualStyleBackColor = true;
            // 
            // checkBox47
            // 
            this.checkBox47.AutoSize = true;
            this.checkBox47.Enabled = false;
            this.checkBox47.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox47.Location = new System.Drawing.Point(213, 27);
            this.checkBox47.Name = "checkBox47";
            this.checkBox47.Size = new System.Drawing.Size(45, 17);
            this.checkBox47.TabIndex = 23;
            this.checkBox47.Text = "Hati";
            this.checkBox47.UseVisualStyleBackColor = true;
            // 
            // checkBox46
            // 
            this.checkBox46.AutoSize = true;
            this.checkBox46.Enabled = false;
            this.checkBox46.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox46.Location = new System.Drawing.Point(162, 27);
            this.checkBox46.Name = "checkBox46";
            this.checkBox46.Size = new System.Drawing.Size(52, 17);
            this.checkBox46.TabIndex = 22;
            this.checkBox46.Text = "Ginjal";
            this.checkBox46.UseVisualStyleBackColor = true;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(1, 7);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(179, 13);
            this.label22.TabIndex = 10;
            this.label22.Text = "3. Pasien dengan diagnose khusus :";
            // 
            // checkBox54
            // 
            this.checkBox54.AutoSize = true;
            this.checkBox54.Enabled = false;
            this.checkBox54.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox54.Location = new System.Drawing.Point(122, 54);
            this.checkBox54.Name = "checkBox54";
            this.checkBox54.Size = new System.Drawing.Size(122, 17);
            this.checkBox54.TabIndex = 29;
            this.checkBox54.Text = "Penurunan Imunitas";
            this.checkBox54.UseVisualStyleBackColor = true;
            // 
            // chkEtc14
            // 
            this.chkEtc14.AutoSize = true;
            this.chkEtc14.Enabled = false;
            this.chkEtc14.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkEtc14.Location = new System.Drawing.Point(250, 54);
            this.chkEtc14.Name = "chkEtc14";
            this.chkEtc14.Size = new System.Drawing.Size(63, 17);
            this.chkEtc14.TabIndex = 30;
            this.chkEtc14.Text = "Lainnya";
            this.chkEtc14.UseVisualStyleBackColor = true;
            this.chkEtc14.CheckedChanged += new System.EventHandler(this.chkEtc14_CheckedChanged);
            // 
            // rgDiagnoseKh
            // 
            this.rgDiagnoseKh.Location = new System.Drawing.Point(10, 23);
            this.rgDiagnoseKh.Name = "rgDiagnoseKh";
            this.rgDiagnoseKh.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgDiagnoseKh.Properties.Columns = 2;
            this.rgDiagnoseKh.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(0, "Tidak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(1, "Ya")});
            this.rgDiagnoseKh.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Flow;
            this.rgDiagnoseKh.Size = new System.Drawing.Size(109, 20);
            this.rgDiagnoseKh.TabIndex = 20;
            this.rgDiagnoseKh.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // checkBox45
            // 
            this.checkBox45.AutoSize = true;
            this.checkBox45.Enabled = false;
            this.checkBox45.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox45.Location = new System.Drawing.Point(122, 27);
            this.checkBox45.Name = "checkBox45";
            this.checkBox45.Size = new System.Drawing.Size(41, 17);
            this.checkBox45.TabIndex = 21;
            this.checkBox45.Text = "DM";
            this.checkBox45.UseVisualStyleBackColor = true;
            // 
            // pnlLaporTim
            // 
            this.pnlLaporTim.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlLaporTim.Controls.Add(this.txLaporDtl);
            this.pnlLaporTim.Controls.Add(this.label24);
            this.pnlLaporTim.Controls.Add(this.label23);
            this.pnlLaporTim.Controls.Add(this.rgLapor_tr_Gizi);
            this.pnlLaporTim.Location = new System.Drawing.Point(-6, 208);
            this.pnlLaporTim.Name = "pnlLaporTim";
            this.pnlLaporTim.Size = new System.Drawing.Size(612, 30);
            this.pnlLaporTim.TabIndex = 12;
            // 
            // txLaporDtl
            // 
            this.txLaporDtl.Enabled = false;
            this.txLaporDtl.Location = new System.Drawing.Point(349, 4);
            this.txLaporDtl.Name = "txLaporDtl";
            this.txLaporDtl.Size = new System.Drawing.Size(209, 21);
            this.txLaporDtl.TabIndex = 33;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(280, 8);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(68, 13);
            this.label24.TabIndex = 11;
            this.label24.Text = "Tanggal-Jam";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(7, 9);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(177, 13);
            this.label23.TabIndex = 12;
            this.label23.Text = "Sudah dilaporkan ke tim terapi Gizi :";
            // 
            // rgLapor_tr_Gizi
            // 
            this.rgLapor_tr_Gizi.Location = new System.Drawing.Point(183, 4);
            this.rgLapor_tr_Gizi.Name = "rgLapor_tr_Gizi";
            this.rgLapor_tr_Gizi.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgLapor_tr_Gizi.Properties.Columns = 2;
            this.rgLapor_tr_Gizi.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(0, "Tidak"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(1, "Ya")});
            this.rgLapor_tr_Gizi.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Flow;
            this.rgLapor_tr_Gizi.Size = new System.Drawing.Size(109, 20);
            this.rgLapor_tr_Gizi.TabIndex = 32;
            this.rgLapor_tr_Gizi.SelectedIndexChanged += new System.EventHandler(this.EnableTextEdit);
            // 
            // pnlBeratBadan
            // 
            this.pnlBeratBadan.Controls.Add(this.lebrtbadan);
            this.pnlBeratBadan.Controls.Add(this.label20);
            this.pnlBeratBadan.Controls.Add(this.label6);
            this.pnlBeratBadan.Controls.Add(this.rgTurunBB);
            this.pnlBeratBadan.Location = new System.Drawing.Point(3, 18);
            this.pnlBeratBadan.Name = "pnlBeratBadan";
            this.pnlBeratBadan.Size = new System.Drawing.Size(509, 72);
            this.pnlBeratBadan.TabIndex = 11;
            // 
            // lebrtbadan
            // 
            this.lebrtbadan.Enabled = false;
            this.lebrtbadan.Location = new System.Drawing.Point(275, 48);
            this.lebrtbadan.Name = "lebrtbadan";
            this.lebrtbadan.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.lebrtbadan.Properties.NullText = "";
            this.lebrtbadan.Size = new System.Drawing.Size(201, 20);
            this.lebrtbadan.TabIndex = 18;
            this.lebrtbadan.EditValueChanged += new System.EventHandler(this.getScoreScriningGizi);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(15, 51);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(255, 13);
            this.label20.TabIndex = 11;
            this.label20.Text = "Jika ya, berapa penuruanan berat badan tersebut :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(2, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(477, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "1. Apakah Pasien mengalami penurunan berat badan ynag tidak diinginkan dalam 6 bu" +
    "lan terakhir?";
            // 
            // rgTurunBB
            // 
            this.rgTurunBB.Location = new System.Drawing.Point(11, 28);
            this.rgTurunBB.Name = "rgTurunBB";
            this.rgTurunBB.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgTurunBB.Properties.Columns = 2;
            this.rgTurunBB.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Tidak penurunan berat badan"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(2)), "Tidak yakin/tidak tahu/terasa baju lebih longgar"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(0, "Ya")});
            this.rgTurunBB.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Flow;
            this.rgTurunBB.Size = new System.Drawing.Size(481, 20);
            this.rgTurunBB.TabIndex = 17;
            this.rgTurunBB.SelectedIndexChanged += new System.EventHandler(this.getScoreScriningGizi);
            // 
            // txScoreScrining
            // 
            this.txScoreScrining.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txScoreScrining.BackColor = System.Drawing.Color.White;
            this.txScoreScrining.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txScoreScrining.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txScoreScrining.ForeColor = System.Drawing.Color.DimGray;
            this.txScoreScrining.Location = new System.Drawing.Point(568, 28);
            this.txScoreScrining.Name = "txScoreScrining";
            this.txScoreScrining.Size = new System.Drawing.Size(41, 30);
            this.txScoreScrining.TabIndex = 10;
            this.txScoreScrining.Text = "0";
            this.txScoreScrining.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(4, 93);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(333, 13);
            this.label21.TabIndex = 8;
            this.label21.Text = "2. Apakah asupan makanan berkurang karena berkurangnya nafsu?";
            // 
            // rgAsupanMakan
            // 
            this.rgAsupanMakan.Location = new System.Drawing.Point(13, 110);
            this.rgAsupanMakan.Name = "rgAsupanMakan";
            this.rgAsupanMakan.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.rgAsupanMakan.Properties.Columns = 2;
            this.rgAsupanMakan.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(1, "Ya"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(0)), "Tidak")});
            this.rgAsupanMakan.Properties.ItemsLayout = DevExpress.XtraEditors.RadioGroupItemsLayout.Flow;
            this.rgAsupanMakan.Size = new System.Drawing.Size(109, 20);
            this.rgAsupanMakan.TabIndex = 19;
            this.rgAsupanMakan.SelectedIndexChanged += new System.EventHandler(this.getScoreScriningGizi);
            this.rgAsupanMakan.Click += new System.EventHandler(this.getScoreScriningGizi);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.splitContainerControl1, 0, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1264, 681);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // FrmRawatInap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "FrmRawatInap";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Rawat Inap";
            this.Load += new System.EventHandler(this.FrmRawatInap_Load);
            this.tab5.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.pnlPulang1.ResumeLayout(false);
            this.scrolPulang.ResumeLayout(false);
            this.xtraScrollableControl8.ResumeLayout(false);
            this.xtraScrollableControl12.ResumeLayout(false);
            this.xtraScrollableControl12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txAltTerpsang.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txKeadaanDtl.Properties)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txDoc3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txDoc5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txDoc6.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txDoc4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txDoc2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txDoc1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcObtPlng)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvObtPlng)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txObatRutin.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgRawatLanjutan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txWaktu.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txdoRawat.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txKebiasaanlain.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txDokterDituju.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txTindakan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txPsikologis.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txProcedurePlan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txControlLanjutan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txProcRawat.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txUnitKesehatan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txPolaMakan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txAktivitas.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txjenisPeriksa.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtkeluar.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtkeluar.Properties)).EndInit();
            this.panel14.ResumeLayout(false);
            this.xtraScrollableControl9.ResumeLayout(false);
            this.xtraScrollableControl11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txAnjuran.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mmPeriksaFisik.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txAnamesa.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txTerapiLanjtan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txTindakanDo.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txPengobatan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txDiagnosaAkhir.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txDokterKonsultan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txDokterPengirim.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtKeluarx.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtKeluarx.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl3)).EndInit();
            this.splitContainerControl3.ResumeLayout(false);
            this.tbLayJdObat.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl2)).EndInit();
            this.splitContainerControl2.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gcCppt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvCppt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpDatex.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpDatex)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txJamx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpKodePpa)).EndInit();
            this.panel17.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl4)).EndInit();
            this.splitContainerControl4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gcJadwalObat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvJadwalObat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbJnisObaT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpDate.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpTimetx)).EndInit();
            this.panel7.ResumeLayout(false);
            this.tableLayoutPanel11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl5)).EndInit();
            this.splitContainerControl5.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gcVt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvVt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpDateVx.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpDateVx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rpTxShu)).EndInit();
            this.panel9.ResumeLayout(false);
            this.tableLayoutPanel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(xyDiagram1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(pointSeriesLabel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(lineSeriesView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(pointSeriesLabel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(lineSeriesView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(pointSeriesLabel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(lineSeriesView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chrVital)).EndInit();
            this.pnlAsGizi.ResumeLayout(false);
            this.xtraScrollableControl6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txMonitoring.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txIntrvnsiGz.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txDiagnosGz.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txRiwytPerson.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txAsupnLbh.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txAsupnKurng.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txPolaMkn.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txAlergiMkn.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txBiokimia.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txKlinis.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txImtDw.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txKbthnKarbo.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txKbthnLemak.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txKbthnProtein.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txKbthnEnergi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txPercenKarbo.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txNilaiKarbo.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txPercenLemak.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txNilaiLemak.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txPercenProtein.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txNilaiProtein.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txPercenEnergi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txNlaiEnergi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txBBU.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txTgLutut.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txBBTB.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txBbDw.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txImtAnk.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txTbDw.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txLilaDw.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txStsGizi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txBbi.Properties)).EndInit();
            this.tab3.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tab1.ResumeLayout(false);
            this.formLayout.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.frmLayout1.ResumeLayout(false);
            this.layout123.ResumeLayout(false);
            this.gbRwObat.ResumeLayout(false);
            this.gbRwObat.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgRiwayatObat.Properties)).EndInit();
            this.g1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.mmKeluhan.Properties)).EndInit();
            this.g2.ResumeLayout(false);
            this.xtraScrollableControl1.ResumeLayout(false);
            this.gbPernahDirawat.ResumeLayout(false);
            this.gbPernahDirawat.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgPernahRawat.Properties)).EndInit();
            this.gbRwkerja.ResumeLayout(false);
            this.gbRwkerja.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgRiwayatKerja.Properties)).EndInit();
            this.gbRwAlergi.ResumeLayout(false);
            this.gbRwAlergi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgAlergi.Properties)).EndInit();
            this.gbTergantungThdp.ResumeLayout(false);
            this.gbTergantungThdp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgKetergantungan.Properties)).EndInit();
            this.gbRwSakitKlrg.ResumeLayout(false);
            this.gbRwSakitKlrg.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgRwSktKlrg.Properties)).EndInit();
            this.gbPernahOperasi.ResumeLayout(false);
            this.gbPernahOperasi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgPrnhOperasi.Properties)).EndInit();
            this.gbRwPenyakitlalu.ResumeLayout(false);
            this.gbRwPenyakitlalu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgSakitLalu.Properties)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.Scroll2.ResumeLayout(false);
            this.Scroll2.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgPeriksaKhusus.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.pnlKulit.ResumeLayout(false);
            this.pnlKulit.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgKulit.Properties)).EndInit();
            this.pnlDekubitus.ResumeLayout(false);
            this.pnlDekubitus.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rbDekubitus.Properties)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.pnlMiksi.ResumeLayout(false);
            this.pnlMiksi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgMiksi.Properties)).EndInit();
            this.pnlDefekasi.ResumeLayout(false);
            this.pnlDefekasi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgDefekasi.Properties)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.pnlPenglihatan.ResumeLayout(false);
            this.pnlPenglihatan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgPenglihatan.Properties)).EndInit();
            this.pnlPendengaran.ResumeLayout(false);
            this.pnlPendengaran.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgPendengaran.Properties)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.pnlBatasMakan.ResumeLayout(false);
            this.pnlBatasMakan.PerformLayout();
            this.pnlMuntah.ResumeLayout(false);
            this.pnlMuntah.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgMuntah.Properties)).EndInit();
            this.pnlMual.ResumeLayout(false);
            this.pnlMual.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgMual.Properties)).EndInit();
            this.pnlGigiPalsu.ResumeLayout(false);
            this.pnlGigiPalsu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgGigiPalsu.Properties)).EndInit();
            this.pnKeluhan.ResumeLayout(false);
            this.pnKeluhan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgKeluhan.Properties)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.xtraScrollableControl3.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.xtraScrollableControl2.ResumeLayout(false);
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.pnlTempatTinggal.ResumeLayout(false);
            this.pnlTempatTinggal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgTmpTinggal.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgHubKluarga.Properties)).EndInit();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox25.ResumeLayout(false);
            this.groupBox25.PerformLayout();
            this.gbStsPsikologi.ResumeLayout(false);
            this.gbStsPsikologi.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.xtraScrollableControl4.ResumeLayout(false);
            this.xtraScrollableControl4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgMnrimaInfo.Properties)).EndInit();
            this.pnlButuhPnrjmh.ResumeLayout(false);
            this.pnlButuhPnrjmh.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgPnrjemah.Properties)).EndInit();
            this.pnlKbthnEdukasi.ResumeLayout(false);
            this.pnlKbthnEdukasi.PerformLayout();
            this.pnlSedia.ResumeLayout(false);
            this.pnlSedia.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgSedia.Properties)).EndInit();
            this.gbResikoCedera.ResumeLayout(false);
            this.gbResikoCedera.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgResikoCedera.Properties)).EndInit();
            this.gbHambatanBljr.ResumeLayout(false);
            this.gbHambatanBljr.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgHmbtanBljr.Properties)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).EndInit();
            this.splitContainerControl1.ResumeLayout(false);
            this.panTbl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvwMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mainTab)).EndInit();
            this.mainTab.ResumeLayout(false);
            this.tab2.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.groupBox18.ResumeLayout(false);
            this.tableLayoutPanel13.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mmPerawat.Properties)).EndInit();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mmDokter.Properties)).EndInit();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mmTujuanTerukur.Properties)).EndInit();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.pnlRisikoJatuh.ResumeLayout(false);
            this.pnlRJAnak.ResumeLayout(false);
            this.xtraScrollableControl7.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rgJenkel.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgSedasiAnestesi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgGangguan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rguseObat.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgFlingkungan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgDiagnosis.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgUsia.Properties)).EndInit();
            this.pnlRJDewasa.ResumeLayout(false);
            this.xScrolJatuhDwasa.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.pnlStsmental.ResumeLayout(false);
            this.pnlStsmental.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgstsMental.Properties)).EndInit();
            this.pnlGayaJalan.ResumeLayout(false);
            this.pnlGayaJalan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgGayaJalan.Properties)).EndInit();
            this.pnlInfus.ResumeLayout(false);
            this.pnlInfus.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgInfus.Properties)).EndInit();
            this.pnlLatBantuJalan.ResumeLayout(false);
            this.pnlLatBantuJalan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgAltBantuJalan.Properties)).EndInit();
            this.pnlDiagnosaSekunder.ResumeLayout(false);
            this.pnlDiagnosaSekunder.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgDiagnosaSekunder.Properties)).EndInit();
            this.pnlRiwayatJatuh.ResumeLayout(false);
            this.pnlRiwayatJatuh.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgRiwayatJatuh.Properties)).EndInit();
            this.panel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rgKatgriPasien.Properties)).EndInit();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.gbStsFungsi.ResumeLayout(false);
            this.gbStsFungsi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgMobilisasi.Properties)).EndInit();
            this.groupBox16.ResumeLayout(false);
            this.xtraScrollableControl10.ResumeLayout(false);
            this.xtraScrollableControl10.PerformLayout();
            this.pnlSkalaNyeri.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.rgTingkatNyeri.Properties)).EndInit();
            this.gbNyeriHilang.ResumeLayout(false);
            this.gbNyeriHilang.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgNyeri.Properties)).EndInit();
            this.xtraScrollableControl5.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.pnlDiagnoseKhusus.ResumeLayout(false);
            this.pnlDiagnoseKhusus.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgDiagnoseKh.Properties)).EndInit();
            this.pnlLaporTim.ResumeLayout(false);
            this.pnlLaporTim.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rgLapor_tr_Gizi.Properties)).EndInit();
            this.pnlBeratBadan.ResumeLayout(false);
            this.pnlBeratBadan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lebrtbadan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgTurunBB.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgAsupanMakan.Properties)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private DevExpress.XtraTab.XtraTabPage tab5;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl3;
        private DevExpress.XtraTab.XtraTabPage tab3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private DevExpress.XtraTab.XtraTabPage tab1;
        private System.Windows.Forms.Panel panel1;
        private DevExpress.XtraEditors.SimpleButton btnSimpan;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl1;
        private DevExpress.XtraTab.XtraTabControl mainTab;
        private DevExpress.XtraTab.XtraTabPage tab2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel formLayout;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TableLayoutPanel frmLayout1;
        private System.Windows.Forms.TableLayoutPanel layout123;
        private System.Windows.Forms.GroupBox gbRwObat;
        private System.Windows.Forms.TextBox txRiwayatObat;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.GroupBox g1;
        private DevExpress.XtraEditors.MemoEdit mmKeluhan;
        private System.Windows.Forms.GroupBox g2;
        private DevExpress.XtraEditors.XtraScrollableControl xtraScrollableControl1;
        private System.Windows.Forms.GroupBox gbPernahDirawat;
        private System.Windows.Forms.TextBox txRawatDi;
        private System.Windows.Forms.TextBox txKapanRawat;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txDiagnosa;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox gbRwkerja;
        private System.Windows.Forms.TextBox txRwytKerja;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.GroupBox gbRwAlergi;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.TextBox txAlergi;
        private System.Windows.Forms.CheckBox checkBox22;
        private System.Windows.Forms.GroupBox gbTergantungThdp;
        private System.Windows.Forms.CheckBox checkBox17;
        private System.Windows.Forms.TextBox txketergantungan;
        private System.Windows.Forms.CheckBox checkBox19;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.GroupBox gbRwSakitKlrg;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.TextBox txSakitKlrga;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.GroupBox gbPernahOperasi;
        private System.Windows.Forms.TextBox txJnsOperasi;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox gbRwPenyakitlalu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.GroupBox groupBox6;
        private DevExpress.XtraEditors.XtraScrollableControl Scroll2;
        private System.Windows.Forms.TextBox txP;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txSuhu;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Panel pnlPenglihatan;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox txPnglihtDtl;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Panel pnlPendengaran;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox txPdngrDtl;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txImt;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox txGstKet;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox txTbPb;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox txBB;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Panel pnlBatasMakan;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox txBtsMakan;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Panel pnlMuntah;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Panel pnlMual;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Panel pnlGigiPalsu;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Panel pnKeluhan;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox txKeluhan;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox txNadi;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txTd;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Panel pnlDekubitus;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox txSkorNorton;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Panel pnlKulit;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TextBox txKulitDtl;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Panel pnlMiksi;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox txMiksiDtl;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Panel pnlDefekasi;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox txDefekasiDtl;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.PictureBox pictureBox3;
        private DevExpress.XtraEditors.RadioGroup rgPeriksaKhusus;
        private System.Windows.Forms.TextBox txPeriksaFisik;
        private System.Windows.Forms.CheckedListBox ckLokasiLuka;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label69;
        private DevExpress.XtraEditors.RadioGroup rgRiwayatKerja;
        private DevExpress.XtraEditors.RadioGroup rgAlergi;
        private DevExpress.XtraEditors.RadioGroup rgKetergantungan;
        private DevExpress.XtraEditors.RadioGroup rgRwSktKlrg;
        private DevExpress.XtraEditors.RadioGroup rgPrnhOperasi;
        private DevExpress.XtraEditors.RadioGroup rgSakitLalu;
        private DevExpress.XtraEditors.RadioGroup rgPernahRawat;
        private DevExpress.XtraEditors.RadioGroup rbDekubitus;
        private DevExpress.XtraEditors.RadioGroup rgKulit;
        private DevExpress.XtraEditors.RadioGroup rgMiksi;
        private DevExpress.XtraEditors.RadioGroup rgDefekasi;
        private DevExpress.XtraEditors.RadioGroup rgPenglihatan;
        private DevExpress.XtraEditors.RadioGroup rgPendengaran;
        private DevExpress.XtraEditors.RadioGroup rgMuntah;
        private DevExpress.XtraEditors.RadioGroup rgMual;
        private DevExpress.XtraEditors.RadioGroup rgGigiPalsu;
        private DevExpress.XtraEditors.RadioGroup rgKeluhan;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private DevExpress.XtraEditors.XtraScrollableControl xtraScrollableControl3;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.CheckBox checkBox27;
        private System.Windows.Forms.CheckBox checkBox26;
        private System.Windows.Forms.CheckBox checkBox23;
        private System.Windows.Forms.CheckBox checkBox24;
        private System.Windows.Forms.CheckBox checkBox25;
        private System.Windows.Forms.CheckBox checkBox21;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.Label label71;
        private DevExpress.XtraEditors.XtraScrollableControl xtraScrollableControl4;
        private System.Windows.Forms.Panel pnlSedia;
        private System.Windows.Forms.CheckBox checkBox43;
        private System.Windows.Forms.CheckBox checkBox41;
        private System.Windows.Forms.CheckBox checkBox42;
        private DevExpress.XtraEditors.RadioGroup rgSedia;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.GroupBox gbResikoCedera;
        private System.Windows.Forms.Label label83;
        private DevExpress.XtraEditors.RadioGroup rgResikoCedera;
        private System.Windows.Forms.GroupBox gbHambatanBljr;
        private System.Windows.Forms.CheckBox checkBox38;
        private System.Windows.Forms.CheckBox checkBox40;
        private System.Windows.Forms.CheckBox checkBox39;
        private System.Windows.Forms.CheckBox checkBox37;
        private DevExpress.XtraEditors.RadioGroup rgHmbtanBljr;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.GroupBox gbStsFungsi;
        private System.Windows.Forms.TextBox txAltBantujalan;
        private System.Windows.Forms.TextBox txMobilisasiDtl;
        private System.Windows.Forms.Label label7;
        private DevExpress.XtraEditors.RadioGroup rgMobilisasi;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private DevExpress.XtraEditors.XtraScrollableControl xtraScrollableControl5;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label21;
        private DevExpress.XtraEditors.RadioGroup rgAsupanMakan;
        private System.Windows.Forms.Label txScoreScrining;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.GroupBox groupBox18;
        private DevExpress.XtraEditors.MemoEdit mmTujuanTerukur;
        private DevExpress.XtraEditors.MemoEdit mmDokter;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label88;
        private DevExpress.XtraEditors.MemoEdit mmPerawat;
        private System.Windows.Forms.CheckBox chkSusunRencana;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Panel pnlPulang1;
        private System.Windows.Forms.Panel panel14;
        private DevExpress.XtraEditors.XtraScrollableControl scrolPulang;
        private System.Windows.Forms.Panel pnlRisikoJatuh;
        private System.Windows.Forms.Panel panel12;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private System.Windows.Forms.Panel pnlRJAnak;
        private DevExpress.XtraEditors.RadioGroup rgKatgriPasien;
        private System.Windows.Forms.Panel pnlRJDewasa;
        private DevExpress.XtraEditors.XtraScrollableControl xScrolJatuhDwasa;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private System.Windows.Forms.Label txTotalNilai;
        private DevExpress.XtraEditors.XtraScrollableControl xtraScrollableControl7;
        private DevExpress.XtraEditors.RadioGroup rgJenkel;
        private DevExpress.XtraEditors.RadioGroup rgSedasiAnestesi;
        private DevExpress.XtraEditors.RadioGroup rgGangguan;
        private DevExpress.XtraEditors.LabelControl labelControl32;
        private DevExpress.XtraEditors.RadioGroup rguseObat;
        private DevExpress.XtraEditors.LabelControl labelControl30;
        private DevExpress.XtraEditors.RadioGroup rgFlingkungan;
        private DevExpress.XtraEditors.LabelControl labelControl31;
        private DevExpress.XtraEditors.RadioGroup rgDiagnosis;
        private DevExpress.XtraEditors.LabelControl labelControl29;
        private DevExpress.XtraEditors.RadioGroup rgUsia;
        private DevExpress.XtraEditors.LabelControl labelControl28;
        private DevExpress.XtraEditors.LabelControl labelControl27;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private System.Windows.Forms.TableLayoutPanel tbLayJdObat;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl2;
        private System.Windows.Forms.Panel panel16;
        private DevExpress.XtraGrid.GridControl gcCppt;
        private DevExpress.XtraGrid.Views.Grid.GridView gvCppt;
        private System.Windows.Forms.Panel panel17;
        private DevExpress.XtraGrid.GridControl gcJadwalObat;
        private DevExpress.XtraGrid.Views.Grid.GridView gvJadwalObat;
        private System.Windows.Forms.Panel pnlAsGizi;
        private System.Windows.Forms.TextBox txSakitLalu;
        private DevExpress.XtraEditors.RadioGroup rgRiwayatObat;
        private System.Windows.Forms.Panel pnlKbthnEdukasi;
        private System.Windows.Forms.TextBox txKbthnEdukasi;
        private System.Windows.Forms.Panel pnlButuhPnrjmh;
        private DevExpress.XtraEditors.RadioGroup rgPnrjemah;
        private System.Windows.Forms.TextBox txPnrjmhDtl;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.CheckBox chkEtc12;
        private System.Windows.Forms.CheckBox checkBox44;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Panel pnlBeratBadan;
        private DevExpress.XtraEditors.LookUpEdit lebrtbadan;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label6;
        private DevExpress.XtraEditors.RadioGroup rgTurunBB;
        private System.Windows.Forms.Panel pnlLaporTim;
        private System.Windows.Forms.TextBox txLaporDtl;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private DevExpress.XtraEditors.RadioGroup rgLapor_tr_Gizi;
        private System.Windows.Forms.Panel pnlDiagnoseKhusus;
        private System.Windows.Forms.TextBox txDiagnoseDtl;
        private System.Windows.Forms.CheckBox checkBox53;
        private System.Windows.Forms.CheckBox checkBox52;
        private System.Windows.Forms.CheckBox checkBox51;
        private System.Windows.Forms.CheckBox checkBox50;
        private System.Windows.Forms.CheckBox checkBox48;
        private System.Windows.Forms.CheckBox checkBox47;
        private System.Windows.Forms.CheckBox checkBox46;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.CheckBox chkEtc14;
        private DevExpress.XtraEditors.RadioGroup rgDiagnoseKh;
        private System.Windows.Forms.CheckBox checkBox45;
        private System.Windows.Forms.CheckBox checkBox54;
        private System.Windows.Forms.Label label96;
        private DevExpress.XtraEditors.RadioGroup rgMnrimaInfo;
        private System.Windows.Forms.Panel pnlLatBantuJalan;
        private System.Windows.Forms.TextBox txKet3;
        private DevExpress.XtraEditors.RadioGroup rgAltBantuJalan;
        private System.Windows.Forms.Panel pnlDiagnosaSekunder;
        private System.Windows.Forms.TextBox txKet2;
        private DevExpress.XtraEditors.RadioGroup rgDiagnosaSekunder;
        private System.Windows.Forms.Panel pnlRiwayatJatuh;
        private System.Windows.Forms.TextBox txKet1;
        private DevExpress.XtraEditors.RadioGroup rgRiwayatJatuh;
        private System.Windows.Forms.Panel pnlStsmental;
        private System.Windows.Forms.TextBox txket6;
        private DevExpress.XtraEditors.RadioGroup rgstsMental;
        private System.Windows.Forms.Panel pnlGayaJalan;
        private System.Windows.Forms.TextBox txKet5;
        private DevExpress.XtraEditors.RadioGroup rgGayaJalan;
        private System.Windows.Forms.Panel pnlInfus;
        private System.Windows.Forms.TextBox txket4;
        private DevExpress.XtraEditors.RadioGroup rgInfus;
        private System.Windows.Forms.Label txScoreAnak;
        private System.Windows.Forms.Label txResikoAnak;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox cbJnisObaT;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit rpDate;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraEditors.SimpleButton btnAddJadwalObat;
        private DevExpress.XtraEditors.SimpleButton btnSimpanObat;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit rpTimetx;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit rpDatex;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit txJamx;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn16;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn17;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn18;
        private DevExpress.XtraEditors.SimpleButton btnSaveCppt;
        private DevExpress.XtraEditors.SimpleButton btnAddCppt;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox rpKodePpa;
        private System.Windows.Forms.Button btnInputData;
        private System.Windows.Forms.TextBox txHmbtan;
        private System.Windows.Forms.TextBox txSedia;
        private DevExpress.XtraEditors.SimpleButton btnSaveX;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl4;
        private System.Windows.Forms.CheckBox txLain2;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox28;
        private DevExpress.XtraEditors.LabelControl labelControl93;
        private DevExpress.XtraEditors.LabelControl labelControl36;
        private DevExpress.XtraEditors.XtraScrollableControl xtraScrollableControl8;
        private DevExpress.XtraEditors.LabelControl labelControl26;
        private DevExpress.XtraEditors.XtraScrollableControl xtraScrollableControl9;
        private DevExpress.XtraEditors.LabelControl labelControl95;
        private DevExpress.XtraEditors.LabelControl labelControl96;
        private DevExpress.XtraEditors.LabelControl labelControl97;
        private DevExpress.XtraEditors.LabelControl lblTindakan;
        private DevExpress.XtraEditors.LabelControl txResikoDewasa;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl5;
        private System.Windows.Forms.Panel panel8;
        private DevExpress.XtraEditors.SimpleButton btnSaveV;
        private DevExpress.XtraEditors.SimpleButton btnAddVt;
        private DevExpress.XtraGrid.GridControl gcVt;
        private DevExpress.XtraGrid.Views.Grid.GridView gvVt;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn24;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn25;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit rpDateVx;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn26;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit rpTxShu;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn27;
        private System.Windows.Forms.Panel panel9;
        private DevExpress.XtraEditors.LabelControl labelControl98;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel12;
        private DevExpress.XtraCharts.ChartControl chrVital;
        private DevExpress.XtraEditors.XtraScrollableControl xtraScrollableControl10;
        private System.Windows.Forms.Panel pnlSkalaNyeri;
        private System.Windows.Forms.CheckedListBox chkSkalaNyeri;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txScorNyeri;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.TextBox txDurasiNyeri;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txFrekuensi;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txLokasiNyeri;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private DevExpress.XtraEditors.RadioGroup rgTingkatNyeri;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox gbNyeriHilang;
        private System.Windows.Forms.TextBox txNyeriHilang;
        private System.Windows.Forms.CheckBox chkEtc7;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.Label label9;
        private DevExpress.XtraEditors.RadioGroup rgNyeri;
        private DevExpress.XtraEditors.LabelControl labelControl99;
        private DevExpress.XtraEditors.LabelControl labelControl100;
        private DevExpress.XtraEditors.LabelControl labelControl101;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel13;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel13;
        private DevExpress.XtraEditors.XtraScrollableControl xtraScrollableControl2;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.Panel pnlTempatTinggal;
        private System.Windows.Forms.TextBox txTpTinggalDtl;
        private DevExpress.XtraEditors.RadioGroup rgTmpTinggal;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.TextBox txTlpKerabat;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.TextBox txHubKerabat;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.TextBox txNmKerabat;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label74;
        private DevExpress.XtraEditors.RadioGroup rgHubKluarga;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.TextBox txStsMental3;
        private System.Windows.Forms.TextBox txStsMental2;
        private System.Windows.Forms.CheckBox chkStasMental3;
        private System.Windows.Forms.CheckBox chkStsMental2;
        private System.Windows.Forms.CheckBox ckStsMental1;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.TextBox txkegSpirit;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.TextBox txkegAgama;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.GroupBox gbStsPsikologi;
        private System.Windows.Forms.CheckBox checkBox32;
        private System.Windows.Forms.CheckBox checkBox33;
        private System.Windows.Forms.CheckBox checkBox34;
        private System.Windows.Forms.CheckBox checkBox35;
        private System.Windows.Forms.CheckBox checkBox36;
        private System.Windows.Forms.TextBox txStsPsikologi;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.CheckBox chkEtc5;
        private DevExpress.XtraEditors.XtraScrollableControl xtraScrollableControl6;
        private System.Windows.Forms.Panel panel20;
        private DevExpress.XtraEditors.LabelControl labelControl75;
        private DevExpress.XtraEditors.LabelControl labelControl79;
        private DevExpress.XtraEditors.LabelControl labelControl77;
        private DevExpress.XtraEditors.LabelControl labelControl73;
        private DevExpress.XtraEditors.LabelControl labelControl70;
        private DevExpress.XtraEditors.LabelControl labelControl51;
        private DevExpress.XtraEditors.TextEdit txMonitoring;
        private DevExpress.XtraEditors.TextEdit txIntrvnsiGz;
        private DevExpress.XtraEditors.TextEdit txDiagnosGz;
        private DevExpress.XtraEditors.TextEdit txRiwytPerson;
        private DevExpress.XtraEditors.LabelControl labelControl90;
        private DevExpress.XtraEditors.TextEdit txAsupnLbh;
        private DevExpress.XtraEditors.LabelControl labelControl89;
        private DevExpress.XtraEditors.TextEdit txAsupnKurng;
        private DevExpress.XtraEditors.LabelControl labelControl88;
        private DevExpress.XtraEditors.TextEdit txPolaMkn;
        private DevExpress.XtraEditors.LabelControl labelControl87;
        private DevExpress.XtraEditors.TextEdit txAlergiMkn;
        private DevExpress.XtraEditors.LabelControl labelControl86;
        private DevExpress.XtraEditors.TextEdit txBiokimia;
        private DevExpress.XtraEditors.LabelControl labelControl44;
        private DevExpress.XtraEditors.TextEdit txKlinis;
        private DevExpress.XtraEditors.LabelControl labelControl85;
        private DevExpress.XtraEditors.LabelControl labelControl45;
        private DevExpress.XtraEditors.LabelControl labelControl46;
        private DevExpress.XtraEditors.TextEdit txImtDw;
        private DevExpress.XtraEditors.TextEdit txKbthnKarbo;
        private DevExpress.XtraEditors.TextEdit txKbthnLemak;
        private DevExpress.XtraEditors.TextEdit txKbthnProtein;
        private DevExpress.XtraEditors.TextEdit txKbthnEnergi;
        private DevExpress.XtraEditors.TextEdit txPercenKarbo;
        private DevExpress.XtraEditors.TextEdit txNilaiKarbo;
        private DevExpress.XtraEditors.TextEdit txPercenLemak;
        private DevExpress.XtraEditors.TextEdit txNilaiLemak;
        private DevExpress.XtraEditors.TextEdit txPercenProtein;
        private DevExpress.XtraEditors.TextEdit txNilaiProtein;
        private DevExpress.XtraEditors.TextEdit txPercenEnergi;
        private DevExpress.XtraEditors.TextEdit txNlaiEnergi;
        private DevExpress.XtraEditors.TextEdit txBBU;
        private DevExpress.XtraEditors.TextEdit txTgLutut;
        private DevExpress.XtraEditors.TextEdit txBBTB;
        private DevExpress.XtraEditors.TextEdit txBbDw;
        private DevExpress.XtraEditors.TextEdit txImtAnk;
        private DevExpress.XtraEditors.TextEdit txTbDw;
        private DevExpress.XtraEditors.TextEdit txLilaDw;
        private DevExpress.XtraEditors.LabelControl labelControl78;
        private DevExpress.XtraEditors.TextEdit txStsGizi;
        private DevExpress.XtraEditors.LabelControl labelControl37;
        private DevExpress.XtraEditors.LabelControl labelControl39;
        private DevExpress.XtraEditors.LabelControl labelControl43;
        private DevExpress.XtraEditors.LabelControl labelControl42;
        private DevExpress.XtraEditors.LabelControl labelControl41;
        private DevExpress.XtraEditors.LabelControl labelControl40;
        private DevExpress.XtraEditors.LabelControl labelControl65;
        private DevExpress.XtraEditors.LabelControl labelControl74;
        private DevExpress.XtraEditors.LabelControl labelControl91;
        private DevExpress.XtraEditors.LabelControl labelControl84;
        private DevExpress.XtraEditors.TextEdit txBbi;
        private DevExpress.XtraEditors.LabelControl labelControl83;
        private DevExpress.XtraEditors.LabelControl labelControl76;
        private DevExpress.XtraEditors.LabelControl labelControl82;
        private DevExpress.XtraEditors.LabelControl labelControl72;
        private DevExpress.XtraEditors.LabelControl labelControl71;
        private DevExpress.XtraEditors.LabelControl labelControl69;
        private DevExpress.XtraEditors.LabelControl labelControl67;
        private DevExpress.XtraEditors.LabelControl labelControl68;
        private DevExpress.XtraEditors.LabelControl labelControl80;
        private DevExpress.XtraEditors.LabelControl labelControl81;
        private DevExpress.XtraEditors.LabelControl labelControl92;
        private DevExpress.XtraEditors.XtraScrollableControl xtraScrollableControl12;
        private System.Windows.Forms.ComboBox cbKeadaanPulang;
        private DevExpress.XtraEditors.SimpleButton addObat;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.CheckBox chkDoc7;
        private System.Windows.Forms.CheckBox chkDoc8;
        private System.Windows.Forms.CheckBox chkDoc6;
        private System.Windows.Forms.CheckBox chkDoc5;
        private System.Windows.Forms.CheckBox chkDoc4;
        private System.Windows.Forms.CheckBox chkDoc3;
        private System.Windows.Forms.CheckBox chkDoc2;
        private System.Windows.Forms.CheckBox chkDoc1;
        private DevExpress.XtraEditors.TextEdit txDoc3;
        private DevExpress.XtraEditors.TextEdit txDoc5;
        private DevExpress.XtraEditors.TextEdit txDoc6;
        private DevExpress.XtraEditors.TextEdit txDoc4;
        private DevExpress.XtraEditors.TextEdit txDoc2;
        private DevExpress.XtraEditors.TextEdit txDoc1;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl38;
        private DevExpress.XtraEditors.LabelControl lblKeadaan;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private System.Windows.Forms.ComboBox cbAlatTerpasang;
        private DevExpress.XtraGrid.GridControl gcObtPlng;
        private DevExpress.XtraGrid.Views.Grid.GridView gvObtPlng;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn19;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn20;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn21;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn22;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn23;
        private DevExpress.XtraEditors.TextEdit txAltTerpsang;
        private DevExpress.XtraEditors.TextEdit txKeadaanDtl;
        private DevExpress.XtraEditors.TextEdit txObatRutin;
        private DevExpress.XtraEditors.RadioGroup rgRawatLanjutan;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.LabelControl labelControl47;
        private DevExpress.XtraEditors.LabelControl labelControl48;
        private DevExpress.XtraEditors.LabelControl labelControl49;
        private DevExpress.XtraEditors.LabelControl labelControl50;
        private DevExpress.XtraEditors.LabelControl labelControl52;
        private DevExpress.XtraEditors.TextEdit txWaktu;
        private DevExpress.XtraEditors.TextEdit txdoRawat;
        private DevExpress.XtraEditors.TextEdit txKebiasaanlain;
        private DevExpress.XtraEditors.TextEdit txDokterDituju;
        private DevExpress.XtraEditors.TextEdit txTindakan;
        private DevExpress.XtraEditors.TextEdit txPsikologis;
        private DevExpress.XtraEditors.TextEdit txProcedurePlan;
        private DevExpress.XtraEditors.TextEdit txControlLanjutan;
        private DevExpress.XtraEditors.TextEdit txProcRawat;
        private DevExpress.XtraEditors.TextEdit txUnitKesehatan;
        private DevExpress.XtraEditors.TextEdit txPolaMakan;
        private DevExpress.XtraEditors.TextEdit txAktivitas;
        private DevExpress.XtraEditors.TextEdit txjenisPeriksa;
        private DevExpress.XtraEditors.LabelControl labelControl53;
        private DevExpress.XtraEditors.LabelControl labelControl54;
        private DevExpress.XtraEditors.LabelControl labelControl55;
        private DevExpress.XtraEditors.LabelControl labelControl56;
        private DevExpress.XtraEditors.LabelControl labelControl57;
        private DevExpress.XtraEditors.LabelControl labelControl58;
        private DevExpress.XtraEditors.LabelControl labelControl59;
        private DevExpress.XtraEditors.LabelControl labelControl60;
        private DevExpress.XtraEditors.LabelControl labelControl61;
        private DevExpress.XtraEditors.LabelControl labelControl62;
        private DevExpress.XtraEditors.LabelControl labelControl63;
        private DevExpress.XtraEditors.LabelControl labelControl64;
        private DevExpress.XtraEditors.LabelControl labelControl66;
        private DevExpress.XtraEditors.DateEdit dtkeluar;
        private DevExpress.XtraEditors.XtraScrollableControl xtraScrollableControl11;
        private DevExpress.XtraEditors.LabelControl labelControl25;
        private DevExpress.XtraEditors.LabelControl labelControl21;
        private DevExpress.XtraEditors.LabelControl labelControl20;
        private DevExpress.XtraEditors.LabelControl labelControl24;
        private DevExpress.XtraEditors.LabelControl labelControl23;
        private DevExpress.XtraEditors.LabelControl labelControl22;
        private DevExpress.XtraEditors.LabelControl labelControl19;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.LabelControl labelControl94;
        private DevExpress.XtraEditors.MemoEdit txAnjuran;
        private DevExpress.XtraEditors.MemoEdit mmPeriksaFisik;
        private DevExpress.XtraEditors.MemoEdit txAnamesa;
        private DevExpress.XtraEditors.TextEdit txTerapiLanjtan;
        private DevExpress.XtraEditors.TextEdit txTindakanDo;
        private DevExpress.XtraEditors.TextEdit txPengobatan;
        private DevExpress.XtraEditors.TextEdit txDiagnosaAkhir;
        private DevExpress.XtraEditors.TextEdit txDokterKonsultan;
        private DevExpress.XtraEditors.TextEdit txDokterPengirim;
        private DevExpress.XtraEditors.DateEdit dtKeluarx;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panTbl;
        private DevExpress.XtraGrid.GridControl grdMain;
        private DevExpress.XtraGrid.Views.Grid.GridView gvwMain;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn28;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn29;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn30;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn31;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn32;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn33;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn34;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn35;
    }
}

